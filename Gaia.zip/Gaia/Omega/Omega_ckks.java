package Omega;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.util.Base64;

public class Omega_ckks {

    static {
        System.loadLibrary("ckks");
    }


    private native long initCKKS(int lambda);
    private native byte[] encrypt(long context, double value);
    private native double decrypt(long context, byte[] ciphertext);
    private native byte[] add(long context, byte[] ciphertext1, byte[] ciphertext2);
    private native byte[] sub(long context, byte[] ciphertext1, byte[] ciphertext2);
    private native byte[] multiply(long context, byte[] ciphertext, double scalar);
    private native void saveKeysToFile(long context, String publicKeyPath, String privateKeyPath);
    private native long loadKeysFromFile(String publicKeyPath, String privateKeyPath);
    private native void cleanup(long context);

    private long context;

    public void init(int lambda) {
        context = initCKKS(lambda);
    }

    public void WriteSK(String fileName, BigInteger q1) throws IOException {
        try (FileOutputStream outputStream = new FileOutputStream(new File(fileName))) {
            outputStream.write(Base64.getEncoder().encode(q1.toByteArray()));
        }
    }

    public static BigInteger readSK(String fileName) throws IOException {
        File file = new File(fileName);
        try (FileInputStream inputStream = new FileInputStream(file)) {
            byte[] bytes = new byte[(int) file.length()];
            inputStream.read(bytes);
            byte[] decodedBytes = Base64.getDecoder().decode(bytes);
            return new BigInteger(decodedBytes);
        }
    }


    public byte[] Enc(double value) {
        return encrypt(context, value);
    }


    public double Dec(byte[] ciphertext) {
        return decrypt(context, ciphertext);
    }


    public byte[] add(byte[] ciphertext1, byte[] ciphertext2) {
        return add(context, ciphertext1, ciphertext2);
    }


    public byte[] sub(byte[] ciphertext1, byte[] ciphertext2) {
        return sub(context, ciphertext1, ciphertext2);
    }


    public byte[] multiply(byte[] ciphertext, double scalar) {
        return multiply(context, ciphertext, scalar);
    }


    public void saveKeys(String publicKeyPath, String privateKeyPath) {
        saveKeysToFile(context, publicKeyPath, privateKeyPath);
    }


    public void loadKeys(String publicKeyPath, String privateKeyPath) {
        context = loadKeysFromFile(publicKeyPath, privateKeyPath);
    }


    public void cleanup() {
        cleanup(context);
    }
}
