package Omega;

import NSP.Times;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import it.unisa.dia.gas.jpbc.*;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;
import it.unisa.dia.gas.plaf.jpbc.pairing.a1.TypeA1CurveGenerator;
import lombok.SneakyThrows;
import org.apache.commons.codec.binary.Base64;
import util.JsonUtil;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
public class NewOmega {
    private Field<Element> G;
    private Field<Element> Zr;
    private Element g;
    private Element h;
    private Element g1;
    private Element h1;
    private ElementPowPreProcessing gPre;
    private ElementPowPreProcessing hPre;
    private ElementPowPreProcessing g1Pre;
    private ElementPowPreProcessing h1Pre;
    private BigInteger q1;

    // 写入私钥到文件
    @SneakyThrows
    public void WriteSK(String fileName, BigInteger q1) throws IOException {
        FileOutputStream outputStream = new FileOutputStream(new File(fileName));
        outputStream.write(Base64.encodeBase64(q1.toByteArray()));
        outputStream.close();
    }

    public static BigInteger readSK(String fileName) throws IOException {
        File file = new File(fileName);
        try (FileInputStream inputStream = new FileInputStream(file)) {
            byte[] bytes = new byte[(int) file.length()];
            inputStream.read(bytes);
            byte[] decodedBytes = Base64.decodeBase64(bytes);
            return new BigInteger(decodedBytes);
        }
    }

    public PK Gen(int lambda, SK _sk, String fileName) throws IOException {//|SK|=256,|PK|=520;
        SecureRandom rng = new SecureRandom();

        TypeA1CurveGenerator a1 = new TypeA1CurveGenerator(rng, 2, lambda);
        PairingParameters param = a1.generate();

        Pairing pairing = PairingFactory.getPairing(param);
        String ParamString = param.toString();

        Field<Element> G = pairing.getG1();
        Zr = pairing.getZr();
        q1 = param.getBigInteger("n0");
        BigInteger q2 = param.getBigInteger("n1");
        Element g = G.newRandomElement().getImmutable();
        System.out.println("g.toBytes() = " + g.toBytes().length);
        System.out.println("g = " + g);
        gPre = g.getElementPowPreProcessing();
        PairingPreProcessing gPair = pairing.getPairingPreProcessingFromElement(g);
        Element u = G.newRandomElement().getImmutable();
        Element h = u.pow(q2).getImmutable();
        hPre = h.getElementPowPreProcessing();
        Element g1 = gPair.pairing(g).getImmutable();
        Element h1 = gPair.pairing(h).getImmutable();
        _sk.setQ1(q1);
        System.out.println("q1.bitLength() = " + q1.bitLength());
        System.out.println("q1.toByteArray().length = " + q1.toByteArray().length);
        System.out.println("q1.toString() = " + q1.toString());
        WriteSK(fileName + "/SK.json", q1);

//        gqPre = g_q.getElementPowPreProcessing();
        // System.out.println(G1.equals(pairing.getGT()));
        return new PK(g, h, pairing, h1, g1, ParamString);

    }

    // BGN 加密函数
    public Element Enc(BigInteger m) {
        Element r = Zr.newRandomElement().getImmutable();
        return gPre.pow(m).mul(hPre.powZn(r)).getImmutable();
        //gPre的m次方*hPre的r次方    r是随机的
    }

    // BGN 加密函数 (g1, h1)
    public Element Enc1(BigInteger m) {
        Element r = Zr.newRandomElement().getImmutable();
        return g1Pre.pow(m).mul(h1Pre.powZn(r)).getImmutable();
        //g1Pre的m次方*h1Pre的r次方    r是随机的
    }

    // 并行加密
    public Element ConcurrentEnc(BigInteger m) throws ExecutionException, InterruptedException {
        Element r = Zr.newRandomElement().getImmutable();
        FutureTask<Element> task00 = new FutureTask<>(() -> gPre.pow(m).getImmutable());
        FutureTask<Element> task01 = new FutureTask<>(() -> hPre.powZn(r).getImmutable());

        new Thread(task00).start();
        new Thread(task01).start();

        return task00.get().mul(task01.get()).getImmutable();
    }

    public Element ConcurrentEnc1(BigInteger m) throws ExecutionException, InterruptedException {
        Element r = Zr.newRandomElement().getImmutable();
        FutureTask<Element> task03 = new FutureTask<>(() -> g1Pre.pow(m).getImmutable());
        FutureTask<Element> task04 = new FutureTask<>(() -> h1Pre.powZn(r).getImmutable());

        new Thread(task03).start();
        new Thread(task04).start();

        return task03.get().mul(task04.get()).getImmutable();
    }

    // BGN 解密函数
    public BigInteger Dec(Element C, PK pk, BigInteger _sk) {
        Element P = C.pow(_sk).getImmutable();
        //P = C^sk
        ElementPowPreProcessing gqPre = pk.getG().pow(_sk).getElementPowPreProcessing();
        //gqPre = (g^sk)预处理
        BigInteger res = BigInteger.ZERO;

        // 寻找离散对数
        while (!P.equals(gqPre.pow(res))) {
            res = res.add(BigInteger.ONE);
        }
        //m是明文,C是密文
        // C^sk = ((g^sk)预处理)^m
        //C = g^m
        return res;
    }

    // BGN 解密函数 (g1, h1)
    public BigInteger Dec1(Element C, PK pk, BigInteger _sk) {
        Element P = C.pow(_sk).getImmutable();
        ElementPowPreProcessing gqPre = pk.getG1().pow(_sk).getElementPowPreProcessing();
        BigInteger res = BigInteger.ZERO;
        //System.out.println("开始解密");

        // 寻找离散对数
        while (!P.equals(gqPre.pow(res))) {
            res = res.add(BigInteger.ONE);
        }
        //System.out.println("解密结束");
        return res;
    }

    // 并行解密
    @SneakyThrows
    public BigInteger ConcurrentDec(Element C, PK pk, BigInteger _sk) {
        FutureTask<Element> task10 = new FutureTask<>(() -> C.pow(_sk));
        FutureTask<ElementPowPreProcessing> task11 = new FutureTask<>(() -> pk.getG().pow(_sk).getElementPowPreProcessing());

        new Thread(task10).start();
        new Thread(task11).start();

        Element P = task10.get();
        ElementPowPreProcessing gqPre = task11.get();

        BigInteger res = BigInteger.ZERO;
        while (!P.equals(gqPre.pow(res))) {
            res = res.add(BigInteger.ONE);
        }

        return res;
    }

    // 同态加法
    public Element HomomorphicAdd(Element c1, Element c2) {
        return c1.mul(c2).getImmutable();  // c1 + c2
    }

    public Element add(Element C1, Element C2) {
        // 实现同态加法
        return C1.mul(C2).mul(hPre.powZn(Zr.newRandomElement())).getImmutable();
        //c1*c2*(hPre)r次方
    }

    // 同态乘法
    public Element HomomorphicMultiply(Element c, BigInteger scalar) {
        return c.pow(scalar).getImmutable();  // c * m
    }

    public void SetByPk(PK pk) {
        gPre = pk.getG();
        hPre = pk.getH();
        g1Pre = pk.getG1();
        h1Pre = pk.getH1();
        Zr = pk.getE().getZr();

    }

    @SneakyThrows
    public PK getPK(String fileName) {
        String jsonFile = JsonUtil.readJsonFile(fileName);
        ObjectMapper mapper = new ObjectMapper();
        JsonNode rootNode = mapper.readTree(jsonFile);
        byte[] g = Base64.decodeBase64(rootNode.get("g").asText());
        byte[] g1 = Base64.decodeBase64(rootNode.get("g1").asText());
        byte[] h = Base64.decodeBase64(rootNode.get("h").asText());
        byte[] h1 = Base64.decodeBase64(rootNode.get("h1").asText());
        String param = rootNode.get("param").asText();
        Pairing pairing = PairingFactory.getPairing("D:\\Gaia\\src\\main\\resources\\ours.properties");
        Element ge = pairing.getG1().newElementFromBytes(g);
        Element g1e = pairing.getGT().newElementFromBytes(g1);
        Element he = pairing.getG1().newElementFromBytes(h);
        Element h1e = pairing.getGT().newElementFromBytes(h1);
        return new PK(ge, he, pairing, h1e, g1e, param);
    }

    public Element sub(Element C1, Element C2) {
        Element r = Zr.newRandomElement().getImmutable();
        return C1.div(C2).mul(hPre.powZn(r)).getImmutable();
        //(C1➗C2)*hPre的r次方   r是随机数
    }

    public Element add_G1(Element C1, Element C2) {
        return C1.mul(C2).mul(h1Pre.powZn(Zr.newRandomElement())).getImmutable();
        //c1*c2*(h1Pre)的r次方
    }

    @SneakyThrows
//    @Deprecated
    public int ConcurrentDec1(Element P, Element[] elements) {

        int i = 0;
        while (!P.equals(elements[i])) {
            i++;
        }
        return i;
    }

    public Element add_G1r(Element C1, Element C2) {
        long Mulrs = System.currentTimeMillis();
        Element immutable = C1.mul(C2).mul(h1Pre.powZn(Zr.newRandomElement())).getImmutable();
        long Mulre = System.currentTimeMillis();
        Times.timeMulR += (Mulre - Mulrs);
        Times.alltimes += (Mulre - Mulrs);
        return immutable;
    }

    public Element sub_G1(Element C1, Element C2) {
        Element r = Zr.newRandomElement().getImmutable();
        return C1.div(C2).mul(h1Pre.powZn(r)).getImmutable();
    }

    public static void main(String[] args) throws IOException, ExecutionException, InterruptedException {

        // 记录程序开始时间
        long startTime = System.currentTimeMillis();

        NewOmega omega = new NewOmega();
        // 定义测试参数
        int lambda = 256; // 安全参数
        SK sk = new SK(); // 私钥对象
        String filePath = "D:\\docter\\Hermers-code/newHermes/src/main/resources"; // 公私钥存储路径

        // 生成公钥和私钥
        System.out.println("正在生成公钥和私钥...");
        PK pk = omega.Gen(lambda, sk, filePath);

        // 测试整数加密和解密
        BigInteger integerMessage = BigInteger.valueOf(12345);
        System.out.println("原始整数消息: " + integerMessage);
        Element encryptedIntegerMessage = omega.Enc(integerMessage);
        System.out.println("加密后的整数消息: " + encryptedIntegerMessage);
        BigInteger decryptedIntegerMessage = omega.Dec(encryptedIntegerMessage, pk, sk.getQ1());
        System.out.println("解密后的整数消息: " + decryptedIntegerMessage);
        if (integerMessage.equals(decryptedIntegerMessage)) {
            System.out.println("整数加密和解密测试通过!");
        } else {
            System.out.println("整数加密和解密测试失败。");
        }


        // 测试同态加法
        BigInteger message1 = BigInteger.valueOf(5);
        BigInteger message2 = BigInteger.valueOf(10);
        System.out.println("原始消息1: " + message1);
        System.out.println("原始消息2: " + message2);
        Element encryptedMessage1 = omega.Enc(message1);
        Element encryptedMessage2 = omega.Enc(message2);
        System.out.println("加密后的消息1: " + encryptedMessage1);
        System.out.println("加密后的消息2: " + encryptedMessage2);
        Element homomorphicSum = omega.add(encryptedMessage1, encryptedMessage2);
        BigInteger decryptedSum = omega.Dec(homomorphicSum, pk, sk.getQ1());
        System.out.println("同态加法解密后的消息: " + decryptedSum);
        if (message1.add(message2).equals(decryptedSum)) {
            System.out.println("同态加法测试通过!");
        } else {
            System.out.println("同态加法测试失败。");
        }


        // 测试同态减法
        BigInteger message3 = BigInteger.valueOf(544);
        BigInteger message4 = BigInteger.valueOf(102);
        System.out.println("原始消息3: " + message3);
        System.out.println("原始消息4: " + message4);
        Element encryptedMessage3 = omega.Enc(message3);
        Element encryptedMessage4 = omega.Enc(message4);
        System.out.println("加密后的消息1: " + encryptedMessage3);
        System.out.println("加密后的消息2: " + encryptedMessage4);
        Element homomorphicSub = omega.sub(encryptedMessage3, encryptedMessage4);
        BigInteger decryptedSub = omega.Dec(homomorphicSub, pk, sk.getQ1());
        System.out.println("同态减法解密后的消息: " + decryptedSub);

        // 记录程序结束时间
        long endTime = System.currentTimeMillis();

        // 计算并输出程序运行时间
        long totalTime = endTime - startTime;
        System.out.println("\n程序运行时间: " + totalTime + " 毫秒");
    }

}
