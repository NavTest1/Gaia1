package Omega;

import NSP.Times;
import Proxy.CT;
import util.JsonUtil;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import it.unisa.dia.gas.jpbc.*;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;
import it.unisa.dia.gas.plaf.jpbc.pairing.a1.TypeA1CurveGenerator;
import lombok.SneakyThrows;
import org.apache.commons.codec.binary.Base64;

import java.io.File;
import java.io.FileOutputStream;
import java.math.BigInteger;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;


public class Omega {

    // private  Pairing pairing;
    private BigInteger q1;//私钥
    private Field Zr;
    private ElementPowPreProcessing gPre;
    private ElementPowPreProcessing hPre;
    private ElementPowPreProcessing g1Pre;
    private ElementPowPreProcessing h1Pre;
//    private ElementPowPreProcessing gqPre;

    @SneakyThrows
    public static void main(String[] args) throws NoSuchAlgorithmException {
        Omega omega = new Omega();
        omega.Gen(256,new SK(),"C:\\Users\\zhb25\\Desktop\\信安作品赛\\newHermes\\src\\main\\resources");
//        PK pk = omega.Gen(256, new SK(), "resources");//返回公钥产生私钥
        //System.out.println(pk.getN().bitLength());
        // System.out.println(pk.getG().toString());
//        Element c = omega.Enc(new BigInteger("1")).getImmutable();
//        Element c1 = omega.Enc(new BigInteger("10")).getImmutable();
//        Element c2 = omega.Enc(new BigInteger("100")).getImmutable();

//        Element c4 = omega.Enc(new BigInteger("10000")).getImmutable();
//        Element c5 = omega.Enc(new BigInteger("10")).getImmutable();
        // BigInteger m=omega.Dec(new BigInteger(c), omega.getQ1(),pk);
//        pk.WritePKinJson("resources/PK.json");
//        PK pk1 = omega.getPK("resources/PK.json");
//        omega.SetByPk(pk1);
//        long t1 = System.currentTimeMillis();
//        Element c3 = omega.Enc(new BigInteger("10000")).getImmutable();
//        long t2 = System.currentTimeMillis();
//        Element cc3 = omega.ConcurrentEnc(new BigInteger("10000")).getImmutable();
//        long t3 = System.currentTimeMillis();
//        System.out.println("(t2-t1) = " + (t2 - t1));
//        System.out.println("(t3-t2) = " + (t3 - t2));
//        CT ct = new CT();
//        BigInteger sk = ct.getSk();
//
//        long l1 = System.currentTimeMillis();
//        BigInteger ans = omega.Dec(c3, pk1, sk);
//        long l2 = System.currentTimeMillis();
//        BigInteger ans1 = omega.ConcurrentDec(cc3, pk1, sk);
//        long l3 = System.currentTimeMillis();
//        BigInteger ans2 = omega.Dec(c2, omega.getQ1());
//        long l4 = System.currentTimeMillis();
//        BigInteger ans3 = omega.Dec(c3, pk1, omega.getQ1());
//        System.out.println("ans3.toString() = " + ans3.toString());
//        long l5 = System.currentTimeMillis();
//        BigInteger ans4 = omega.Dec(c4, omega.getQ1());
//        long l6 = System.currentTimeMillis();

//        System.out.println("10000:(l6-l5) = " + (l6 - l5));
//        System.out.println("10000:(l5-l4) = " + (l5 - l4));
//        System.out.println("100:(l4-l3) = " + (l4 - l3));
//        System.out.println("10000：(l3-l2) = " + (l3 - l2));
//        System.out.println("10000：(l2-l1) = " + (l2 - l1));
////
//        System.out.println("omega.gPre = " + (omega.gPre.toBytes()).length);
//        System.out.println("ans = " + ans);
//        System.out.println("ans1 = " + ans1);
    }

    public PK Gen(int lambda, SK _sk, String fileName) {//|SK|=256,|PK|=520;
        SecureRandom rng = new SecureRandom();

        TypeA1CurveGenerator a1 = new TypeA1CurveGenerator(rng, 2, lambda);
        PairingParameters param = a1.generate();

        Pairing pairing = PairingFactory.getPairing(param);
        String ParamString = param.toString();

        Field<Element> G = pairing.getG1();
        Zr = pairing.getZr();
        q1 = param.getBigInteger("n0");
        BigInteger q2 = param.getBigInteger("n1");
        Element g = G.newRandomElement().getImmutable();
        System.out.println("g.toBytes() = " + g.toBytes().length);
        System.out.println("g = " + g);
        gPre = g.getElementPowPreProcessing();
        PairingPreProcessing gPair = pairing.getPairingPreProcessingFromElement(g);
        Element u = G.newRandomElement().getImmutable();
        Element h = u.pow(q2).getImmutable();
        hPre = h.getElementPowPreProcessing();
        Element g1 = gPair.pairing(g).getImmutable();
        Element h1 = gPair.pairing(h).getImmutable();
        _sk.setQ1(q1);
        System.out.println("q1.bitLength() = " + q1.bitLength());
        System.out.println("q1.toByteArray().length = " + q1.toByteArray().length);
        System.out.println("q1.toString() = " + q1.toString());
        WriteSK(fileName + "/SK.json", q1);
//        gqPre = g_q.getElementPowPreProcessing();
        // System.out.println(G1.equals(pairing.getGT()));
        return new PK(g, h, pairing, h1, g1, ParamString);

    }

    public Element Enc(BigInteger m) {
        Element r = Zr.newRandomElement().getImmutable();
        return gPre.pow(m).getImmutable().mul(hPre.powZn(r)).getImmutable();
    }

    public Element Enc1(BigInteger m) {
        Element r = Zr.newRandomElement().getImmutable();
        return g1Pre.pow(m).getImmutable().mul(h1Pre.powZn(r)).getImmutable();
    }


    public Element ConcurrentEnc(BigInteger m) throws ExecutionException, InterruptedException {
        Element r = Zr.newRandomElement().getImmutable();
        FutureTask<Element> task00 = new FutureTask<>(() -> gPre.pow(m).getImmutable());
        FutureTask<Element> task01 = new FutureTask<>(() -> hPre.powZn(r).getImmutable());
        new Thread(task00, "t00").start();
        new Thread(task01, "t01").start();
        return task00.get().mul(task01.get()).getImmutable();
    }

    public Element ConcurrentEnc1(BigInteger m) throws ExecutionException, InterruptedException {
        Element r = Zr.newRandomElement().getImmutable();
        FutureTask<Element> task03 = new FutureTask<>(() -> g1Pre.pow(m).getImmutable());
        FutureTask<Element> task04 = new FutureTask<>(() -> h1Pre.powZn(r).getImmutable());
        new Thread(task03, "t03").start();
        new Thread(task04, "t04").start();
        return task03.get().mul(task04.get()).getImmutable();
    }

    /*    * 解离散对数问题
     * 使用pollard's lambda解离散对数
     * */
    public BigInteger Dec(Element C, PK pk, BigInteger _sk) {
        Element P = C.pow(_sk).getImmutable();

        //System.out.println(C.duplicate().pow(sk).equals(g.duplicate().pow(q1).pow(new BigInteger("123456"))));
        //true表示加密没问题
        ElementPowPreProcessing gqPre = pk.getG().pow(_sk)
                .getElementPowPreProcessing();
        BigInteger res = BigInteger.ZERO;

        while (!P.equals(gqPre.pow(res))) {
            res = res.add(BigInteger.ONE);
        }

        return res;
    }

    public BigInteger Dec1(Element C, PK pk, BigInteger _sk) {
        Element P = C.pow(_sk).getImmutable();

        //System.out.println(C.duplicate().pow(sk).equals(g.duplicate().pow(q1).pow(new BigInteger("123456"))));
        //true表示加密没问题
        ElementPowPreProcessing gqPre = pk.getG1().pow(_sk)
                .getElementPowPreProcessing();
        BigInteger res = BigInteger.ZERO;

        while (!P.equals(gqPre.pow(res))) {
            res = res.add(BigInteger.ONE);
        }

        return res;
    }

    @SneakyThrows
//    @Deprecated
    public BigInteger ConcurrentDec(Element C, PK pk, BigInteger _sk) {
//        Element P = C.pow(_sk).getImmutable();

        FutureTask<Element> task10 = new FutureTask<>(() -> C.pow(_sk));

        //System.out.println(C.duplicate().pow(sk).equals(g.duplicate().pow(q1).pow(new BigInteger("123456"))));
        //true表示加密没问题
//        ElementPowPreProcessing gqPre = pk.getG().pow(_sk)
//                .getElementPowPreProcessing();

        FutureTask<ElementPowPreProcessing> task11 = new FutureTask<>(() -> pk.getG().pow(_sk).getElementPowPreProcessing());

        new Thread(task10, "t10").start();
        new Thread(task11, "t11").start();
        Element P = task10.get();
        ElementPowPreProcessing gqPre = task11.get();
        BigInteger res = BigInteger.ZERO;
//        BigInteger resb =new BigInteger("2999");
//        BigInteger res1 = new BigInteger("3000");
//        BigInteger res1b = new BigInteger("5999");
//        BigInteger res2 = new BigInteger("6000");
//        BigInteger res2b = new BigInteger("8999");
//        BigInteger res3 = new BigInteger("9000");
//        BigInteger res3b = new BigInteger("11000");
        while (!P.equals(gqPre.pow(res))) {
            res = res.add(BigInteger.ONE);
        }
//        FutureTask<Boolean>task1z=new FutureTask<>(()->{
//            for(; res.compareTo(resb)<=0;res.add(BigInteger.ONE)){
//                if(P.equals(gqPre.pow(res)))return true;
//            }
//            return false;
//        });
        return res;

    }

    @Deprecated
    public BigInteger ConcurrentDec1(Element C, PK pk, BigInteger _sk) {
        Element P = C.pow(_sk).getImmutable();

        //System.out.println(C.duplicate().pow(sk).equals(g.duplicate().pow(q1).pow(new BigInteger("123456"))));
        //true表示加密没问题
        ElementPowPreProcessing gqPre = pk.getG1().pow(_sk)
                .getElementPowPreProcessing();

        BigInteger res = BigInteger.ZERO;

        while (!P.equals(gqPre.pow(res))) {
            res = res.add(BigInteger.ONE);
        }

        return res;
    }

    //will@Deprecated，密钥应该要通过通信传输
    public BigInteger getQ1() {
        return q1;
    }

    @SneakyThrows
    public PK getPK(String fileName) {
        String jsonFile = JsonUtil.readJsonFile(fileName);
        ObjectMapper mapper = new ObjectMapper();
        JsonNode rootNode = mapper.readTree(jsonFile);
        byte[] g = Base64.decodeBase64(rootNode.get("g").asText());
        byte[] g1 = Base64.decodeBase64(rootNode.get("g1").asText());
        byte[] h = Base64.decodeBase64(rootNode.get("h").asText());
        byte[] h1 = Base64.decodeBase64(rootNode.get("h1").asText());
        String param = rootNode.get("param").asText();
        Pairing pairing = PairingFactory.getPairing("C:/Users/zhb25/Desktop/吴靖宇/hermes-system-core/Test/src/main/resources/map/ours.properties");
        Element ge = pairing.getG1().newElementFromBytes(g);
        Element g1e = pairing.getGT().newElementFromBytes(g1);
        Element he = pairing.getG1().newElementFromBytes(h);
        Element h1e = pairing.getGT().newElementFromBytes(h1);
        return new PK(ge, he, pairing, h1e, g1e, param);
    }

    public Element sub(Element C1, Element C2) {
        Element r = Zr.newRandomElement().getImmutable();
        return C1.div(C2).mul(hPre.powZn(r)).getImmutable();
    }

    public Element sub_G1(Element C1, Element C2) {
        Element r = Zr.newRandomElement().getImmutable();
        return C1.div(C2).mul(h1Pre.powZn(r)).getImmutable();
    }

    public Element add_G1(Element C1, Element C2) {
        return C1.mul(C2).mul(h1Pre.powZn(Zr.newRandomElement())).getImmutable();
    }

    public Element add_G1r(Element C1, Element C2) {
        long Mulrs = System.currentTimeMillis();
        Element immutable = C1.mul(C2).mul(h1Pre.powZn(Zr.newRandomElement())).getImmutable();
        long Mulre = System.currentTimeMillis();
        Times.timeMulR += (Mulre - Mulrs);
        Times.alltimes += (Mulre - Mulrs);
        return immutable;
    }

    public Element add(Element C1, Element C2) {
        return C1.mul(C2).mul(hPre.powZn(Zr.newRandomElement())).getImmutable();
    }

    public void SetByPk(PK pk) {
        gPre = pk.getG();
        hPre = pk.getH();
        g1Pre = pk.getG1();
        h1Pre = pk.getH1();
        Zr = pk.getE().getZr();
    }

    @SneakyThrows
    public void WriteSK(String fileName, BigInteger q1) {
        FileOutputStream outputStream = new FileOutputStream(new File("C:/Users/zhb25/Desktop/吴靖宇/hermes-system-core/Test/src/main/resources/map/SK.json"));
        outputStream.write(Base64.encodeBase64(q1.toByteArray()));
        outputStream.close();
    }

}
