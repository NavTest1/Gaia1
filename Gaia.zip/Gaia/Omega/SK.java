package Omega;
import java.math.BigInteger;

public class SK {
    private String k1,k2,k3,k4,k5;
    private BigInteger q1;

    public SK(){
    }

    public SK(BigInteger q){
        q1=q;
    }
    public void set_K(String[]ak){
        k1=ak[0];
        k2=ak[1];
        k3=ak[2];
        k4=ak[3];
        k5=ak[4];
    }

    public String[] getHash64(){
        return new String[]{k1,k2,k3,k4,k5};
    }

    public BigInteger getQ1() {
        return q1;
    }

    public void setQ1(BigInteger q1) {
        this.q1 = q1;
    }

}
