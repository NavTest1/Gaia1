package Omega;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.ElementPowPreProcessing;
import it.unisa.dia.gas.jpbc.Field;
import it.unisa.dia.gas.jpbc.Pairing;
import lombok.SneakyThrows;
import org.apache.commons.codec.binary.Base64;

import java.io.File;
import java.io.FileWriter;
import java.io.Writer;


/**
 * The type Pk.
 */
public class PK {


    private final Field<Element> _G;
    private final Field<Element> _G1;
    private final Pairing e;


    private final String paramString;
    private final ElementPowPreProcessing gPow;
    private final ElementPowPreProcessing g1Pow;
    private final ElementPowPreProcessing hPow;
    private final ElementPowPreProcessing h1Pow;
    private Element g;
    private Element g1;
    private Element h;
    private Element h1;


    /**
     * Instantiates a new Pk.
     *
     * @param _g2     the Element g
     * @param _h      the Element h
     * @param _ee     the pairing ee
     * @param h1      the Element h1
     * @param g1      the Element g1
     * @param ParmStr the parmstr 传递参数值，便于保存pairing
     */
    public PK(Element _g2, Element _h, Pairing _ee, Element h1, Element g1, String ParmStr) {


        _G = _ee.getG1();
        _G1 = _ee.getGT();
        e = _ee;
        this.paramString = ParmStr;
        g = _g2;
        this.g1 = g1;
        this.h = _h;
        this.h1 = h1;
        gPow = _g2.getElementPowPreProcessing();
        g1Pow = g1.getElementPowPreProcessing();
        hPow = _h.getElementPowPreProcessing();
        h1Pow = h1.getElementPowPreProcessing();
    }

    public PK(ElementPowPreProcessing _g2, ElementPowPreProcessing _h, Pairing _ee, ElementPowPreProcessing h1, ElementPowPreProcessing g1, String ParmStr) {

        _G = _ee.getG1();
        _G1 = _ee.getGT();
        System.out.println("_ee.getClass().toString()ddddddddddddddddd");
        System.out.println(_ee.getClass().toString());
        e = _ee;
        System.out.println("e.getClass().toString()dddddddddddddsaddddd");
        System.out.println(e.getClass().toString());
        this.paramString = ParmStr;
        gPow = _g2;
        g1Pow = g1;
        hPow = _h;
        h1Pow = h1;
    }


    /**
     * Gets e.
     *
     * @return the e
     */
    public Pairing getE() {
        return e;
    }

    /**
     * Gets g 1.
     *
     * @return the g 1
     */
    public ElementPowPreProcessing getG1() {
        return g1Pow;
    }

    /**
     * Gets h 1.
     *
     * @return the h 1
     */
    public ElementPowPreProcessing getH1() {
        return h1Pow;
    }


    /**
     * Gets pair.
     *
     * @param A the a
     * @param B the b
     * @return the pair
     */
    public Element EncMul(Element A, Element B) {
        return e.pairing(A.getImmutable(), B.getImmutable()).getImmutable();
    }


    /**
     * Gets g.
     *
     * @return the g
     */
    public Field get_G() {
        return _G;
    }

    /**
     * Gets g 1.
     *
     * @return the g 1
     */
    public Field get_G1() {
        return _G1;
    }

    /**
     * Gets g.
     *
     * @return the g
     */
    public ElementPowPreProcessing getG() {
        return gPow;
    }

    /**
     * Gets h.
     *
     * @return the h
     */
    public ElementPowPreProcessing getH() {
        return hPow;
    }


    /**
     * Write p kin json.
     *
     * @param fileName the file name
     */
    @SneakyThrows
    public void WritePKinJson(String fileName) {
        try (Writer writer = new FileWriter(new File("D:\\Gaia\\src\\main\\resources\\ours.properties"))) {
            writer.write(paramString);
        }
        ObjectMapper mapper = new ObjectMapper();
        ObjectNode root = mapper.createObjectNode();
        String GS = Base64.encodeBase64String(g.toBytes());
        String G1S = Base64.encodeBase64String(g1.toBytes());
        String HS = Base64.encodeBase64String(h.toBytes());
        String H1S = Base64.encodeBase64String(h1.toBytes());
        root.put("g", GS);
        root.put("g1", G1S);
        root.put("h", HS);
        root.put("h1", H1S);
        root.put("param", paramString);


        mapper.writeValue(new File(fileName), root);
    }

}

