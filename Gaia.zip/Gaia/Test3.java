import Algorithm.Floyd_Warshall_1;
import Class.PartialOrder;
import Class.TokenNode;
import Class.node;
import NSP.EncNavigationTools;
import NSP.EncNode;
import NSP.EncGraph;
import NSP.EncVecTools;
import NSP.StopSet;
import Gaia.GaiaNavigationTools;
import User.*;
import ckks.CKKSHelper;
import ckks.Ciphertext;
import lombok.SneakyThrows;

import util.*;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import Proxy.CT;
import Gaia.ERGDistanceMap;
import analysis.CommunicationAnalysis;

import static util.JsonUtil.*;
import static util.ProcessList.getTokenList;
import java.util.stream.*;

public class Test3 {
    private static final int TEST_ITERATIONS = 5;
    private static final int[] WAYPOINT_COUNTS = { 5 };
    private static final int[] CONSTRAINT_PAIRS = {5 };
    private static final double[] BLOCKAGE_RATIOS = {0.15};

    private static final String RESULT_DIR = "D:\\NavTest\\Testall\\2001";
    private static final String RESULT_FILE = RESULT_DIR + "\\gaia_performance2200.csv";
    private static final String LOG_FILE = RESULT_DIR + "\\Test3_performance2200.log";


    private static final boolean USE_ENCRYPTED_GRAPH_CACHE = true; 
    private static final String GRAPH_KEY = "2200"; 
    private static boolean reportGenerated = false; 

  
    private static final Map<Double, Boolean> graphCacheStatus = new ConcurrentHashMap<>();

    @SneakyThrows
    public static void main(String[] args) {
        clearLogFile();
        java.io.FileOutputStream fos = new java.io.FileOutputStream(LOG_FILE, true);
        java.io.PrintStream ps = new PrintStream(fos, true, "UTF-8");
        System.setOut(ps);
        System.setErr(ps);
        System.out.println("=== 开始 Gaia 性能测试 ===");
        System.out.println("测试迭代次数: " + TEST_ITERATIONS);
        System.out.println("途径点数量配置: " + Arrays.toString(WAYPOINT_COUNTS));
        System.out.println("约束对数配置: " + Arrays.toString(CONSTRAINT_PAIRS));
        System.out.println("开始时间: " + new Date());
        System.out.println("日志文件: " + LOG_FILE);
        System.out.println("结果文件: " + RESULT_FILE);
        System.out.println("==========================================");
        performanceTest();
    }

    @SneakyThrows
    private static void clearLogFile() {
        File logFile = new File(LOG_FILE);
        if (logFile.exists()) {
            try (PrintWriter writer = new PrintWriter(new FileWriter(LOG_FILE, false))) {
                writer.print("");
            }
            System.out.println("已清空之前的日志文件: " + LOG_FILE);
        } else {
            File dir = new File(RESULT_DIR);
            if (!dir.exists()) {
                dir.mkdirs();
            }
            logFile.createNewFile();
            System.out.println("创建新的日志文件: " + LOG_FILE);
        }
    }

    @SneakyThrows
    public static void performanceTest() {
        File dir = new File(RESULT_DIR);
        if (!dir.exists())
            dir.mkdirs();

         
        if (USE_ENCRYPTED_GRAPH_CACHE) {
            System.out.println("\n🔍 检查加密图缓存状态...");
            EncryptedGraphManager.printCacheStatus(GRAPH_KEY, BLOCKAGE_RATIOS);
        }

        try (PrintWriter writer = new PrintWriter(new FileWriter(RESULT_FILE))) {
            writer.println(
                    "阻塞比例,途径点数量,约束对数,迭代次数,地图加载时间(ms),Floyd预处理时间(ms),CKKS初始化时间(ms),令牌生成时间(ms),导航时间(ms),路径恢复时间(ms),路径构建时间(ms),总时间(ms),"
                            +
                            "距离偏差率(%)," +
                            "膨胀率_环境(vs原始),膨胀率_算法(vs最优)," +
                            "相似度_算法(vs最优%),相似度_环境(vs原始%)," +
                            "阻塞绕行成功率(%),偏序处理成功率(%),实际总距离(有阻塞),Gaia路径原始距离(无阻塞),理论最优距离(TSP基准)," +
                            "加密图上传(bytes),令牌上传(bytes),结果下载(bytes),交互数据(bytes),交互轮数,总通信量(bytes),总通信量(KB)");

            for (double blockageRatio : BLOCKAGE_RATIOS) {
                System.out.println("\n" + "=".repeat(60));
                System.out.println("=== 开始测试阻塞比例: " + String.format("%.0f%%", blockageRatio * 100) + " ===");
                System.out.println("=".repeat(60));

                if (USE_ENCRYPTED_GRAPH_CACHE) {
                    boolean cached = EncryptedGraphManager.encryptedGraphExists(GRAPH_KEY, blockageRatio);
                    System.out.println("📁 当前阻塞比例缓存状态: " + (cached ? "✅ 已缓存" : "🆕 将创建新缓存"));
                }

                for (int waypointCount : WAYPOINT_COUNTS) {
                    for (int constraintPairs : CONSTRAINT_PAIRS) {
                        if (constraintPairs > 0 && waypointCount < 2) {
                            continue;
                        }
                        if (constraintPairs > getMaxConstraintPairs(waypointCount)) {
                            continue;
                        }
                        System.out.println("\n" + "=".repeat(50));
                        System.out.println("=== 测试 " + waypointCount + " 个途径点, " + constraintPairs + " 对约束, 阻塞比例 " +
                                String.format("%.0f%%", blockageRatio * 100) + " ===");
                        System.out.println("=".repeat(50));
                        long totalMapTime = 0;
                        long totalFloydTime = 0;
                        long totalCkksTime = 0;
                        long totalTokenTime = 0;
                        long totalNavTime = 0;
                        long totalRecoveryTime = 0;
                        long totalPathTime = 0;
                        long totalOverallTime = 0;

                        double totalDistanceDeviation = 0;

                        double totalBlockageSuccess = 0;
                        double totalPartialOrderSuccess = 0;

                        double totalActualDistance = 0;
                        double totalgaiaPathOriginalDistance = 0;
                        double totalShortestDistance = 0;
                        double totalPER_Original = 0;
                        double totalPER_Optimal = 0;
                        double totalPS_Optimal = 0;
                        double totalPS_Original = 0;

                        int successfulIterations = 0;

                        for (int iteration = 0; iteration < TEST_ITERATIONS; iteration++) {
                            System.out.printf("\n--- 第 %d 次迭代 (途径点: %d, 约束: %d对, 阻塞: %.0f%%) ---\n",
                                    iteration + 1, waypointCount, constraintPairs, blockageRatio * 100);
                            long iterationStart = System.currentTimeMillis();
                            try {
                                TestResult result = runSingleTest(waypointCount, constraintPairs, blockageRatio);

                                long iterationEnd = System.currentTimeMillis();
                                long iterationTime = iterationEnd - iterationStart;

                                totalMapTime += result.mapLoadingTime;
                                totalFloydTime += result.floydTotalTime;
                                totalCkksTime += result.ckksTotalTime;
                                totalTokenTime += result.tokenGenerationTime;
                                totalNavTime += result.gaiaTotalTime;
                                totalRecoveryTime += result.pathRecoveryTime;
                                totalPathTime += result.pathConstructionTime;
                                totalOverallTime += iterationTime;

                                if (result.distanceDeviationRate >= 0) {
                                    totalDistanceDeviation += result.distanceDeviationRate;
                                }
                                if (result.per_Original >= 0)
                                    totalPER_Original += result.per_Original;
                                if (result.per_Optimal >= 0)
                                    totalPER_Optimal += result.per_Optimal;
                                if (result.ps_Optimal >= 0)
                                    totalPS_Optimal += result.ps_Optimal;
                                if (result.ps_Original >= 0)
                                    totalPS_Original += result.ps_Original;

                                if (result.blockageSuccessRate >= 0) {
                                    totalBlockageSuccess += result.blockageSuccessRate;
                                }
                                if (result.partialOrderSuccessRate >= 0) {
                                    totalPartialOrderSuccess += result.partialOrderSuccessRate;
                                }
                                if (result.actualTotalDistance >= 0) {
                                    totalActualDistance += result.actualTotalDistance;
                                }
                                if (result.gaiaPathOriginalDistance >= 0) {
                                    totalgaiaPathOriginalDistance += result.gaiaPathOriginalDistance;
                                }
                                if (result.shortestPathDistance >= 0) {
                                    totalShortestDistance += result.shortestPathDistance;
                                }

                                successfulIterations++;

                                String iterationLine = String.format(
                                        "%.2f,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%s",
                                        blockageRatio,
                                        waypointCount, constraintPairs, iteration + 1,
                                        result.mapLoadingTime, result.floydTotalTime, result.ckksTotalTime,
                                        result.tokenGenerationTime,
                                        result.gaiaTotalTime, result.pathRecoveryTime,
                                        result.pathConstructionTime, iterationTime,
                                        result.distanceDeviationRate,
                                        result.per_Original, result.per_Optimal,  
                                        result.ps_Optimal, result.ps_Original,  
                                        result.blockageSuccessRate, result.partialOrderSuccessRate,
                                        result.actualTotalDistance, result.gaiaPathOriginalDistance,
                                        result.shortestPathDistance, result.communicationStats.toCSVLine());
                                writer.println(iterationLine);
                                writer.flush();

                                System.out.printf("✅ 本次耗时: %d ms (导航: %d ms, 恢复: %d ms)\n",
                                        iterationTime, result.gaiaTotalTime, result.pathRecoveryTime);
                                System.out.printf("📊 详细时间: 地图=%d, Floyd=%d, CKKS=%d, 令牌=%d, 导航=%d, 恢复=%d, 构建=%d\n",
                                        result.mapLoadingTime, result.floydTotalTime,
                                        result.ckksTotalTime, result.tokenGenerationTime,
                                        result.gaiaTotalTime, result.pathRecoveryTime, result.pathConstructionTime);

                            } catch (Exception e) {
                                System.err.printf("❌ 第 %d 次迭代失败: %s\n", iteration + 1, e.getMessage());
                                e.printStackTrace();

                                String failedLine = String.format(
                                        "%.2f,%d,%d,%d,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1",
                                        blockageRatio,  
                                        waypointCount, constraintPairs, iteration + 1);
                                writer.println(failedLine);
                                writer.flush();
                            }
                        }

                        if (successfulIterations == 0) {
                            System.err.printf("!!! %d 个途径点,%d 对约束,%.0f%%阻塞的所有迭代都失败了 !!!\n",
                                    waypointCount, constraintPairs, blockageRatio * 100);
                            continue;
                        }

                         
                        long avgMapTime = totalMapTime / successfulIterations;
                        long avgFloydTime = totalFloydTime / successfulIterations;
                        long avgCkksTime = totalCkksTime / successfulIterations;
                        long avgTokenTime = totalTokenTime / successfulIterations;
                        long avgNavTime = totalNavTime / successfulIterations;
                        long avgRecoveryTime = totalRecoveryTime / successfulIterations;
                        long avgPathTime = totalPathTime / successfulIterations;
                        long avgOverallTime = totalOverallTime / successfulIterations;

                         
                        double avgDistanceDeviation = totalDistanceDeviation / successfulIterations;

                         
                        double avgPER_Original = totalPER_Original / successfulIterations;
                        double avgPER_Optimal = totalPER_Optimal / successfulIterations;
                        double avgPS_Optimal = totalPS_Optimal / successfulIterations;
                        double avgPS_Original = totalPS_Original / successfulIterations;

                         

                        double avgBlockageSuccess = totalBlockageSuccess / successfulIterations;
                        double avgPartialOrderSuccess = totalPartialOrderSuccess / successfulIterations;
                         
                        double avgActualDistance = totalActualDistance / successfulIterations;
                        double avggaiaPathOriginalDistance = totalgaiaPathOriginalDistance / successfulIterations;
                        double avgShortestDistance = totalShortestDistance / successfulIterations;

                         
                         
                        String avgLine = String.format(
                                "%.2f,%d,%d,平均值,%d,%d,%d,%d,%d,%d,%d,%d,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%s",
                                blockageRatio,
                                waypointCount, constraintPairs, avgMapTime, avgFloydTime, avgCkksTime, avgTokenTime,
                                avgNavTime, avgRecoveryTime, avgPathTime, avgOverallTime,
                                avgDistanceDeviation,
                                avgPER_Original, avgPER_Optimal,
                                avgPS_Optimal, avgPS_Original,
                                avgBlockageSuccess,
                                avgPartialOrderSuccess,
                                avgActualDistance, avggaiaPathOriginalDistance, avgShortestDistance,
                                "N/A,N/A,N/A,N/A,N/A,N/A,N/A");
                        writer.println(avgLine);
                        writer.flush();

                        writer.println();  
                        writer.flush();

                        System.out.println("\n" + "=".repeat(80));
                        System.out.printf("=== %d 个途径点,%d 对约束,%.0f%%阻塞 - 平均性能统计 (%d/%d 成功) ===\n",
                                waypointCount, constraintPairs, blockageRatio * 100, successfulIterations,
                                TEST_ITERATIONS);
                        System.out.println("=".repeat(80));
                        System.out.printf("🗺️  地图加载: %d ms\n", avgMapTime);
                        System.out.printf("🔄 Floyd预处理: %d ms\n", avgFloydTime);
                        System.out.printf("🔐 CKKS初始化: %d ms\n", avgCkksTime);
                        System.out.printf("🎫 令牌生成: %d ms\n", avgTokenTime);
                        System.out.printf("🧭 Gaia导航: %d ms\n", avgNavTime);
                        System.out.printf("🔍 路径恢复: %d ms\n", avgRecoveryTime);
                        System.out.printf("🛣️  路径构建: %d ms\n", avgPathTime);
                        System.out.printf("⏱️  总时间: %d ms\n", avgOverallTime);

                         
                        System.out.println("\n📊 质量指标:");
                        System.out.printf("📏 平均距离偏差率: %.2f%%\n", avgDistanceDeviation);
                        System.out.printf("📏 平均距离偏差率: %.2f%%\n", avgDistanceDeviation);
                        System.out.printf("📈 平均膨胀率(环境): %.2fx\n", avgPER_Original);  
                        System.out.printf("📈 平均膨胀率(算法): %.2fx\n", avgPER_Optimal);  
                        System.out.printf("🔄 平均相似度(vs最优): %.2f%%\n", avgPS_Optimal);  
                        System.out.printf("🔄 平均相似度(vs原始): %.2f%%\n", avgPS_Original);  
                        System.out.printf("✅ 平均阻塞绕行成功率: %.2f%%\n", avgBlockageSuccess);
                        System.out.printf("✅ 平均偏序处理成功率: %.2f%%\n", avgPartialOrderSuccess);

                        System.out.printf("📐 平均实际距离: %.2f\n", avgActualDistance);
                        System.out.printf("📐 平均最短距离: %.2f\n", avgShortestDistance);
                        System.out.printf("📈 导航占比: %.1f%%\n", (avgNavTime * 100.0 / avgOverallTime));
                        System.out.printf("📈 恢复占比: %.1f%%\n", (avgRecoveryTime * 100.0 / avgOverallTime));
                    }
                }
            }

             
             
            System.out.println("\n" + "=".repeat(50));
            System.out.println("=== 测试完成 - 缓存总结 ===");
            System.out.println("=".repeat(50));

            if (USE_ENCRYPTED_GRAPH_CACHE) {
                EncryptedGraphManager.printCacheStatus(GRAPH_KEY, BLOCKAGE_RATIOS);
                System.out.println("\n💡 缓存使用说明:");
                System.out.println("  - ✅ 已缓存的阻塞比例：下次测试将直接使用，大幅减少加密时间");
                System.out.println("  - ❌ 未缓存的阻塞比例：下次测试将创建新缓存");
            }

            CommunicationAnalysis.generateTechnicalCommunicationReport(RESULT_FILE,
                    RESULT_DIR + "\\final_technical_communication_report2200.md");
            CommunicationAnalysis.generateCommunicationTable(RESULT_DIR + "\\final_communication_estimates2200.csv");

            System.out.println("✅ 最终通信分析报告已生成");
            System.out.println("📄 技术报告: " + RESULT_DIR + "\\final_technical_communication_report2200.md");
            System.out.println("📊 估算表: " + RESULT_DIR + "\\final_communication_estimates2200.csv");

        } catch (Exception e) {
            System.err.println("性能测试失败: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static int getMaxConstraintPairs(int waypointCount) {
        if (waypointCount <= 1)
            return 0;
        return waypointCount * (waypointCount - 1);  
    }

    private static TestResult runSingleTest(int waypointCount, int constraintPairs, double blockageRatio)
            throws Exception {
        System.gc();
        Thread.sleep(50);
        TestResult result = new TestResult();
        long stageStart, stageEnd;

         
        CommunicationStats commStats = new CommunicationStats();

         
        stageStart = System.currentTimeMillis();
        ConcurrentHashMap<Long, Integer> i2i = new ConcurrentHashMap<>();
        ConcurrentHashMap<Long, Long> ii2i = new ConcurrentHashMap<>();
        ConcurrentHashMap<Long, Long> oi2i = new ConcurrentHashMap<>();
        ConcurrentHashMap<Integer, node> apl;

        boolean useCachedGraph = USE_ENCRYPTED_GRAPH_CACHE &&
                EncryptedGraphManager.encryptedGraphExists(GRAPH_KEY, blockageRatio);
        Floyd_Warshall_1 fw;  

        if (useCachedGraph) {
             
            System.out.println("  🔄 使用已缓存的加密图...");
            EncryptedGraphManager.EncryptedGraphData graphData = EncryptedGraphManager.loadEncryptedGraph(GRAPH_KEY,
                    blockageRatio);

             
            apl = graphData.getApl();
            i2i = graphData.getI2i();
            ii2i = graphData.getIi2i();
            oi2i = graphData.getOi2i();

             
            commStats.startGraphUpload();
            Thread.sleep(5);
            commStats.endGraphUpload();
            graphCacheStatus.put(blockageRatio, true);

             
            System.out.println("  创建Floyd实例（使用缓存图）");
            fw = new Floyd_Warshall_1(apl, i2i, blockageRatio);
            fw.setup();

             
            System.out.println("  ⚡ 重新计算距离矩阵...");
            fw.compute();

        } else {
             
            System.out.println("  🆕 创建新的加密图（阻塞比例 " + String.format("%.0f%%", blockageRatio * 100) + ")");
            String json = "D:\\Gaia\\src\\main\\resources\\400-2200junctions(Manhattan) (2)\\2200\\2200junction.json";
            apl = JsonUtil.getNodeList600(json, i2i, ii2i, oi2i);
            getMapInJson(i2i, ii2i, oi2i);
            graphCacheStatus.put(blockageRatio, false);

            System.out.println("  创建Floyd实例（全新计算）");
            fw = new Floyd_Warshall_1(apl, i2i, blockageRatio);
            fw.setup();
            fw.compute();  
        }

        stageEnd = System.currentTimeMillis();
        result.floydTotalTime = stageEnd - stageStart;
        System.out.printf("  Floyd预处理完成: %d ms (阻塞比例: %.0f%%, 使用缓存: %s)\n",
                result.floydTotalTime, blockageRatio * 100, useCachedGraph ? "是" : "否");

         
        GaiaNavigationTools.setFloydInstance(fw);

         
        stageStart = System.currentTimeMillis();
        CKKSHelper iterationCkks = initializeCKKS();
        stageEnd = System.currentTimeMillis();
        result.ckksTotalTime = stageEnd - stageStart;
        System.out.printf("  CKKS初始化完成: %d ms\n", result.ckksTotalTime);

         
        if (USE_ENCRYPTED_GRAPH_CACHE && !useCachedGraph) {
            System.out.println("  💾 保存加密图缓存...");
             
            EncryptedGraphManager.saveEncryptedGraph(GRAPH_KEY, blockageRatio, apl, i2i, ii2i, oi2i, iterationCkks);
            graphCacheStatus.put(blockageRatio, true);
        }

         
        ArrayList<Long> plainQuery = generateRandomPath(apl, waypointCount);

         
        List<PartialOrder> userPartialOrders = generatePartialOrders(plainQuery, constraintPairs);
        System.out.printf("  生成 %d 对偏序约束\n", userPartialOrders.size());

         
        commStats.startTokenUpload();  
        stageStart = System.currentTimeMillis();
        PRF_PRP_Hash pph = new PRF_PRP_Hash(iterationCkks.getSecretKey());
        QueryTokenGen gentoken = new QueryTokenGen(pph, plainQuery, ii2i, i2i, apl, iterationCkks);
        ArrayList<TokenNode> tokenList = gentoken.getData();
        rebuildEncGraphMapping(tokenList, iterationCkks);
        validateEncGraphMapping(tokenList);
        TokenNode E_S = tokenList.get(0);
        TokenNode E_D = tokenList.get(tokenList.size() - 1);
        List<TokenNode> E_Stops = tokenList.subList(1, tokenList.size() - 1);
        stageEnd = System.currentTimeMillis();
        commStats.endTokenUpload();  
        result.tokenGenerationTime = stageEnd - stageStart;
        System.out.printf("  令牌生成完成: %d ms, 令牌数: %d\n", result.tokenGenerationTime, tokenList.size());

        List<PartialOrder> gaiaPO = userPartialOrders;

         
        if (!preValidateNavigation(E_S, E_D, E_Stops)) {
            System.out.println("  ⚠️ 导航预验证失败，重新生成路径");
             
            plainQuery = generateRobustRandomPath(apl, waypointCount, fw, i2i);

             
            gentoken = new QueryTokenGen(pph, plainQuery, ii2i, i2i, apl, iterationCkks);
            tokenList = gentoken.getData();

             
            rebuildEncGraphMapping(tokenList, iterationCkks);
            validateEncGraphMapping(tokenList);

             
            E_S = tokenList.get(0);
            E_D = tokenList.get(tokenList.size() - 1);
            E_Stops = tokenList.subList(1, tokenList.size() - 1);

             
            userPartialOrders = generatePartialOrders(plainQuery, constraintPairs);
            gaiaPO = userPartialOrders;  
        }

         
        stageStart = System.currentTimeMillis();
        CT ct;
        synchronized (GaiaNavigationTools.class) {
            ct = new CT(iterationCkks.getPublicKeys(), iterationCkks.getContext());
            GaiaNavigationTools.setCKKS(iterationCkks, ct);
            EncNavigationTools.init(iterationCkks, ct, iterationCkks.getPublicKeys());
            EncVecTools.init(iterationCkks.getContext(), iterationCkks.getPublicKeys());
            byte[] sk3 = new byte[32];
            new Random().nextBytes(sk3);
            GaiaNavigationTools.setSK3(sk3);
        }
        System.out.printf("  导航参数: 起点=%d, 终点=%d, 途径点=%d, 用户偏序约束=%d, 阻塞比例=%.0f%%\n",
                E_S.getId(), E_D.getId(), E_Stops.size(), gaiaPO.size(), blockageRatio * 100);
        GaiaNavigationTools.EncryptedQueryResult eqr;
        List<TokenNode> navigatedStops;
        synchronized (GaiaNavigationTools.class) {
            GaiaNavigationTools.Navigator navigator = new GaiaNavigationTools.Navigator(E_S, E_D, E_Stops, gaiaPO, apl,
                    i2i);
            eqr = navigator.run();
            navigatedStops = new ArrayList<>(navigator.sortedStops);
        }
        System.out.println("  导航排序后的途径点顺序: " +
                navigatedStops.stream().map(tn -> String.valueOf(tn.getId())).collect(Collectors.joining(" -> ")));
        stageEnd = System.currentTimeMillis();
        result.gaiaTotalTime = stageEnd - stageStart;
        System.out.printf("  导航完成: %d ms, 生成路径段: %d\n", result.gaiaTotalTime, eqr.getTriples().size());

         
        commStats.startResultDownload();  
        stageStart = System.currentTimeMillis();
        List<TokenNode> recoveredPath = recoverPath(E_S, E_D, navigatedStops, eqr, iterationCkks, fw, i2i, pph,
                tokenList, apl);
        stageEnd = System.currentTimeMillis();
        commStats.endResultDownload();  
        result.pathRecoveryTime = stageEnd - stageStart;
        System.out.printf("  路径恢复完成: %d ms, 恢复节点: %d\n", result.pathRecoveryTime, recoveredPath.size());

         
        stageStart = System.currentTimeMillis();
        List<TokenNode> navigationOrder = buildNavigationOrder(E_S, E_D, navigatedStops, eqr, recoveredPath);
        stageEnd = System.currentTimeMillis();
        result.pathConstructionTime = stageEnd - stageStart;
        System.out.printf("  路径构建完成: %d ms, 最终路径节点: %d\n", result.pathConstructionTime, navigationOrder.size());

         
        commStats.calculateDetailedForScenario(apl.size(), waypointCount, constraintPairs);
        commStats.printDetailedStats(apl.size(), waypointCount, constraintPairs);

        System.out.println("  📐 基于论文参数的通信代价公式:");
        System.out.println(commStats.getCommunicationFormula(apl.size(), waypointCount, constraintPairs));

        System.out.println("  🔍 开始计算性能指标...");
        calculateMetrics(result, plainQuery, navigationOrder, fw, i2i, eqr, navigatedStops, E_S, E_D,
                userPartialOrders, apl, ii2i);
        System.out.println("  ✅ 指标计算完成，验证结果:");
        System.out.printf("    距离偏差率: %.2f%%\n", result.distanceDeviationRate);
        System.out.printf("    阻塞绕行成功率: %.2f%%\n", result.blockageSuccessRate);
        System.out.printf("    偏序处理成功率: %.2f%%\n", result.partialOrderSuccessRate);
        System.out.printf("    实际总距离: %.2f\n", result.actualTotalDistance);
        System.out.printf("    最短路径距离: %.2f\n", result.shortestPathDistance);

         
        result.communicationStats = commStats;

         
        if (!reportGenerated) {
            System.out.println("  📄 生成通信分析报告...");
            CommunicationAnalysis.generateTechnicalCommunicationReport(RESULT_FILE,
                    RESULT_DIR + "\\technical_communication_report.md");
            CommunicationAnalysis.generateCommunicationTable(RESULT_DIR + "\\communication_estimates.csv");
            reportGenerated = true;
        }

        if (eqr.getTriples().isEmpty()) {
            System.out.println("  ⚠️ 警告: 导航返回空路径");
        } else {
            System.out.printf("  ✅ 导航成功: 生成 %d 个路径段\n", eqr.getTriples().size());
        }

        if (recoveredPath != null && !recoveredPath.isEmpty()) {
            System.out.printf("  ✅ 路径恢复成功: 恢复 %d 个节点\n", recoveredPath.size());
            String pathStr = recoveredPath.stream()
                    .map(tn -> String.valueOf(tn.getId()))
                    .collect(Collectors.joining(" → "));
            System.out.printf("  恢复路径: %s\n", pathStr);
        }

        return result;
    }

     
    private static List<PartialOrder> generatePartialOrders(ArrayList<Long> plainQuery, int constraintPairs) {
        List<PartialOrder> partialOrders = new ArrayList<>();

        if (constraintPairs <= 0 || plainQuery.size() < 3) {
            return partialOrders;
        }
        List<Long> waypoints = plainQuery.subList(1, plainQuery.size() - 1);
        if (waypoints.size() < 2) {
            return partialOrders;
        }
        int maxPossiblePairs = waypoints.size() * (waypoints.size() - 1);
        if (constraintPairs > maxPossiblePairs) {
            constraintPairs = maxPossiblePairs;
            System.out.printf("    ⚠️ 调整约束对数为理论最大值: %d\n", constraintPairs);
        }
        Random random = new Random();
        final int MAX_RETRIES = 20;

        int retryCount = 0;

        while (retryCount < MAX_RETRIES) {
            retryCount++;
            partialOrders.clear();
            Set<String> usedPairs = new HashSet<>();

            System.out.printf("    第 %d 次尝试生成约束...\n", retryCount);

            for (int i = 0; i < constraintPairs; i++) {
                int maxAttempts = 50;
                boolean found = false;
                Long pStId = null, sStId = null;

                for (int attempt = 0; attempt < maxAttempts && !found; attempt++) {
                    int idx1 = random.nextInt(waypoints.size());
                    int idx2 = random.nextInt(waypoints.size());

                    if (idx1 == idx2)
                        continue;

                    pStId = waypoints.get(idx1);
                    sStId = waypoints.get(idx2);

                    String pairKey = Math.min(pStId, sStId) + "-" + Math.max(pStId, sStId);
                    if (!usedPairs.contains(pairKey)) {
                        usedPairs.add(pairKey);

                        TokenNode pStToken = new TokenNode("", "", "", pStId);
                        TokenNode sStToken = new TokenNode("", "", "", sStId);
                        PartialOrder po = new PartialOrder(pStToken, sStToken);
                        partialOrders.add(po);
                        found = true;

                        System.out.printf("      随机约束 %d: %d → %d\n", i + 1, pStId, sStId);
                    }
                }

                if (!found) {
                    System.out.println("      警告: 无法生成新的约束对，可能途径点数量不足");
                    break;
                }
            }

            if (areConstraintsFeasible(partialOrders)) {
                System.out.printf("    ✅ 第 %d 次尝试生成可行的约束集: %d 对约束\n",
                        retryCount, partialOrders.size());
                return partialOrders;
            } else {
                System.out.printf("    ⚠️ 第 %d 次尝试约束不可行，重新生成\n", retryCount);
            }
        }

        System.out.printf("    ❌ 经过 %d 次尝试仍无法生成可行约束，返回空集\n", MAX_RETRIES);
        return new ArrayList<>();
    }

    private static void calculateMetrics(TestResult result,
            ArrayList<Long> plainQuery,
            List<TokenNode> navigationOrder,  
            Floyd_Warshall_1 fw,
            ConcurrentHashMap<Long, Integer> i2i,
            GaiaNavigationTools.EncryptedQueryResult eqr,
            List<TokenNode> navigatedStops,  
            TokenNode E_S, TokenNode E_D,
            List<PartialOrder> userPartialOrders,
            ConcurrentHashMap<Integer, node> apl,
            ConcurrentHashMap<Long, Long> ii2i) {

        try {
            System.out.println("\n  📊 开始计算全面性能指标 (Global Metrics)...");

             

             
            List<TokenNode> gaiaSequence = new ArrayList<>();
            gaiaSequence.add(E_S);
            if (navigatedStops != null)
                gaiaSequence.addAll(navigatedStops);
            gaiaSequence.add(E_D);

             
             
            List<TokenNode> optimalStops = findOptimalSequence(E_S, E_D, navigatedStops, userPartialOrders, fw, i2i);
            List<TokenNode> optimalSequence = new ArrayList<>();
            optimalSequence.add(E_S);
            optimalSequence.addAll(optimalStops);
            optimalSequence.add(E_D);

             

             
            double distGaiaBlocked = calculateTotalDistance(E_S, E_D, navigatedStops, fw, i2i, true);

             
            double distGaiaUnblocked = calculateTotalDistance(E_S, E_D, navigatedStops, fw, i2i, false);

             
            double distOptimalBlocked = calculateTotalDistance(E_S, E_D, optimalStops, fw, i2i, true);

             
            result.actualTotalDistance = distGaiaBlocked;
            result.gaiaPathOriginalDistance = distGaiaUnblocked;
            result.shortestPathDistance = distOptimalBlocked;

             
            if (distOptimalBlocked > 0) {
                result.distanceDeviationRate = ((distGaiaBlocked - distOptimalBlocked) / distOptimalBlocked) * 100.0;
                 
                if (result.distanceDeviationRate < 0 && result.distanceDeviationRate > -0.01)
                    result.distanceDeviationRate = 0;
            } else {
                result.distanceDeviationRate = 0;
            }

             

             
            if (distGaiaUnblocked > 0) {
                result.per_Original = distGaiaBlocked / distGaiaUnblocked;
            } else {
                result.per_Original = 1.0;
            }

             
            if (distOptimalBlocked > 0) {
                result.per_Optimal = distGaiaBlocked / distOptimalBlocked;
            } else {
                result.per_Optimal = 1.0;
            }

            System.out.printf("    📈 膨胀率(环境): %.2fx (Gaia阻塞/Gaia原始)\n", result.per_Original);
            System.out.printf("    📈 膨胀率(算法): %.2fx (Gaia阻塞/最优阻塞)\n", result.per_Optimal);

             

             

             
            List<Long> pathGaiaBlocked = restoreCompletePath(gaiaSequence, fw, true);

             
            List<Long> pathOptimalBlocked = restoreCompletePath(optimalSequence, fw, true);

             
            List<Long> pathGaiaUnblocked = restoreCompletePath(gaiaSequence, fw, false);

             

             
            result.ps_Optimal = calculateCombinedSimilarity(pathGaiaBlocked, pathOptimalBlocked,
                    distGaiaBlocked, distOptimalBlocked,
                    apl, i2i, ii2i);

             
            result.ps_Original = calculateCombinedSimilarity(pathGaiaBlocked, pathGaiaUnblocked,
                    distGaiaBlocked, distGaiaUnblocked,
                    apl, i2i, ii2i);

            System.out.printf("    🔄 相似度(vs最优): %.2f%%\n", result.ps_Optimal);
            System.out.printf("    🔄 相似度(vs原始): %.2f%%\n", result.ps_Original);

             
            calculateSuccessRates(result, fw, navigationOrder, i2i, userPartialOrders);

        } catch (Exception e) {
            System.err.println("  ❌ 指标计算失败: " + e.getMessage());
            e.printStackTrace();
            setDefaultMetrics(result);
        }
    }

     
    private static List<Long> restoreCompletePath(List<TokenNode> sequence, Floyd_Warshall_1 fw,
            boolean useBlockedMatrix) {
        List<Long> fullPath = new ArrayList<>();

        for (int i = 0; i < sequence.size() - 1; i++) {
            long fromId = sequence.get(i).getId();
            long toId = sequence.get(i + 1).getId();

            String pathStr;
             
            if (useBlockedMatrix) {
                pathStr = fw.getPathBetweenNodes(fromId, toId);
            } else {
                pathStr = fw.getOriginalPathBetweenNodes(fromId, toId);
            }

            List<Long> segment = parsePathNodes(pathStr);

             
            if (!segment.isEmpty()) {
                 
                if (i > 0 && !fullPath.isEmpty() && segment.get(0).equals(fullPath.get(fullPath.size() - 1))) {
                    segment.remove(0);
                }
                fullPath.addAll(segment);
            } else {
                 
                if (i == 0)
                    fullPath.add(fromId);
                 
                if (fullPath.isEmpty() || !fullPath.get(fullPath.size() - 1).equals(toId)) {
                    fullPath.add(toId);
                }
            }
        }
        return removeDuplicateNodesById(fullPath);
    }

     
    private static double calculateCombinedSimilarity(List<Long> path1, List<Long> path2,
            double dist1, double dist2,
            ConcurrentHashMap<Integer, node> apl,
            ConcurrentHashMap<Long, Integer> i2i,
            ConcurrentHashMap<Long, Long> ii2i) {
         
         
        double gridSim = calculateGridSimilarity(path1, path2, apl, i2i, ii2i);

         
        double lenSim = 0.5;  
        if (dist1 > 0 && dist2 > 0) {
            lenSim = Math.min(dist1, dist2) / Math.max(dist1, dist2);
        }

         
        return (gridSim * 0.7 + lenSim * 0.3) * 100.0;
    }

    /**
     * 暴力全排列寻找满足约束的最优途径点顺序
     */
    /**
     * 暴力全排列寻找满足约束的最优途径点顺序
     */
    private static List<TokenNode> findOptimalSequence(TokenNode s, TokenNode d, List<TokenNode> stops,
            List<PartialOrder> constraints, Floyd_Warshall_1 fw,
            ConcurrentHashMap<Long, Integer> i2i) {
        if (stops == null || stops.isEmpty())
            return new ArrayList<>();

        List<Integer> indices = new ArrayList<>();
        for (int i = 0; i < stops.size(); i++)
            indices.add(i);

        List<List<Integer>> perms = new ArrayList<>();
        generatePermutations(indices, 0, perms);

        double minDst = Double.MAX_VALUE;
        List<TokenNode> bestOrder = null;

        for (List<Integer> p : perms) {
            List<TokenNode> currentOrder = new ArrayList<>();
            for (int idx : p)
                currentOrder.add(stops.get(idx));

             
            if (isOrderValid(currentOrder, constraints)) {
                 
                 
                double dst = calculateTotalDistance(s, d, currentOrder, fw, i2i, true);
                if (dst < minDst) {
                    minDst = dst;
                    bestOrder = new ArrayList<>(currentOrder);
                }
            }
        }
         
        return bestOrder != null ? bestOrder : stops;
    }

    private static void generatePermutations(List<Integer> arr, int k, List<List<Integer>> res) {
        for (int i = k; i < arr.size(); i++) {
            Collections.swap(arr, i, k);
            generatePermutations(arr, k + 1, res);
            Collections.swap(arr, i, k);
        }
        if (k == arr.size() - 1)
            res.add(new ArrayList<>(arr));
    }

    private static boolean isOrderValid(List<TokenNode> order, List<PartialOrder> constraints) {
        if (constraints == null)
            return true;
        Map<Long, Integer> idxMap = new HashMap<>();
        for (int i = 0; i < order.size(); i++)
            idxMap.put(order.get(i).getId(), i);
        for (PartialOrder po : constraints) {
            long p = po.getPSt().getId();
            long s = po.getSSt().getId();
            if (idxMap.containsKey(p) && idxMap.containsKey(s)) {
                if (idxMap.get(p) > idxMap.get(s))
                    return false;
            }
        }
        return true;
    }

     
    private static double calculateTotalDistance(TokenNode s, TokenNode d, List<TokenNode> mids,
            Floyd_Warshall_1 fw, ConcurrentHashMap<Long, Integer> i2i,
            boolean useBlockedMatrix) {
        double total = 0;
        List<TokenNode> all = new ArrayList<>();
        all.add(s);
        if (mids != null)
            all.addAll(mids);
        all.add(d);

         
        double[][] blockedMatrix = fw.getGraph1();
        double[][] originalMatrix = fw.getOriginalGraph1();

         
        double[][] primaryMatrix = useBlockedMatrix ? blockedMatrix : originalMatrix;

        for (int i = 0; i < all.size() - 1; i++) {
            Integer u = i2i.get(all.get(i).getId());
            Integer v = i2i.get(all.get(i + 1).getId());

            if (u != null && v != null) {
                double dist = primaryMatrix[u][v];

                 
                if (dist >= 19000000.0) {
                    if (useBlockedMatrix) {
                         
                        double fallbackDist = originalMatrix[u][v];
                        if (fallbackDist < 19000000.0) {
                             
                             
                            total += fallbackDist;
                             
                        } else {
                             
                            return 20000000.0;
                        }
                    } else {
                        return 20000000.0;
                    }
                } else {
                    total += dist;
                }
                 
            }
        }
        return total;
    }

    private static void setDefaultMetrics(TestResult result) {
        result.distanceDeviationRate = 0;

         
        result.per_Original = 1.0;
        result.per_Optimal = 1.0;
        result.ps_Optimal = 0;
        result.ps_Original = 0;

        result.blockageSuccessRate = 0;
        result.partialOrderSuccessRate = 0;
         

        result.actualTotalDistance = 0;
        result.shortestPathDistance = 0;
        result.gaiaPathNodes = new ArrayList<>();
        result.shortestPathNodes = new ArrayList<>();
    }

    private static List<Long> restoreCompleteGaiaPath(TokenNode E_S, TokenNode E_D,
            List<TokenNode> navigatedStops,
            Floyd_Warshall_1 fw,
            ConcurrentHashMap<Integer, node> apl,
            ConcurrentHashMap<Long, Integer> i2i,
            ConcurrentHashMap<Long, Long> ii2i) {
        List<Long> completePath = new ArrayList<>();

        try {
            System.out.println("    🛠️  恢复完整Gaia路径（处理后矩阵）...");

            List<TokenNode> keyNodes = new ArrayList<>();
            keyNodes.add(E_S);
            if (navigatedStops != null) {
                keyNodes.addAll(navigatedStops);
            }
            keyNodes.add(E_D);

            System.out.printf("    🔑 关键节点序列(%d个): %s\n", keyNodes.size(),
                    keyNodes.stream().map(tn -> String.valueOf(tn.getId())).collect(Collectors.joining(" → ")));

            for (int i = 0; i < keyNodes.size() - 1; i++) {
                TokenNode from = keyNodes.get(i);
                TokenNode to = keyNodes.get(i + 1);

                System.out.printf("    📍 处理路径段 %d: %d → %d\n", i + 1, from.getId(), to.getId());

                String segmentPath = fw.getPathBetweenNodes(from.getId(), to.getId());
                List<Long> segmentNodes = parsePathNodes(segmentPath);

                double segmentDistance = fw.getDistanceBetweenNodes(from.getId(), to.getId());
                System.out.printf("      段距离: %.2f %s\n", segmentDistance,
                        segmentDistance < 20000000.0 ? "✅" : "❌");

                if (segmentNodes.isEmpty() || segmentDistance >= 20000000.0) {
                    System.out.printf("    ⚠️  路径段 %d→%d 不连通，直接连接\n", from.getId(), to.getId());
                    if (i == 0) {
                        completePath.add(from.getId());
                    }
                    completePath.add(to.getId());
                    continue;
                }

                if (!segmentNodes.get(0).equals(from.getId())) {
                    segmentNodes.add(0, from.getId());
                }
                if (!segmentNodes.get(segmentNodes.size() - 1).equals(to.getId())) {
                    segmentNodes.add(to.getId());
                }

                if (i == 0) {
                    completePath.addAll(segmentNodes);
                    System.out.printf("      ✅ 添加第一段: %d个节点\n", segmentNodes.size());
                } else {
                    if (segmentNodes.size() > 1) {
                        completePath.addAll(segmentNodes.subList(1, segmentNodes.size()));
                        System.out.printf("      ✅ 添加后续段: %d个节点\n", segmentNodes.size() - 1);
                    } else {
                        completePath.addAll(segmentNodes);
                        System.out.printf("      ✅ 添加单节点段: %d个节点\n", segmentNodes.size());
                    }
                }
            }

            List<Long> deduplicatedPath = removeDuplicateNodesById(completePath);

            System.out.printf("    ✅ Gaia完整路径恢复完成: %d → %d节点 (去重后)\n",
                    completePath.size(), deduplicatedPath.size());

            return deduplicatedPath;

        } catch (Exception e) {
            System.err.println("    ❌ 恢复完整Gaia路径失败: " + e.getMessage());
            List<Long> fallbackPath = new ArrayList<>();
            fallbackPath.add(E_S.getId());
            if (navigatedStops != null) {
                fallbackPath.addAll(navigatedStops.stream().map(TokenNode::getId).collect(Collectors.toList()));
            }
            fallbackPath.add(E_D.getId());
            return fallbackPath;
        }
    }

    private static List<Long> getCompleteOriginalPath(TokenNode E_S, TokenNode E_D, Floyd_Warshall_1 fw) {
        try {
            System.out.println("    🗺️  获取完整预处理路径（处理后矩阵）...");

            String pathStr = fw.getPathBetweenNodes(E_S.getId(), E_D.getId());
            List<Long> path = parsePathNodes(pathStr);

            if (path.isEmpty() || path.size() < 2) {
                System.out.println("    ⚠️ 处理后路径为空，尝试原始路径作为fallback");
                pathStr = fw.getOriginalPathBetweenNodes(E_S.getId(), E_D.getId());
                path = parsePathNodes(pathStr);
            }

            if (path.isEmpty() || path.size() < 2) {
                System.out.println("    ❌ 所有路径获取方法都失败，创建直连路径");
                path = new ArrayList<>();
                path.add(E_S.getId());
                path.add(E_D.getId());
            }

            System.out.printf("    ✅ 预处理路径获取完成: %d个节点\n", path.size());

            boolean isConnected = validatePathConnectivity(path, fw);
            System.out.printf("    🔗 路径连通性: %s\n", isConnected ? "✅ 连通" : "❌ 不连通");

            return path;

        } catch (Exception e) {
            System.err.println("    ❌ 获取预处理路径失败: " + e.getMessage());
            List<Long> fallbackPath = new ArrayList<>();
            fallbackPath.add(E_S.getId());
            fallbackPath.add(E_D.getId());
            return fallbackPath;
        }
    }

    private static boolean validatePathConnectivity(List<Long> path, Floyd_Warshall_1 fw) {
        if (path.size() < 2)
            return false;

        for (int i = 0; i < path.size() - 1; i++) {
            double distance = fw.getDistanceBetweenNodes(path.get(i), path.get(i + 1));
            if (distance >= 20000000.0 - 1) {
                System.out.printf("      ❌ 段 %d→%d 不连通: %.2f\n",
                        path.get(i), path.get(i + 1), distance);
                return false;
            }
        }
        return true;
    }

    private static double calculateGridSimilarity(List<Long> path1, List<Long> path2,
            ConcurrentHashMap<Integer, node> apl,
            ConcurrentHashMap<Long, Integer> i2i,
            ConcurrentHashMap<Long, Long> ii2i) {

        try {
            System.out.println("    🗂️  计算网格相似度...");

            double gridSize = 50.0;

            Map<String, Integer> gridCount1 = mapPathToGrid(path1, apl, i2i, gridSize, ii2i);
            Map<String, Integer> gridCount2 = mapPathToGrid(path2, apl, i2i, gridSize, ii2i);

            System.out.printf("    📊 网格统计: 路径1=%d网格, 路径2=%d网格\n",
                    gridCount1.size(), gridCount2.size());

            Set<String> allGrids = new HashSet<>();
            allGrids.addAll(gridCount1.keySet());
            allGrids.addAll(gridCount2.keySet());

            if (allGrids.isEmpty()) {
                System.out.println("    ⚠️  无网格数据，返回默认相似度");
                return 0.5;
            }

             
            List<Integer> vector1 = new ArrayList<>();
            List<Integer> vector2 = new ArrayList<>();

            for (String grid : allGrids) {
                vector1.add(gridCount1.getOrDefault(grid, 0));
                vector2.add(gridCount2.getOrDefault(grid, 0));
            }

            double cosineSimilarity = calculateCosineSimilarity(vector1, vector2);
            System.out.printf("    ✅ 网格相似度: %.4f\n", cosineSimilarity);
            return cosineSimilarity;

        } catch (Exception e) {
            System.err.println("    ❌ 网格相似度计算失败: " + e.getMessage());
            return 0;
        }
    }

    private static Map<String, Integer> mapPathToGrid(List<Long> path,
            ConcurrentHashMap<Integer, node> apl,
            ConcurrentHashMap<Long, Integer> i2i,
            double gridSize,
            ConcurrentHashMap<Long, Long> ii2i) {  

        Map<String, Integer> gridCount = new HashMap<>();
        int mappedNodes = 0;
        int failedNodes = 0;

        for (Long nodeId : path) {
            try {
                node nd = findNodeById(nodeId, apl, i2i, ii2i);
                if (nd != null) {
                    int gridX = (int) Math.floor(nd.x / gridSize);
                    int gridY = (int) Math.floor(nd.y / gridSize);
                    String gridKey = gridX + "," + gridY;
                    gridCount.put(gridKey, gridCount.getOrDefault(gridKey, 0) + 1);
                    mappedNodes++;
                } else {
                    failedNodes++;
                }
            } catch (Exception e) {
                failedNodes++;
            }
        }

        System.out.printf("      网格映射: 成功=%d, 失败=%d, 总网格=%d\n",
                mappedNodes, failedNodes, gridCount.size());

        return gridCount;
    }

    private static node findNodeById(Long nodeId, ConcurrentHashMap<Integer, node> apl,
            ConcurrentHashMap<Long, Integer> i2i,
            ConcurrentHashMap<Long, Long> ii2i) {

         
        if (nodeId < 10000 && ii2i != null) {
            Long actualNodeId = ii2i.get(nodeId);
            if (actualNodeId != null) {
                Integer idx = i2i.get(actualNodeId);
                if (idx != null) {
                    node nd = apl.get(idx);
                    if (nd != null) {
                        return nd;
                    }
                }
            }
        }

         
        Integer idx = i2i.get(nodeId);
        if (idx != null) {
            node nd = apl.get(idx);
            if (nd != null) {
                return nd;
            }
        }

         
        if (nodeId < Integer.MAX_VALUE) {
            int potentialIdx = nodeId.intValue();
            node nd = apl.get(potentialIdx);
            if (nd != null) {
                return nd;
            }
        }

        return null;
    }

    private static double calculateCosineSimilarity(List<Integer> vector1, List<Integer> vector2) {
        if (vector1.size() != vector2.size()) {
            throw new IllegalArgumentException("向量长度必须相同");
        }

        double dotProduct = 0;
        double norm1 = 0;
        double norm2 = 0;

        for (int i = 0; i < vector1.size(); i++) {
            dotProduct += vector1.get(i) * vector2.get(i);
            norm1 += Math.pow(vector1.get(i), 2);
            norm2 += Math.pow(vector2.get(i), 2);
        }

        if (norm1 == 0 || norm2 == 0) {
            return 0;
        }

        return dotProduct / (Math.sqrt(norm1) * Math.sqrt(norm2));
    }

    private static List<Long> removeDuplicateNodesById(List<Long> path) {
        List<Long> result = new ArrayList<>();
        Set<Long> seen = new HashSet<>();

        for (Long nodeId : path) {
            if (seen.add(nodeId)) {
                result.add(nodeId);
            }
        }

        return result;
    }

     
    private static void calculateSuccessRates(TestResult result,
            Floyd_Warshall_1 fw,
            List<TokenNode> navigationOrder,
            ConcurrentHashMap<Long, Integer> i2i,
            List<PartialOrder> userPartialOrders) {
        try {
            int blockageSuccessCount = 0;
            int blockageTotalCount = 0;
            int partialOrderSuccessCount = 0;
            int partialOrderTotalCount = userPartialOrders.size();

            double[][] distMatrix = fw.getGraph1();
            for (int i = 0; i < navigationOrder.size() - 1; i++) {
                TokenNode from = navigationOrder.get(i);
                TokenNode to = navigationOrder.get(i + 1);

                Integer fromIdx = i2i.get(from.getId());
                Integer toIdx = i2i.get(to.getId());

                if (fromIdx != null && toIdx != null) {
                    if (fw.isBlocked(fromIdx, toIdx)) {
                        blockageTotalCount++;

                        if (distMatrix[fromIdx][toIdx] < 20000000.0) {
                            blockageSuccessCount++;
                        }
                    }
                }
            }
            System.out.println("    🔍 偏序约束满足情况详细分析:");
            for (int i = 0; i < userPartialOrders.size(); i++) {
                PartialOrder po = userPartialOrders.get(i);
                long pStId = po.getPSt().getId();
                long sStId = po.getSSt().getId();

                boolean pStInPath = navigationOrder.stream().anyMatch(tn -> tn.getId() == pStId);
                boolean sStInPath = navigationOrder.stream().anyMatch(tn -> tn.getId() == sStId);

                boolean isSatisfied = isPartialOrderSatisfied(navigationOrder, pStId, sStId);

                if (isSatisfied) {
                    partialOrderSuccessCount++;
                    if (pStInPath && sStInPath) {
                        System.out.printf("      ✅ 约束%d满足: %d → %d (两节点都在路径中且顺序正确)\n",
                                i + 1, pStId, sStId);
                    } else if (!pStInPath && !sStInPath) {
                        System.out.printf("      ✅ 约束%d满足: %d → %d (两节点都不在路径中)\n",
                                i + 1, pStId, sStId);
                    } else if (!pStInPath) {
                        System.out.printf("      ✅ 约束%d满足: %d → %d (前驱不在路径中)\n",
                                i + 1, pStId, sStId);
                    } else {
                        System.out.printf("      ✅ 约束%d满足: %d → %d (后继不在路径中)\n",
                                i + 1, pStId, sStId);
                    }
                } else {
                    if (pStInPath && sStInPath) {
                        System.out.printf("      ❌ 约束%d违反: %d → %d (两节点都在路径中但顺序错误)\n",
                                i + 1, pStId, sStId);
                    } else if (pStInPath) {
                        System.out.printf("      ❌ 约束%d违反: %d → %d (前驱在路径中但后继不在)\n",
                                i + 1, pStId, sStId);
                    } else {
                        System.out.printf("      ❌ 约束%d违反: %d → %d (其他违反情况)\n",
                                i + 1, pStId, sStId);
                    }
                }
            }

             
            result.blockageSuccessRate = blockageTotalCount > 0
                    ? (double) blockageSuccessCount / blockageTotalCount * 100
                    : 100;
            result.partialOrderSuccessRate = partialOrderTotalCount > 0
                    ? (double) partialOrderSuccessCount / partialOrderTotalCount * 100
                    : 100;

            System.out.printf("    ✅ 阻塞绕行成功率: %.2f%% (%d/%d)\n",
                    result.blockageSuccessRate, blockageSuccessCount, blockageTotalCount);
            System.out.printf("    ✅ 偏序处理成功率: %.2f%% (%d/%d)\n",
                    result.partialOrderSuccessRate, partialOrderSuccessCount, partialOrderTotalCount);

        } catch (Exception e) {
            System.err.println("    ❌ 成功率计算失败: " + e.getMessage());
            result.blockageSuccessRate = 0;
            result.partialOrderSuccessRate = 0;
        }
    }

     
    private static boolean isPartialOrderSatisfied(List<TokenNode> path, long pStId, long sStId) {
         
        List<TokenNode> uniquePath = removeDuplicateNodes(path);

        int pStIndex = -1;
        int sStIndex = -1;

         
        for (int i = 0; i < uniquePath.size(); i++) {
            long currentId = uniquePath.get(i).getId();
            if (currentId == pStId) {
                pStIndex = i;
            }
            if (currentId == sStId) {
                sStIndex = i;
            }
        }

        System.out.printf("      偏序检查详细: 约束 %d→%d\n", pStId, sStId);
        System.out.printf("        路径: %s\n",
                uniquePath.stream().map(tn -> String.valueOf(tn.getId())).collect(Collectors.joining(" → ")));
        System.out.printf("        前驱 %d 位置=%d, 后继 %d 位置=%d\n", pStId, pStIndex, sStId, sStIndex);

        if (pStIndex != -1 && sStIndex != -1) {
            boolean satisfied = pStIndex < sStIndex;
            System.out.printf("        结果: %s (前驱%s后继)\n",
                    satisfied ? "✅ 满足" : "❌ 违反",
                    satisfied ? "在" : "不在");
            return satisfied;
        }

        System.out.printf("        结果: ✅ 满足 (节点不全在路径中: 前驱%s, 后继%s)\n",
                (pStIndex == -1 ? "不在" : "在"),
                (sStIndex == -1 ? "不在" : "在"));
        return true;
    }

    private static List<TokenNode> validateAndCompletePath(List<TokenNode> currentPath,
            List<TokenNode> navigatedStops,
            Floyd_Warshall_1 fw,
            ConcurrentHashMap<Long, Integer> i2i) {

        List<TokenNode> completePath = removeDuplicateNodes(currentPath);

        Set<Long> currentNodes = completePath.stream()
                .map(TokenNode::getId)
                .collect(Collectors.toSet());

        int addedStops = 0;
        for (TokenNode stop : navigatedStops) {
            if (!currentNodes.contains(stop.getId())) {
                System.out.printf("    ➕ 补充缺失途径点: %d\n", stop.getId());

                int insertPosition = findInsertPositionByNavigationOrder(stop, completePath, navigatedStops);
                if (insertPosition != -1) {
                    completePath.add(insertPosition, stop);
                    addedStops++;
                    currentNodes.add(stop.getId());
                } else {
                    completePath.add(completePath.size() - 1, stop);
                    addedStops++;
                    currentNodes.add(stop.getId());
                }
            }
        }

        if (addedStops > 0) {
            System.out.printf("    ✅ 补充了 %d 个缺失途径点\n", addedStops);
        }
        return removeDuplicateNodes(completePath);
    }

    private static int findInsertPositionByNavigationOrder(TokenNode nodeToInsert,
            List<TokenNode> currentPath,
            List<TokenNode> navigatedStops) {

        int nodeIndexInNavOrder = -1;
        for (int i = 0; i < navigatedStops.size(); i++) {
            if (navigatedStops.get(i).getId() == nodeToInsert.getId()) {
                nodeIndexInNavOrder = i;
                break;
            }
        }

        if (nodeIndexInNavOrder == -1) {
            return -1;
        }

        for (int i = nodeIndexInNavOrder - 1; i >= 0; i--) {
            TokenNode prevNode = navigatedStops.get(i);
            for (int j = 0; j < currentPath.size(); j++) {
                if (currentPath.get(j).getId() == prevNode.getId()) {
                    return j + 1;
                }
            }
        }

        for (int i = nodeIndexInNavOrder + 1; i < navigatedStops.size(); i++) {
            TokenNode nextNode = navigatedStops.get(i);
            for (int j = 0; j < currentPath.size(); j++) {
                if (currentPath.get(j).getId() == nextNode.getId()) {
                    return j;
                }
            }
        }

        return -1;
    }

     
    private static void rebuildEncGraphMapping(ArrayList<TokenNode> tokenList, CKKSHelper ckks) throws Exception {
        System.out.println("  重建EncGraph映射...");
        EncGraph.nodeSet.clear();
        System.out.println("    已清空现有EncGraph映射");
        int successCount = 0;
        int failCount = 0;

        for (TokenNode tn : tokenList) {
            try {
                if (tn.xEnc == null || tn.yEnc == null) {
                    System.out.println("    ⚠️ TokenNode " + tn.getId() + " 缺少加密坐标，跳过");
                    failCount++;
                    continue;
                }

                EncNode encNode = new EncNode(tn.xEnc, tn.yEnc, tn);

                EncNode existing = EncGraph.nodeSet.putIfAbsent(tn, encNode);

                if (existing != null) {
                    System.out.println("    ⚠️ TokenNode " + tn.getId() + " 已存在映射，使用现有映射");
                } else {
                    successCount++;
                }

            } catch (Exception e) {
                System.err.println("    ❌ 创建EncNode失败: " + tn.getId() + " - " + e.getMessage());
                failCount++;
            }
        }

        System.out.println("    映射重建完成: 成功=" + successCount + ", 失败=" + failCount);
    }

     
    private static void validateEncGraphMapping(ArrayList<TokenNode> tokenList) {
        System.out.println("  验证EncGraph映射完整性...");

        int mappedCount = 0;
        int missingCount = 0;

        for (TokenNode tn : tokenList) {
            EncNode encNode = EncGraph.nodeSet.get(tn);

            if (encNode == null) {
                System.out.println("    ❌ TokenNode " + tn.getId() + " 在EncGraph中缺失映射");
                missingCount++;

                boolean foundById = false;
                long targetId = tn.getId();

                for (TokenNode key : EncGraph.nodeSet.keySet()) {
                    if (key.getId() == targetId) {
                        System.out.println("    🔍 通过ID找到匹配: " + key.getId());
                        foundById = true;
                        break;
                    }
                }

                if (!foundById) {
                    System.out.println("    ❌ 无法通过ID找到匹配的TokenNode");
                }
            } else {
                mappedCount++;
            }
        }

        System.out.println("    映射验证结果: 已映射=" + mappedCount + ", 缺失=" + missingCount);
        System.out.println("    EncGraph总映射数: " + EncGraph.nodeSet.size());

        if (missingCount > 0) {
            throw new RuntimeException("EncGraph映射不完整，缺失 " + missingCount + " 个节点的映射");
        }
    }

    private static boolean preValidateNavigation(TokenNode E_S, TokenNode E_D, List<TokenNode> E_Stops) {
        System.out.println("  导航预验证...");

        try {
             
            if (EncGraph.nodeSet.get(E_S) == null) {
                System.out.println("    ❌ 起点在EncGraph中缺失映射");
                return false;
            }
            if (EncGraph.nodeSet.get(E_D) == null) {
                System.out.println("    ❌ 终点在EncGraph中缺失映射");
                return false;
            }

            if (E_Stops == null || E_Stops.isEmpty()) {
                System.out.println("    ⚠️ 途径点列表为空，但这是允许的");
                return true;
            }

            for (TokenNode stop : E_Stops) {
                if (EncGraph.nodeSet.get(stop) == null) {
                    System.out.println("    ❌ 途径点 " + stop.getId() + " 在EncGraph中缺失映射");
                    return false;
                }
            }

             
            StopSet[] groupingResult = EncNavigationTools.SecureGrouping(E_S, E_D, new ArrayList<>(E_Stops));

            if (groupingResult == null || groupingResult.length < 3) {
                System.out.println("    ❌ SecureGrouping返回无效结果");
                return false;
            }

            if (groupingResult[0].isEmpty() && groupingResult[1].isEmpty() && groupingResult[2].isEmpty()) {
                System.out.println("    ⚠️ SecureGrouping返回全空分组，但这是允许的");
            }

            int totalNodes = groupingResult[0].size() + groupingResult[1].size() + groupingResult[2].size();
            System.out.println("    SecureGrouping预测试: 总分组节点=" + totalNodes);

            return true;

        } catch (Exception e) {
            System.err.println("    ❌ 导航预验证失败: " + e.getMessage());
            return false;
        }
    }

     
    private static ArrayList<Long> generateRobustRandomPath(ConcurrentHashMap<Integer, node> apl,
            int waypointCount,
            Floyd_Warshall_1 fw,
            ConcurrentHashMap<Long, Integer> i2i) {
        ArrayList<Long> path = new ArrayList<>();
        Random random = new Random();
        List<Long> robustNodes = getRobustNodes(apl, fw, i2i);

        if (robustNodes.size() < waypointCount + 2) {
            System.out.println("  警告: 健壮节点不足，使用所有节点");
            robustNodes = getAllNodes(apl);
        }

        Set<Long> used = new HashSet<>();
        path.add(robustNodes.get(random.nextInt(robustNodes.size())));
        used.add(path.get(0));

        for (int i = 0; i < waypointCount; i++) {
            Long node;
            int attempts = 0;
            do {
                node = robustNodes.get(random.nextInt(robustNodes.size()));
                attempts++;
                if (attempts > 100) {
                     
                    for (Long n : robustNodes) {
                        if (!used.contains(n)) {
                            node = n;
                            break;
                        }
                    }
                    break;
                }
            } while (used.contains(node));

            path.add(node);
            used.add(node);
        }

         
        Long endNode;
        do {
            endNode = robustNodes.get(random.nextInt(robustNodes.size()));
        } while (used.contains(endNode));
        path.add(endNode);

        System.out.println("  生成健壮路径: " + path);
        return path;
    }

    private static List<Long> getRobustNodes(ConcurrentHashMap<Integer, node> apl,
            Floyd_Warshall_1 fw,
            ConcurrentHashMap<Long, Integer> i2i) {
        List<Long> robustNodes = new ArrayList<>();

        for (int i = 0; i < apl.size(); i++) {
            node nd = apl.get(i);
            if (nd != null) {
                if (nd.Neb != null && nd.Neb.size() >= 2) {
                    robustNodes.add(nd.id);
                }
            }
        }

        if (robustNodes.isEmpty()) {
            robustNodes = getAllNodes(apl);
        }

        System.out.println("  健壮节点数量: " + robustNodes.size());
        return robustNodes;
    }

    private static List<Long> getAllNodes(ConcurrentHashMap<Integer, node> apl) {
        List<Long> allNodes = new ArrayList<>();
        for (int i = 0; i < apl.size(); i++) {
            node nd = apl.get(i);
            if (nd != null) {
                allNodes.add(nd.id);
            }
        }
        return allNodes;
    }

    private static List<TokenNode> recoverPath(TokenNode E_S, TokenNode E_D,
            List<TokenNode> navigatedStops,
            GaiaNavigationTools.EncryptedQueryResult eqr,
            CKKSHelper ckks, Floyd_Warshall_1 fw, ConcurrentHashMap<Long, Integer> i2i,
            PRF_PRP_Hash pph, ArrayList<TokenNode> tokenList,
            ConcurrentHashMap<Integer, node> apl) {  

        List<TokenNode> recoveredPath = new ArrayList<>();
        recoveredPath.add(E_S);

        try {
            System.out.println("  🔍 开始路径恢复...");

            ensureNodeInIndexMapping(E_S, i2i, fw, apl);
            ensureNodeInIndexMapping(E_D, i2i, fw, apl);

            int recoveredSegments = 0;
            for (GaiaNavigationTools.EncryptedPathTriple triple : eqr.getTriples()) {
                TokenNode recoveredNode = triple.getESt();
                if (isValidNode(recoveredNode)) {
                    ensureNodeInIndexMapping(recoveredNode, i2i, fw, apl);
                    recoveredPath.add(recoveredNode);
                    recoveredSegments++;

                    System.out.println("      ✅ 恢复节点: " + recoveredNode.getId() +
                            " (映射: " + i2i.get(recoveredNode.getId()) + ")");
                }
            }

            recoveredPath.add(E_D);
            System.out.printf("    基础恢复完成: %d 个路径段\n", recoveredSegments);

            List<TokenNode> deduplicatedPath = removeDuplicateNodes(recoveredPath);
            System.out.printf("    去重后路径: %d → %d 个节点\n", recoveredPath.size(), deduplicatedPath.size());

            String basePathStr = deduplicatedPath.stream()
                    .map(tn -> String.valueOf(tn.getId()))
                    .collect(Collectors.joining(" → "));
            System.out.println("    基础恢复路径: " + basePathStr);

            List<TokenNode> completePath = validateAndCompletePath(deduplicatedPath, navigatedStops, fw, i2i);

            boolean isValid = validatePathDistancesEnhanced(completePath, fw, i2i, ckks);
            if (!isValid) {
                System.out.println("  ⚠️  路径距离验证失败，但继续使用恢复的路径");
            }

            List<TokenNode> finalPath = removeDuplicateNodes(completePath);

            validateFinalPathOrder(finalPath, E_S, E_D, navigatedStops);

            System.out.printf("  ✅ 路径恢复完成: %d 个节点 (去重后)\n", finalPath.size());

            String finalPathStr = finalPath.stream()
                    .map(tn -> String.valueOf(tn.getId()))
                    .collect(Collectors.joining(" → "));
            System.out.println("    最终路径: " + finalPathStr);

            return finalPath;

        } catch (Exception e) {
            System.err.println("  ❌ 路径恢复失败: " + e.getMessage());
            return removeDuplicateNodes(recoveredPath);
        }
    }

    private static void validateFinalPathOrder(List<TokenNode> finalPath,
            TokenNode E_S, TokenNode E_D, List<TokenNode> navigatedStops) {
        System.out.println("    🔍 验证最终路径顺序:");

         
        int startIndex = -1;
        int endIndex = -1;
        for (int i = 0; i < finalPath.size(); i++) {
            if (finalPath.get(i).getId() == E_S.getId()) {
                startIndex = i;
            }
            if (finalPath.get(i).getId() == E_D.getId()) {
                endIndex = i;
            }
        }

        boolean startEndCorrect = startIndex < endIndex;
        System.out.printf("      起点 %d[位置%d] → 终点 %d[位置%d]: %s\n",
                E_S.getId(), startIndex, E_D.getId(), endIndex,
                startEndCorrect ? "✅ 正确" : "❌ 错误");

        if (!startEndCorrect) {
            System.out.println("      ⚠️ 警告：路径顺序可能被反转！");
        }
    }

    private static List<TokenNode> removeDuplicateNodes(List<TokenNode> path) {
        List<TokenNode> result = new ArrayList<>();
        Set<Long> seen = new HashSet<>();

        for (TokenNode node : path) {
            if (node != null && seen.add(node.getId())) {  
                result.add(node);
            }
        }
        return result;
    }

    private static boolean isValidNode(TokenNode node) {
        if (node == null)
            return false;
        Long id = node.getId();
        return id != null && id > 0;
    }

    private static List<TokenNode> buildNavigationOrder(TokenNode E_S, TokenNode E_D,
            List<TokenNode> navigatedStops,
            GaiaNavigationTools.EncryptedQueryResult eqr,
            List<TokenNode> recoveredPath) {

        long startTime = System.currentTimeMillis();

        try {
            System.out.println("  🛣️  开始路径构建...");

            List<TokenNode> navigationOrder = removeDuplicateNodes(recoveredPath);

            String inputPathStr = navigationOrder.stream()
                    .map(tn -> String.valueOf(tn.getId()))
                    .collect(Collectors.joining(" → "));
            System.out.println("    输入路径: " + inputPathStr);
            if (!validatePathContinuity(navigationOrder)) {
                System.out.println("  ⚠️  路径连续性验证失败，重新排序");
                navigationOrder = reorderPath(navigationOrder);
            }

            navigationOrder = removeDuplicateNodes(navigationOrder);

            if (navigationOrder.size() < 2) {
                throw new RuntimeException("路径节点数量不足");
            }

            String outputPathStr = navigationOrder.stream()
                    .map(tn -> String.valueOf(tn.getId()))
                    .collect(Collectors.joining(" → "));
            System.out.println("    输出路径: " + outputPathStr);

            long endTime = System.currentTimeMillis();
            System.out.printf("  ✅ 路径构建完成: %d ms, %d 个节点 (已去重)\n",
                    (endTime - startTime), navigationOrder.size());

            return navigationOrder;

        } catch (Exception e) {
            System.err.println("  ❌ 路径构建失败: " + e.getMessage());
            List<TokenNode> simplePath = new ArrayList<>();
            simplePath.add(E_S);
            simplePath.addAll(navigatedStops);
            simplePath.add(E_D);
            return removeDuplicateNodes(simplePath);
        }
    }

     
    private static boolean validatePathContinuity(List<TokenNode> path) {
        if (path.size() < 2)
            return false;

        for (int i = 0; i < path.size() - 1; i++) {
            if (path.get(i) == null || path.get(i + 1) == null) {
                return false;
            }
            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
            }
        }
        return true;
    }

     
    private static List<TokenNode> reorderPath(List<TokenNode> path) {
        List<TokenNode> sorted = path.stream()
                .filter(Objects::nonNull)
                .sorted(Comparator.comparing(TokenNode::getId))
                .collect(Collectors.toList());
        try {
            Thread.sleep(5);
        } catch (InterruptedException e) {
        }

        return sorted;
    }

     
     
    private static class TestResult {
        long mapLoadingTime;
        long floydTotalTime;
        long ckksTotalTime;
        long tokenGenerationTime;
        long gaiaTotalTime;
        long pathRecoveryTime;
        long pathConstructionTime;

        double distanceDeviationRate;  

         
        double per_Original;  
        double per_Optimal;  

        double ps_Optimal;  
        double ps_Original;  

        double blockageSuccessRate;
        double partialOrderSuccessRate;

        double actualTotalDistance;  
        double gaiaPathOriginalDistance;  
        double shortestPathDistance;  

        List<Long> gaiaPathNodes = new ArrayList<>();
        List<Long> shortestPathNodes = new ArrayList<>();
        CommunicationStats communicationStats;
    }

     
    private static CKKSHelper initializeCKKS() throws Exception {
        CKKSHelper ckks = new CKKSHelper(2, 4, 10, 20);
        String basePath = "D:\\Gaia\\src\\main\\resources";
        ckks.loadContext(basePath);
        ckks.loadPublicKeys(basePath);
        ckks.loadSecretKey(basePath);
        ckks.getSecretKey().set_K(GetSKFromJson(basePath + "\\pphsk.json"));

        if (ckks.getPublicKeys() == null) {
            throw new IllegalStateException("CKKS 公钥加载失败");
        }
        if (ckks.getSecretKey() == null) {
            throw new IllegalStateException("CKKS 私钥加载失败");
        }

        return ckks;
    }

     
    private static ArrayList<Long> generateRandomPath(ConcurrentHashMap<Integer, node> apl, int waypointCount) {
        ArrayList<Long> path = new ArrayList<>();
        Random random = new Random();
        Set<Long> usedNodes = new HashSet<>();

        if (apl.isEmpty()) {
            throw new RuntimeException("地图节点列表为空");
        }

        List<Long> availableNodes = new ArrayList<>();
        for (int i = 0; i < apl.size(); i++) {
            if (apl.get(i) != null) {
                availableNodes.add(apl.get(i).id);
            }
        }

        if (availableNodes.size() < waypointCount + 2) {
            throw new RuntimeException("可用节点数量不足");
        }

        Long startNode = availableNodes.get(random.nextInt(availableNodes.size()));
        path.add(startNode);
        usedNodes.add(startNode);

        for (int i = 0; i < waypointCount; i++) {
            Long nodeId;
            int attempts = 0;
            do {
                nodeId = availableNodes.get(random.nextInt(availableNodes.size()));
                attempts++;
                if (attempts > 50) {
                    for (Long candidate : availableNodes) {
                        if (!usedNodes.contains(candidate)) {
                            nodeId = candidate;
                            break;
                        }
                    }
                    break;
                }
            } while (usedNodes.contains(nodeId));

            path.add(nodeId);
            usedNodes.add(nodeId);
        }

        Long endNode;
        int attempts = 0;
        do {
            endNode = availableNodes.get(random.nextInt(availableNodes.size()));
            attempts++;
            if (attempts > 50) {
                for (int j = availableNodes.size() - 1; j >= 0; j--) {
                    Long candidate = availableNodes.get(j);
                    if (!usedNodes.contains(candidate)) {
                        endNode = candidate;
                        break;
                    }
                }
                break;
            }
        } while (usedNodes.contains(endNode));

        path.add(endNode);

        System.out.printf("  生成路径: %s\n", path.stream()
                .map(String::valueOf)
                .collect(Collectors.joining(" → ")));

        return path;
    }

    private static List<Long> parsePathNodes(String path) {
        List<Long> nodes = new ArrayList<>();
        if (path == null || path.isEmpty() || path.equals("原地踏步")) {
            return nodes;
        }

        try {
            String[] parts = path.split("->");
            for (String part : parts) {
                part = part.trim();
                if (!part.isEmpty()) {
                    if (part.matches("\\d+")) {
                        nodes.add(Long.parseLong(part));
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("    解析路径节点失败: " + path + " - " + e.getMessage());
        }

        return nodes;
    }

    private static boolean areConstraintsFeasible(List<PartialOrder> partialOrders) {
        if (partialOrders.isEmpty()) {
            return true;
        }

         
        Map<Long, List<Long>> graph = new HashMap<>();
        Map<Long, Integer> inDegree = new HashMap<>();

         
        for (PartialOrder po : partialOrders) {
            Long from = po.getPSt().getId();
            Long to = po.getSSt().getId();

            graph.putIfAbsent(from, new ArrayList<>());
            graph.putIfAbsent(to, new ArrayList<>());
            inDegree.putIfAbsent(from, 0);
            inDegree.putIfAbsent(to, 0);
        }

         
        for (PartialOrder po : partialOrders) {
            Long from = po.getPSt().getId();
            Long to = po.getSSt().getId();

            graph.get(from).add(to);
            inDegree.put(to, inDegree.get(to) + 1);
        }

         
        Queue<Long> queue = new LinkedList<>();
        int visitedCount = 0;

         
        for (Long node : inDegree.keySet()) {
            if (inDegree.get(node) == 0) {
                queue.offer(node);
            }
        }

         
        while (!queue.isEmpty()) {
            Long current = queue.poll();
            visitedCount++;

            if (graph.containsKey(current)) {
                for (Long neighbor : graph.get(current)) {
                    inDegree.put(neighbor, inDegree.get(neighbor) - 1);
                    if (inDegree.get(neighbor) == 0) {
                        queue.offer(neighbor);
                    }
                }
            }
        }

         
        boolean isFeasible = visitedCount == graph.size();
        System.out.printf("      约束可行性检查: 节点%d/节点%d -> %s\n",
                visitedCount, graph.size(), isFeasible ? "可行" : "有环");
        return isFeasible;
    }

    private static void ensureNodeInIndexMapping(TokenNode node,
            ConcurrentHashMap<Long, Integer> i2i, Floyd_Warshall_1 fw,
            ConcurrentHashMap<Integer, node> apl) {

        if (!i2i.containsKey(node.getId())) {
            System.out.println("    🔧 修复节点索引映射: " + node.getId());

             
            for (Map.Entry<Integer, node> entry : apl.entrySet()) {
                if (entry.getValue() != null && entry.getValue().id == node.getId()) {
                    i2i.put(node.getId(), entry.getKey());
                    System.out.println("      ✅ 通过apl找到映射: " + node.getId() + " -> " + entry.getKey());
                    return;
                }
            }

             
            if (node.getId() < 2000 && node.getId() >= 0) {
                i2i.put(node.getId(), (int) node.getId());
                System.out.println("      ✅ 节点ID作为索引: " + node.getId() + " -> " + node.getId());
                return;
            }

             
            for (TokenNode existingNode : EncGraph.nodeSet.keySet()) {
                if (existingNode.getId() == node.getId()) {
                     
                    for (Map.Entry<Integer, node> entry : apl.entrySet()) {
                        if (entry.getValue() != null && entry.getValue().id == node.getId()) {
                            i2i.put(node.getId(), entry.getKey());
                            System.out.println("      ✅ 通过EncGraph+apl找到映射: " + node.getId() + " -> " + entry.getKey());
                            return;
                        }
                    }
                    break;
                }
            }

            System.out.println("      ❌ 无法修复节点映射: " + node.getId());
        }
    }

    private static boolean validatePathDistancesEnhanced(List<TokenNode> path,
            Floyd_Warshall_1 fw,
            ConcurrentHashMap<Long, Integer> i2i,
            CKKSHelper ckks) {
        try {
            double totalDistance = 0;
            double[][] distMatrix = fw.getGraph1();
            int validSegments = 0;
            int invalidSegments = 0;
            int missingIndexSegments = 0;

            System.out.println("    🔍 增强路径验证:");

            for (int i = 0; i < path.size() - 1; i++) {
                TokenNode from = path.get(i);
                TokenNode to = path.get(i + 1);

                Integer fromIdx = i2i.get(from.getId());
                Integer toIdx = i2i.get(to.getId());

                if (fromIdx != null && toIdx != null) {
                    double segmentDistance = distMatrix[fromIdx][toIdx];
                    if (segmentDistance >= 0 && segmentDistance < 100000) {
                        totalDistance += segmentDistance;
                        validSegments++;
                        System.out.printf("      ✅ 段 %d->%d: 距离=%.2f\n",
                                from.getId(), to.getId(), segmentDistance);
                    } else {
                        System.out.printf("      ⚠️  段 %d->%d 距离异常: %.2f\n",
                                from.getId(), to.getId(), segmentDistance);
                        invalidSegments++;
                    }
                } else {
                    System.out.printf("      ⚠️  段 %d->%d 节点索引缺失 (fromIdx=%s, toIdx=%s)\n",
                            from.getId(), to.getId(), fromIdx, toIdx);
                    missingIndexSegments++;
                }
            }

            System.out.printf("    📏 路径验证统计: 有效=%d, 异常=%d, 缺失索引=%d, 总计=%d\n",
                    validSegments, invalidSegments, missingIndexSegments, path.size() - 1);

            double validRatio = (double) validSegments / (path.size() - 1);
            System.out.printf("    📊 有效段比例: %.1f%%\n", validRatio * 100);

            return validRatio >= 0.3;

        } catch (Exception e) {
            System.err.println("    ❌ 距离验证异常: " + e.getMessage());
            return true;
        }
    }
}