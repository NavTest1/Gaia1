package ckks;

public class SecretKey {
    private Polynomial s;
    private String k1,k2,k3,k4,k5;
    public SecretKey() {
    }

    public SecretKey(Polynomial s) {
        this.s = s;
    }

    public Polynomial getS() {
        return s;
    }

    public long[] serialize() {
        return s.serialize();
    }

    public void deserialize(Context context, long[] serialization) {
        s = new Polynomial();
        s.deserialize(context, serialization);
    }
    public void set_K(String[]ak){
        k1=ak[0];
        k2=ak[1];
        k3=ak[2];
        k4=ak[3];
        k5=ak[4];
    }

    public String[] getHash64(){
        return new String[]{k1,k2,k3,k4,k5};
    }
}
