package ckks;

public class CKKSExample {
    public static void main(String[] args) {
        // 初始化CKKS参数
        int slots = 2;  // 只使用2个槽位
        int multiplications = 2;  // 支持的乘法次数
        int integerPrecision = 10;  // 整数部分精度
        int fractionalPrecision = 20;  // 小数部分精度

        // 创建上下文
        Context context = new Context(slots, multiplications, integerPrecision, fractionalPrecision);

        // 生成密钥
        KeyGenerator keyGenerator = new KeyGenerator(context);
        SecretKey secretKey = keyGenerator.getSecretKey();
        PublicKeys publicKeys = keyGenerator.getPublicKeys();

        // 创建加密器、解密器和评估器
        Encryptor encryptor = new Encryptor(context, publicKeys);
        Decryptor decryptor = new Decryptor(secretKey);
        Evaluator evaluator = new Evaluator(context, publicKeys);
        Encoder encoder = new Encoder(context);

        // 创建测试数据
        Complex[] data1 = new Complex[slots];
        Complex[] data2 = new Complex[slots];
        
        // 填充测试数据
        data1[0] = new Complex(2.5, 0.0);  // 第一个数：6
        data1[1] = new Complex(0.0, 0.0);  // 第二个槽位不使用
        
        data2[0] = new Complex(6.5, 0.0);  // 第二个数：2
        data2[1] = new Complex(0.0, 0.0);  // 第二个槽位不使用

        // 编码数据
        Plaintext plaintext1 = new Plaintext(context);
        Plaintext plaintext2 = new Plaintext(context);
        encoder.encode(data1, plaintext1);
        encoder.encode(data2, plaintext2);

        // 加密数据
        Ciphertext ciphertext1 = new Ciphertext(context);
        Ciphertext ciphertext2 = new Ciphertext(context);
        encryptor.encrypt(plaintext1, ciphertext1);
        encryptor.encrypt(plaintext2, ciphertext2);

        // 执行同态运算
        // 1. 加法
        Ciphertext sum = evaluator.add(ciphertext1, ciphertext2);
        
        // 2. 减法
        Ciphertext diff = evaluator.add(ciphertext1, evaluator.mult(ciphertext2, -1));
        
        // 3. 乘法
        Ciphertext product = evaluator.mult(ciphertext1, ciphertext2);
        evaluator.relinearize_inplace(product);  // 重线性化
        evaluator.rescale_inplace(product);      // 重缩放

        // 4. 除法 (通过乘以倒数实现)
        Complex[] inverseData2 = new Complex[slots];
        inverseData2[0] = new Complex(1.0/data2[0].re, 0.0);
        inverseData2[1] = new Complex(0.0, 0.0);
        Plaintext inversePlaintext2 = new Plaintext(context);
        encoder.encode(inverseData2, inversePlaintext2);
        Ciphertext inverseCiphertext2 = new Ciphertext(context);
        encryptor.encrypt(inversePlaintext2, inverseCiphertext2);
        
        Ciphertext quotient = evaluator.mult(ciphertext1, inverseCiphertext2);
        evaluator.relinearize_inplace(quotient);
        evaluator.rescale_inplace(quotient);

        // 解密结果
        Plaintext decryptedSum = new Plaintext(context);
        Plaintext decryptedDiff = new Plaintext(context);
        Plaintext decryptedProduct = new Plaintext(context);
        Plaintext decryptedQuotient = new Plaintext(context);
        
        decryptor.decrypt(sum, decryptedSum);
        decryptor.decrypt(diff, decryptedDiff);
        decryptor.decrypt(product, decryptedProduct);
        decryptor.decrypt(quotient, decryptedQuotient);

        // 解码结果
        Complex[] decodedSum = encoder.decode(decryptedSum);
        Complex[] decodedDiff = encoder.decode(decryptedDiff);
        Complex[] decodedProduct = encoder.decode(decryptedProduct);
        Complex[] decodedQuotient = encoder.decode(decryptedQuotient);

        // 打印结果
        System.out.println("CKKS同态加密测试示例");
        System.out.println("====================");
        System.out.printf("第一个数: %.2f\n", data1[0].re);
        System.out.printf("第二个数: %.2f\n", data2[0].re);
        System.out.println("--------------------");
        System.out.printf("同态加法结果: %.2f\n", decodedSum[0].re);
        System.out.printf("同态减法结果: %.2f\n", decodedDiff[0].re);
        System.out.printf("同态乘法结果: %.2f\n", decodedProduct[0].re);
        System.out.printf("同态除法结果: %.2f\n", decodedQuotient[0].re);
        System.out.println("====================");
    }
} 