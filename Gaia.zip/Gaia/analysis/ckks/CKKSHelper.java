package ckks;

import lombok.Getter;
import lombok.Setter;

import java.io.*;

@Setter
@Getter
public class CKKSHelper {
    private Context context;
    private KeyGenerator keyGenerator;
    private SecretKey secretKey;
    private PublicKeys publicKeys;
    private Encryptor encryptor;
    private Decryptor decryptor;
    private Evaluator evaluator;
    private Encoder encoder;

    /**
     * 构造函数
     * @param slots 槽数（必须是2的幂）
     * @param multiplications 支持的乘法次数
     * @param integerPrecision 整数部分精度
     * @param fractionalPrecision 小数部分精度
     */
    public CKKSHelper(int slots, int multiplications, int integerPrecision, int fractionalPrecision) {
        // 初始化上下文
        context = new Context(slots, multiplications, integerPrecision, fractionalPrecision);

        // 生成密钥
        keyGenerator = new KeyGenerator(context);
        secretKey = keyGenerator.getSecretKey();
        publicKeys = keyGenerator.getPublicKeys();

        // 初始化各个组件
        encryptor = new Encryptor(context, publicKeys);
        decryptor = new Decryptor(secretKey);
        evaluator = new Evaluator(context, publicKeys);
        encoder = new Encoder(context);
    }

    /**
     * 设置私钥
     * @param secretKey 私钥
     */
    public void SetSecretKey(SecretKey secretKey) {
        this.secretKey = secretKey;
        // 重新初始化解密器
        decryptor = new Decryptor(secretKey);
    }

    /**
     * 加密单个实数
     * @param value 要加密的实数
     * @return 加密后的密文
     */
    public Ciphertext encrypt(double value) {
        Complex[] data = new Complex[context.getNumSlots()];
        data[0] = new Complex(value, 0.0);
        for (int i = 1; i < data.length; i++) {
            data[i] = new Complex(0.0, 0.0);
        }

        Plaintext plaintext = new Plaintext(context);
        encoder.encode(data, plaintext);

        Ciphertext ciphertext = new Ciphertext(context);
        encryptor.encrypt(plaintext, ciphertext);
        return ciphertext;
    }

    /**
     * 解密单个实数
     * @param ciphertext 要解密的密文
     * @return 解密后的实数
     */
    public double decrypt(Ciphertext ciphertext) {
        Plaintext plaintext = new Plaintext(context);
        decryptor.decrypt(ciphertext, plaintext);
        Complex[] decoded = encoder.decode(plaintext);
        return decoded[0].re;
    }

    /**
     * 解密单个实数 - 新增方法，解决decryptDouble未定义的问题
     * @param ciphertext 要解密的密文
     * @return 解密后的实数
     */
    public double decryptDouble(Ciphertext ciphertext) {
        return decrypt(ciphertext);
    }

    /**
     * 同态加法
     * @param a 第一个密文
     * @param b 第二个密文
     * @return 加法结果的密文
     */
    public Ciphertext add(Ciphertext a, Ciphertext b) {
        // 如果两个密文的缩放因子不一致，通过乘法调整
        if (a.getScale() != b.getScale()) {
            Ciphertext one = encrypt(1.0);
            Ciphertext b_adjusted = multiply(b, one);
            return evaluator.add(a, b_adjusted);
        }
        return evaluator.add(a, b);
    }

    /**
     * 同态减法
     * @param a 第一个密文
     * @param b 第二个密文
     * @return 减法结果的密文
     */
    public Ciphertext subtract(Ciphertext a, Ciphertext b) {
        return evaluator.add(a, evaluator.mult(b, -1));
    }

    /**
     * 同态乘法
     * @param a 第一个密文
     * @param b 第二个密文
     * @return 乘法结果的密文
     */
    public Ciphertext multiply(Ciphertext a, Ciphertext b) {
        Ciphertext result = evaluator.mult(a, b);
        evaluator.relinearize_inplace(result);  // 重线性化
        evaluator.rescale_inplace(result);      // 重缩放
        return result;
    }

    /**
     * 同态除法
     * @param a 第一个密文
     * @param b 第二个密文
     * @return 除法结果的密文
     */
    public Ciphertext divide(Ciphertext a, Ciphertext b) {
        // 获取b的倒数
        double bValue = decrypt(b);
        if (bValue == 0) {
            throw new ArithmeticException("除数不能为0");
        }
        Ciphertext inverseB = encrypt(1.0 / bValue);

        // 执行乘法
        return evaluator.mult(a, inverseB);
    }

    /**
     * 保存公钥到本地文件
     * @param directoryPath 保存目录的路径
     * @throws IOException 如果文件操作失败
     */
    public void savePublicKeys(String directoryPath) throws IOException {
        // 确保目录存在
        File directory = new File(directoryPath);
        if (!directory.exists()) {
            directory.mkdirs();
        }

        // 序列化公钥
        long[] serializedKeys = publicKeys.serialize();

        // 保存到文件
        String publicKeyPath = directoryPath + File.separator + "public_keys.bin";
        try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(publicKeyPath))) {
            // 首先写入数组长度
            dos.writeInt(serializedKeys.length);
            // 然后写入所有数据
            for (long value : serializedKeys) {
                dos.writeLong(value);
            }
        }
    }

    /**
     * 从本地文件加载公钥
     * @param directoryPath 公钥文件所在的目录路径
     * @throws IOException 如果文件操作失败
     */
    public void loadPublicKeys(String directoryPath) throws IOException {
        String publicKeyPath = directoryPath + File.separator + "public_keys.bin";
        try (DataInputStream dis = new DataInputStream(new FileInputStream(publicKeyPath))) {
            // 读取数组长度
            int length = dis.readInt();
            // 读取所有数据
            long[] serializedKeys = new long[length];
            for (int i = 0; i < length; i++) {
                serializedKeys[i] = dis.readLong();
            }

            // 反序列化公钥
            publicKeys = new PublicKeys();
            publicKeys.deserialize(context, serializedKeys);

            // 重新初始化加密器和评估器
            encryptor = new Encryptor(context, publicKeys);
            evaluator = new Evaluator(context, publicKeys);
        }
    }

    public void SetPublicKeys(PublicKeys publicKeys) throws IOException {
        this.publicKeys = publicKeys;

        // 重新初始化加密器和评估器
        encryptor = new Encryptor(context, this.publicKeys);
        evaluator = new Evaluator(context, this.publicKeys);
    }

    /**
     * 保存私钥到本地文件
     * @param directoryPath 保存目录的路径
     * @throws IOException 如果文件操作失败
     */
    public void saveSecretKey(String directoryPath) throws IOException {
        // 确保目录存在
        File directory = new File(directoryPath);
        if (!directory.exists()) {
            directory.mkdirs();
        }

        // 序列化私钥
        long[] serializedKey = secretKey.serialize();

        // 保存到文件
        String secretKeyPath = directoryPath + File.separator + "secret_key.bin";
        try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(secretKeyPath))) {
            // 首先写入数组长度
            dos.writeInt(serializedKey.length);
            // 然后写入所有数据
            for (long value : serializedKey) {
                dos.writeLong(value);
            }
        }
    }

    /**
     * 从本地文件加载私钥
     * @param directoryPath 私钥文件所在的目录路径
     * @throws IOException 如果文件操作失败
     */
    public void loadSecretKey(String directoryPath) throws IOException {
        String secretKeyPath = directoryPath + File.separator + "secret_key.bin";
        try (DataInputStream dis = new DataInputStream(new FileInputStream(secretKeyPath))) {
            // 读取数组长度
            int length = dis.readInt();
            // 读取所有数据
            long[] serializedKey = new long[length];
            for (int i = 0; i < length; i++) {
                serializedKey[i] = dis.readLong();
            }

            // 反序列化私钥
            secretKey = new SecretKey();
            secretKey.deserialize(context, serializedKey);

            // 重新初始化解密器
            decryptor = new Decryptor(secretKey);
        }
    }

    public void saveContext(String directoryPath) throws IOException {
        // 确保目录存在
        File directory = new File(directoryPath);
        if (!directory.exists()) {
            directory.mkdirs();
        }

        // 序列化上下文
        long[] serializedContext = context.serialize();

        // 保存到文件
        String contextPath = directoryPath + File.separator + "context.bin";
        try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(contextPath))) {
            // 首先写入数组长度
            dos.writeInt(serializedContext.length);
            // 然后写入所有数据
            for (long value : serializedContext) {
                dos.writeLong(value);
            }
        }
    }

    public void loadContext(String directoryPath) throws IOException {
        String contextPath = directoryPath + File.separator + "context.bin";
        try (DataInputStream dis = new DataInputStream(new FileInputStream(contextPath))) {
            // 读取数组长度
            int length = dis.readInt();
            // 读取所有数据
            long[] serializedContext = new long[length];
            for (int i = 0; i < length; i++) {
                serializedContext[i] = dis.readLong();
            }

            // 反序列化上下文
            context = new Context();
            context.deserialize(serializedContext);

            // 重新初始化编码器
            encoder = new Encoder(context);
        }
    }

    public void SetContext(Context context) throws IOException {
        this.context = context;
        encoder = new Encoder(context);
    }

    /**
     * 测试函数
     */
    public static void main(String[] args) {
        // 创建CKKS实例
        CKKSHelper ckks = new CKKSHelper(4, 32, 20, 40);

        // 设置保存路径
        String savePath = "D:\\docter\\Hermers-code\\JAVA-CKKS\\Java-CKKS-main";

        System.out.println("\nCKKS上下文和密钥保存加载测试");
        System.out.println("====================");

        try {
            // 保存上下文、公钥和私钥
            System.out.println("\n正在保存上下文、公钥和私钥...");
            ckks.saveContext(savePath);
            ckks.savePublicKeys(savePath);
            ckks.saveSecretKey(savePath);
            System.out.println("保存成功！");

            // 创建一个新的CKKS实例用于测试加载
            CKKSHelper ckks2 = new CKKSHelper(4, 32, 20, 40);

            // 加载上下文、公钥和私钥
            System.out.println("\n正在加载上下文、公钥和私钥...");
            ckks2.loadContext(savePath);
            ckks2.loadPublicKeys(savePath);
            ckks2.loadSecretKey(savePath);
            System.out.println("加载成功！");

            // 测试基本加密解密
            System.out.println("\n测试基本加密解密...");
            double testValue = 3.14159;
            Ciphertext ciphertext = ckks2.encrypt(testValue);
            double decrypted = ckks.decrypt(ciphertext);
            System.out.printf("原始值: %10.8f\n", testValue);
            System.out.printf("解密值: %10.8f\n", decrypted);
            System.out.printf("误差: %10.8f\n", Math.abs(testValue - decrypted));

            // 测试同态运算
            System.out.println("\n测试同态运算...");
            double a = 2;
            double b = 3;

            // 加密两个数
            Ciphertext cipherA = ckks2.encrypt(a);
            Ciphertext cipherB = ckks2.encrypt(b);

            // 测试加法
            Ciphertext sum = ckks2.add(cipherA, cipherB);
            double decryptedSum = ckks2.decrypt(sum);
            System.out.printf("同态加法: %.2f + %.2f = %.8f (期望值: %.2f)\n",
                    a, b, decryptedSum, a + b);

            // 测试减法
            Ciphertext diff = ckks2.subtract(cipherA, cipherB);
            double decryptedDiff = ckks2.decrypt(diff);
            System.out.printf("同态减法: %.2f - %.2f = %.8f (期望值: %.2f)\n",
                    a, b, decryptedDiff, a - b);

            // 测试乘法
            Ciphertext product = ckks2.multiply(cipherA, cipherB);
            double decryptedProduct = ckks2.decrypt(product);
            System.out.printf("同态乘法: %.2f * %.2f = %.8f (期望值: %.2f)\n",
                    a, b, decryptedProduct, a * b);

            // 测试除法
            Ciphertext quotient = ckks2.divide(cipherA, cipherB);
            double decryptedQuotient = ckks2.decrypt(quotient);
            System.out.printf("同态除法: %.2f / %.2f = %.8f (期望值: %.8f)\n",
                    a, b, decryptedQuotient, a / b);

            // 测试连续运算
            System.out.println("\n测试连续运算...");
            double x = 1.5;
            double y = 2.5;
            double z = 3.5;

            Ciphertext cipherX = ckks2.encrypt(x);
            Ciphertext cipherY = ckks2.encrypt(y);
            Ciphertext cipherZ = ckks2.encrypt(z);

            // 计算 (x + y) * z
            Ciphertext sumXY = ckks2.add(cipherX, cipherY);
            Ciphertext result = ckks2.multiply(sumXY, cipherZ);
            double decryptedResult = ckks2.decrypt(result);
            System.out.printf("连续运算 (%.2f + %.2f) * %.2f = %.8f (期望值: %.2f)\n",
                    x, y, z, decryptedResult, (x + y) * z);

        } catch (IOException e) {
            System.out.println("发生错误：" + e.getMessage());
            e.printStackTrace();
        }

        System.out.println("\n====================");
    }
}