package analysis;

import java.io.*;
import java.util.*;

/**
 * 基于论文参数的通信代价分析
 */
public class CommunicationAnalysis {
    
    /**
     * 生成基于论文参数的通信代价分析报告
     */
    public static void generateTechnicalCommunicationReport(String resultFile, String reportFile) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(reportFile))) {
            writer.println("=== Gaia系统通信代价技术分析报告 ===");
            writer.println("基于论文: Privacy-Preserving and Efficient Navigation Service");
            writer.println("生成时间: " + new Date());
            writer.println();
            
            writer.println("## 1. 密码学参数配置 (基于Table II)");
            writer.println();
            writer.println("| 参数 | 符号 | 大小 | 说明 |");
            writer.println("|------|------|------|------|");
            writer.println("| 公钥长度 | |pk| | 1024 bits | RSA公钥 |");
            writer.println("| 私钥长度 | |sk₁|,|sk₂|,|sk₃|,|sk₄| | 512 bits | 四个私钥组件 |");
            writer.println("| PRP长度 | |PRP| | 256 bits | 伪随机置换 |");
            writer.println("| 哈希函数 | |H₁| | 256 bits | SHA-256 |");
            writer.println("| 随机预言机 | |H₂| | 256 bits | HMAC-SHA256 |");
            writer.println("| 随机数 | |r| | 64 bits | 安全比较 |");
            writer.println("| PRF | F | 256 bits | HMAC-based |");
            writer.println();
            
            writer.println("## 2. 通信代价公式推导");
            writer.println();
            writer.println("### 2.1 加密图上传");
            writer.println("- 组件: 公钥 + 加密节点坐标");
            writer.println("- 大小: |pk| + N × 2 × |密文|");
            writer.println("- 估算: 128 + N × 2 × 2048 bytes");
            writer.println();
            
            writer.println("### 2.2 令牌上传");
            writer.println("- 组件: 起点 + 终点 + k个途径点的加密令牌");
            writer.println("- 大小: (2 + k) × (2 × |密文| + 64)");
            writer.println("- 估算: (2 + k) × 4160 bytes");
            writer.println();
            
            writer.println("### 2.3 结果下载");
            writer.println("- 组件: 加密路径结果");
            writer.println("- 大小: 基础路径 + k个途径段");
            writer.println("- 估算: 2 × |密文| + k × (|密文| + 128)");
            writer.println();
            
            writer.println("### 2.4 交互数据 (GC协议)");
            writer.println("- 组件: FastGC电路交互");
            writer.println("- 大小: 基础轮次 + 约束相关轮次");
            writer.println("- 估算: 2 × 4096 + c × 2048 bytes");
            writer.println();
            
            writer.println("## 3. 最终通信代价公式");
            writer.println();
            writer.println("```");
            writer.println("Total_Comm(N, k, c) = [128 + 4096N] + [8320 + 4160k] + [4096 + 2176k] + [8192 + 2048c]");
            writer.println("                    = 20736 + 4096N + 6336k + 2048c (bytes)");
            writer.println("                    ≈ (20.25 + 4N + 6.19k + 2c) KB");
            writer.println("```");
            writer.println();
            writer.println("其中:");
            writer.println("- N: 道路交叉点数量 (节点数)");
            writer.println("- k: 无序站点数量 (途径点数)");
            writer.println("- c: 偏序约束对数");
            writer.println();
            
            writer.println("## 4. 典型场景分析");
            writer.println();
            writer.println("| 场景 | N | k | c | 估算通信量 |");
            writer.println("|------|----|----|----|------------|");
            writer.println("| 小规模 | 400 | 5 | 2 | ≈ 1.8 MB |");
            writer.println("| 中规模 | 1000 | 10 | 5 | ≈ 4.5 MB |");
            writer.println("| 大规模 | 2200 | 20 | 10 | ≈ 9.8 MB |");
            writer.println();
            
            writer.println("## 5. 技术实现细节");
            writer.println();
            writer.println("### 5.1 加密方案");
            writer.println("- 基于复合阶有限群的双线性映射 [Boneh et al.]");
            writer.println("- 使用JPBC库实现密码学原语");
            writer.println("- 使用jPBC进行加密预处理");
            writer.println();
            
            writer.println("### 5.2 安全比较");
            writer.println("- 基于FastGC构建安全比较电路");
            writer.println("- 消息空间: {0,1}^M with M < q/2");
            writer.println("- 使用足够大的随机数r确保正确解密");
            writer.println();
            
            writer.println("### 5.3 性能优化建议");
            writer.println("1. **批处理操作**: 对多个节点坐标进行批量加密");
            writer.println("2. **压缩技术**: 对密文数据进行压缩传输");
            writer.println("3. **缓存策略**: 重复使用已加密的地图数据");
            writer.println("4. **协议优化**: 减少GC协议的交互轮数");
            
            System.out.println("✅ 技术通信分析报告已生成: " + reportFile);
            
        } catch (Exception e) {
            System.err.println("❌ 生成技术通信报告失败: " + e.getMessage());
        }
    }
    
    /**
     * 生成通信量估算表
     */
    public static void generateCommunicationTable(String tableFile) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(tableFile))) {
            writer.println("N,k,c,加密图(KB),令牌(KB),结果(KB),交互(KB),总计(KB),总计(MB)");
            
            int[] nodeCounts = {400, 1000, 2200};
            int[] waypointCounts = {5, 10, 20};
            int[] constraintPairs = {2, 5, 10};
            
            for (int N : nodeCounts) {
                for (int k : waypointCounts) {
                    for (int c : constraintPairs) {
                        // 计算各组件大小
                        double graphKB = (128 + 4096 * N) / 1024.0;
                        double tokenKB = (8320 + 4160 * k) / 1024.0;
                        double resultKB = (4096 + 2176 * k) / 1024.0;
                        double interactionKB = (8192 + 2048 * c) / 1024.0;
                        double totalKB = graphKB + tokenKB + resultKB + interactionKB;
                        double totalMB = totalKB / 1024.0;
                        
                        writer.printf("%d,%d,%d,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f%n",
                            N, k, c, graphKB, tokenKB, resultKB, interactionKB, totalKB, totalMB);
                    }
                }
            }
            
            System.out.println("✅ 通信量估算表已生成: " + tableFile);
            
        } catch (Exception e) {
            System.err.println("❌ 生成通信量表失败: " + e.getMessage());
        }
    }
}