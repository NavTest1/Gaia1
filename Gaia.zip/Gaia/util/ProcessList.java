package util;
import Class.TokenNode;

import java.util.ArrayList;

public class ProcessList {
    public static TokenNode[]getTokenList(ArrayList<TokenNode> token){
        TokenNode[]res=new TokenNode[token.size()-2];
        ArrayList<TokenNode> res1 = new ArrayList<>(token);
        res1.remove(token.size()-1);
        res1.remove(0);
        res1.toArray(res);
        return res;
    }
}
