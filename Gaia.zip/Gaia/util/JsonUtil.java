package util;

import Omega.SK;
import User.Arrnode;
import Class.*;
import ckks.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.SneakyThrows;
import org.apache.commons.codec.binary.Base64;

import java.io.*;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;


public class JsonUtil {
    public static String readJsonFile(String fileName) {
        String jsonStr = "";
        try {
            File jsonFile = new File(fileName);
            FileReader fileReader = new FileReader(jsonFile);
            Reader reader = new InputStreamReader(new FileInputStream(jsonFile), StandardCharsets.UTF_8);
            int ch = 0;
            StringBuffer sb = new StringBuffer();
            while ((ch = reader.read()) != -1) {
                sb.append((char) ch);
            }
            fileReader.close();
            reader.close();
            jsonStr = sb.toString();
            return jsonStr;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static ArrayList<node> getNodeList(String fileName, ConcurrentHashMap<Long, Integer> Id2Index, ConcurrentHashMap<Long, Long> inI2I, ConcurrentHashMap<Long, Long> outI2I) {
        ArrayList<node> res = new ArrayList<>();
//        ConcurrentHashMap<Integer,node> res = new ConcurrentHashMap<>();
        String jsonString = readJsonFile(fileName);
        ObjectMapper mapper = new ObjectMapper();
        SecureRandom rng = new SecureRandom(new byte[8]);
        try {
            JsonNode rootNode = mapper.readTree(jsonString);
            Iterator<ConcurrentHashMap.Entry<String, JsonNode>> it = rootNode.fields();
            Iterator<String> tmpIt = rootNode.fieldNames();
            HashSet<String> tmpSet = new HashSet<>();
            tmpIt.forEachRemaining(tmpSet::add);
            double xmax = -1000.0, ymax = -1000.0, xmin = 1000.0, ymin = 1000.0;
            while (it.hasNext()) {
                JsonNode JSvalue = it.next().getValue();
                JsonNode LON = JSvalue.get("LON");
                double lon = Double.parseDouble(LON.asText());
                xmax = Math.max(xmax, lon);
                xmin = Math.min(xmin, lon);
                JsonNode LAT = JSvalue.get("LAT");
                double lat = Double.parseDouble(LAT.asText());
                ymax = Math.max(ymax, lat);
                ymin = Math.min(ymin, lat);
            }
            double xone = (xmax - xmin) / 1000.0;
            double yone = (ymax - ymin) / 1000.0;
            int index = 0;

            var it1 = rootNode.fields();
            while (it1.hasNext()) {
                long tmp = Long.parseLong(it1.next().getKey());
                Id2Index.put(tmp, index++);
                long tl;
                do {
                    tl = rng.nextLong();
                } while (new BigInteger(String.valueOf(tl)).toByteArray().length != 8);
                inI2I.put(tmp, tl);
                outI2I.put(tl, tmp);
            }
            var it2 = rootNode.fields();
            while (it2.hasNext()) {
                node tmpNode = new node();

                ConcurrentHashMap.Entry<String, JsonNode> next = it2.next();
                if (next.getValue() == null || next.getKey() == null) {
                    break;
                }
                long id = Long.parseLong(next.getKey());
                JsonNode JSvalue = next.getValue();
                if (JSvalue == null) {
                    continue;
                }
                JsonNode LON = JSvalue.get("LON");
                JsonNode LAT = JSvalue.get("LAT");
                JsonNode neighbor = JSvalue.get("Neighbor");
                JsonNode distance = JSvalue.get("Distance");
                double x = Double.parseDouble(LON.asText());
                double y = Double.parseDouble(LAT.asText());
                int xi = (int) ((x - xmin) / xone);
                int yi = (int) ((y - ymin) / yone);

                int len = neighbor.size();

                ArrayList<Double> tmpd = new ArrayList<>();
                ArrayList<Integer> tmpn = new ArrayList<>();
                for (int i = 0; i < len; i++) {
                    if (!tmpSet.contains(neighbor.get(i).asText())) {
                        continue;
                    }
                    double dis = Double.parseDouble(distance.get(i).asText());
                    tmpd.add(dis);
                    tmpn.add(Id2Index.get(Long.parseLong(neighbor.get(i).asText())));
                }
                tmpNode.Dis = tmpd;
                tmpNode.Neb = tmpn;
                tmpNode.x = xi;
                tmpNode.y = yi;
                tmpNode.id = id;
                tmpNode.index = Id2Index.get(id);
                res.add(tmpNode);
            }


        } catch (JsonProcessingException e) {
            e.printStackTrace();

        }
        return res;

    }

    //    public static ArrayList<TokenNode>getTokens(String fileName){
//        ArrayList<TokenNode>res=new ArrayList<>();
//        return res;
//    }
//    @SneakyThrows
//    public static ConcurrentHashMap<BigInteger, byte[]> getDX(String fileName) {
//        String s = readJsonFile(fileName);
//        ObjectMapper mapper = new ObjectMapper();
//        ConcurrentHashMap<BigInteger, byte[]> res = new ConcurrentHashMap<>();
//        res = mapper.readValue(s, new TypeReference<ConcurrentHashMap<BigInteger, byte[]>>() {
//        });
//        return res;
//    }

//    @SneakyThrows
//    public static ArrayList<Arr> getArrList(String fileName) {
//        String s = readJsonFile(fileName);
//        ObjectMapper mapper = new ObjectMapper();
//        ArrayList<Arr> res = new ArrayList<>();
//        res = mapper.readValue(s, new TypeReference<ArrayList<Arr>>() {
//        });
//        return res;
//    }

    @SneakyThrows
    public static void testReadArrList(String fileName) {
        String jsonFile = readJsonFile(fileName);
        ObjectMapper mapper = new ObjectMapper();
        JsonNode root = mapper.readTree(jsonFile);
        ConcurrentHashMap<Integer, Arrnode>[] res = new ConcurrentHashMap[root.size()];
        Iterator<Map.Entry<String, JsonNode>> itRoot = root.fields();
        while (itRoot.hasNext()) {
            Map.Entry<String, JsonNode> next = itRoot.next();
            int key = Integer.parseInt(next.getKey());
            JsonNode value = next.getValue();
            ConcurrentHashMap<Integer, Arrnode> arr = new ConcurrentHashMap<>();
            value.fields().forEachRemaining(ele -> {
                int i = Integer.parseInt(ele.getKey());
                JsonNode eleValue = ele.getValue();
                JsonNode first = eleValue.get("first");
                JsonNode second = eleValue.get("second");
                byte[] BytesFirst = Base64.decodeBase64(first.asText());
                BigInteger bigIntegerSecond = new BigInteger(second.asText());
                Arrnode arrnode = new Arrnode(BytesFirst, bigIntegerSecond);

                arr.put(i, arrnode);
            });
            res[key] = arr;
        }
    }

    @SneakyThrows
    public static ConcurrentHashMap<BigInteger, byte[]> getDXformJSON(String fileName) {
        ConcurrentHashMap<BigInteger, byte[]> res = new ConcurrentHashMap<>();
        ObjectMapper mapper = new ObjectMapper();
        JsonNode rootNode = mapper.readTree(new File(fileName));
        rootNode.fields().forEachRemaining(e -> {
            BigInteger KEY = new BigInteger(e.getKey());
            byte[] value = cn.hutool.core.codec.Base64.decode(e.getValue().asText());
            res.put(KEY, value);
        });
        return res;
    }

    @SneakyThrows
    public static ConcurrentHashMap<Long, Arrnode>[] getArrfromJSON(String fileName) {
        String jsonFile = readJsonFile(fileName);
        ObjectMapper mapper = new ObjectMapper();
        JsonNode root = mapper.readTree(jsonFile);
        ConcurrentHashMap<Long, Arrnode>[] res = new ConcurrentHashMap[root.size()];
        Iterator<Map.Entry<String, JsonNode>> itRoot = root.fields();
        while (itRoot.hasNext()) {
            Map.Entry<String, JsonNode> next = itRoot.next();
            int key = Integer.parseInt(next.getKey());
            JsonNode value = next.getValue();
            ConcurrentHashMap<Long, Arrnode> arr = new ConcurrentHashMap<>();
            value.fields().forEachRemaining(ele -> {
                long i = Long.parseLong(ele.getKey());
                JsonNode eleValue = ele.getValue();
                JsonNode first = eleValue.get("first");
                JsonNode second = eleValue.get("second");
                byte[] BytesFirst = org.apache.commons.codec.binary.Base64.decodeBase64(first.asText());
                BigInteger bigIntegerSecond = new BigInteger(second.asText());
                Arrnode arrnode = new Arrnode(BytesFirst, bigIntegerSecond);
                arr.put(i, arrnode);
            });
            res[key] = arr;
        }
        return res;
    }

    @SneakyThrows
    public static void writePPHsk(String fileName, SK sk) {
        ObjectMapper mapper = new ObjectMapper();
        ObjectNode rootNode = mapper.createObjectNode();
        String[] hash64 = sk.getHash64();
        rootNode.put("k1", hash64[0]);
        rootNode.put("k2", hash64[1]);
        rootNode.put("k3", hash64[2]);
        rootNode.put("k4", hash64[3]);
        rootNode.put("k5", hash64[4]);
        mapper.writeValue(new File(fileName), rootNode);
    }
    @SneakyThrows
    public static void writePPHsk(String fileName, SecretKey sk) {
        ObjectMapper mapper = new ObjectMapper();
        ObjectNode rootNode = mapper.createObjectNode();
        String[] hash64 = sk.getHash64();
        rootNode.put("k1", hash64[0]);
        rootNode.put("k2", hash64[1]);
        rootNode.put("k3", hash64[2]);
        rootNode.put("k4", hash64[3]);
        rootNode.put("k5", hash64[4]);
        mapper.writeValue(new File(fileName), rootNode);
    }
    @SneakyThrows
    public static String[] GetSKFromJson(String fileName) {
        ObjectMapper mapper = new ObjectMapper();
        JsonNode rootNode = mapper.readTree(new File(fileName));
        String k1 = rootNode.get("k1").asText();
        String k2 = rootNode.get("k2").asText();
        String k3 = rootNode.get("k3").asText();
        String k4 = rootNode.get("k4").asText();
        String k5 = rootNode.get("k5").asText();

        return new String[]{k1, k2, k3, k4, k5};

    }

    @SneakyThrows
    public static void WriteMapInJson(ConcurrentHashMap<Long, Integer> i2i, ConcurrentHashMap<Long, Long> ii2i, ConcurrentHashMap<Long, Long> oi2i) {
        ObjectMapper mapper = new ObjectMapper();
        ObjectMapper mapper1 = new ObjectMapper();
        ObjectMapper mapper2 = new ObjectMapper();
        ObjectNode rootNode1 = mapper.createObjectNode();
        ObjectNode rootNode2 = mapper1.createObjectNode();
        ObjectNode rootNode3 = mapper2.createObjectNode();
        i2i.forEachEntry(i2i.mappingCount() << 1, e -> {
            rootNode1.put(String.valueOf(e.getKey()), String.valueOf(e.getValue()));
        });
        ii2i.forEachEntry(ii2i.mappingCount() << 1, e -> {
            rootNode2.put(String.valueOf(e.getKey()), String.valueOf(e.getValue()));
        });
        oi2i.forEachEntry(oi2i.mappingCount() << 1, e -> {
            rootNode3.put(String.valueOf(e.getKey()), String.valueOf(e.getValue()));
        });
        mapper.writeValue(new File("D:\\Gaia\\src\\main\\resources\\i2i.json"), rootNode1);
        mapper1.writeValue(new File("D:\\Gaia\\src\\main\\resources\\ii2i.json"), rootNode2);
        mapper2.writeValue(new File("D:\\Gaia\\src\\main\\resources\\oi2i.json"), rootNode3);
    }

    @SneakyThrows
    public static void getMapInJson(ConcurrentHashMap<Long, Integer> i2i, ConcurrentHashMap<Long, Long> ii2i, ConcurrentHashMap<Long, Long> oi2i) {
        ObjectMapper mapper = new ObjectMapper();
        JsonNode rootNode1 = mapper.readTree(new File("D:\\Gaia\\src\\main\\resources\\i2i.json"));
        JsonNode rootNode2 = mapper.readTree(new File("D:\\Gaia\\src\\main\\resources\\ii2i.json"));
        JsonNode rootNode3 = mapper.readTree(new File("D:\\Gaia\\src\\main\\resources\\oi2i.json"));
        rootNode1.fields().forEachRemaining(e -> {
            i2i.put(Long.parseLong(e.getKey()), e.getValue().asInt());
        });
        rootNode2.fields().forEachRemaining(e -> {
            ii2i.put(Long.parseLong(e.getKey()), e.getValue().asLong());
        });
        rootNode3.fields().forEachRemaining(e -> {
            oi2i.put(Long.parseLong(e.getKey()), e.getValue().asLong());
        });
    }
    /**
     * 保存公钥到本地文件
     * @param directoryPath 保存目录的路径
     * @throws IOException 如果文件操作失败
     */
    public static void savePublicKeys(String directoryPath, PublicKeys publicKeys) throws IOException {
        // 确保目录存在
        File directory = new File(directoryPath);
        if (!directory.exists()) {
            directory.mkdirs();
        }

        // 序列化公钥
        long[] serializedKeys = publicKeys.serialize();

        // 保存到文件
        String publicKeyPath = directoryPath + File.separator + "public_keys.bin";
        try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(publicKeyPath))) {
            // 首先写入数组长度
            dos.writeInt(serializedKeys.length);
            // 然后写入所有数据
            for (long value : serializedKeys) {
                dos.writeLong(value);
            }
        }
    }

    /**
     * 从本地文件加载公钥
     * @param directoryPath 公钥文件所在的目录路径
     * @throws IOException 如果文件操作失败
     */
    public PublicKeys loadPublicKeys(String directoryPath, Context context) throws IOException {
        String publicKeyPath = directoryPath + File.separator + "public_keys.bin";
        try (DataInputStream dis = new DataInputStream(new FileInputStream(publicKeyPath))) {
            // 读取数组长度
            int length = dis.readInt();
            // 读取所有数据
            long[] serializedKeys = new long[length];
            for (int i = 0; i < length; i++) {
                serializedKeys[i] = dis.readLong();
            }
            PublicKeys publicKeys;
            // 反序列化公钥
            publicKeys = new PublicKeys();
            publicKeys.deserialize(context, serializedKeys);

            // 重新初始化加密器和评估器
//            encryptor = new Encryptor(context, publicKeys);
//            evaluator = new Evaluator(context, publicKeys);
            return publicKeys;
        }
    }

    /**
     * 保存私钥到本地文件
     * @param directoryPath 保存目录的路径
     * @throws IOException 如果文件操作失败
     */
    public static void saveSecretKey(String directoryPath, SecretKey secretKey) throws IOException {
        // 确保目录存在
        File directory = new File(directoryPath);
        if (!directory.exists()) {
            directory.mkdirs();
        }

        // 序列化私钥
        long[] serializedKey = secretKey.serialize();

        // 保存到文件
        String secretKeyPath = directoryPath + File.separator + "secret_key.bin";
        try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(secretKeyPath))) {
            // 首先写入数组长度
            dos.writeInt(serializedKey.length);
            // 然后写入所有数据
            for (long value : serializedKey) {
                dos.writeLong(value);
            }
        }
    }

    /**
     * 从本地文件加载私钥
     * @param directoryPath 私钥文件所在的目录路径
     * @throws IOException 如果文件操作失败
     */
    public SecretKey loadSecretKey(String directoryPath,Context context) throws IOException {
        String secretKeyPath = directoryPath + File.separator + "secret_key.bin";
        try (DataInputStream dis = new DataInputStream(new FileInputStream(secretKeyPath))) {
            // 读取数组长度
            int length = dis.readInt();
            // 读取所有数据
            long[] serializedKey = new long[length];
            for (int i = 0; i < length; i++) {
                serializedKey[i] = dis.readLong();
            }
            SecretKey secretKey;
            // 反序列化私钥
            secretKey = new SecretKey();
            secretKey.deserialize(context, serializedKey);

            // 重新初始化解密器
//            decryptor = new Decryptor(secretKey);
            return secretKey;
        }
    }

    public static void saveContext(String directoryPath, Context context) throws IOException {
        // 确保目录存在
        File directory = new File(directoryPath);
        if (!directory.exists()) {
            directory.mkdirs();
        }

        // 序列化上下文
        long[] serializedContext = context.serialize();

        // 保存到文件
        String contextPath = directoryPath + File.separator + "context.bin";
        try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(contextPath))) {
            // 首先写入数组长度
            dos.writeInt(serializedContext.length);
            // 然后写入所有数据
            for (long value : serializedContext) {
                dos.writeLong(value);
            }
        }
    }

    public static Context loadContext(String directoryPath) throws IOException {
        String contextPath = directoryPath + File.separator + "context.bin";
        try (DataInputStream dis = new DataInputStream(new FileInputStream(contextPath))) {
            // 读取数组长度
            int length = dis.readInt();
            // 读取所有数据
            long[] serializedContext = new long[length];
            for (int i = 0; i < length; i++) {
                serializedContext[i] = dis.readLong();
            }

            // 反序列化上下文
            Context context = new Context();
            context.deserialize(serializedContext);

            // 重新初始化编码器
//            encoder = new Encoder(context);
            return context;
        }
    }
    //    //Arr，DX数据转json
//    //json构建Eg
    public static void main(String[] args) {
        long t1 = System.currentTimeMillis();
        ConcurrentHashMap<Long, Integer> i2i = new ConcurrentHashMap<>();
        ConcurrentHashMap<Long, Long> oi2i = new ConcurrentHashMap<>();
        ConcurrentHashMap<Long, Long> ii2i = new ConcurrentHashMap<>();
        ConcurrentHashMap<Integer, node> nodeList = getNodeList1("resources/400-2200junctions(Manhattan) (2)/400/400.json", i2i, ii2i, oi2i);
//        testReadArrList("resources/ArrList.json");
        long t2 = System.currentTimeMillis();
//        System.out.println("读取数据(t2-t1) = " + (t2 - t1));
//        ConcurrentHashMap<BigInteger, byte[]> dx1 = JsonUtil.getDX("resources/DX.json");
//        ArrayList<Arr> arrList1 = JsonUtil.getArrList("resources/ArrList.json");

    }

    //    public static int[][]getGraph(){
//        int[][]res=new int[][];
//        return res;
//    }
    @SneakyThrows
    public static ArrayList<TokenNode> getTokens(String fileName) {
        ArrayList<TokenNode> res = new ArrayList<>();
        String jsonFile = readJsonFile(fileName);
        ObjectMapper mapper = new ObjectMapper();
        JsonNode rootNode = mapper.readTree(jsonFile);
        JsonNode jsonNode = rootNode.fields().next().getValue();
        for (JsonNode node : jsonNode) {
            String h1 = node.get("H1").asText();
            String f4 = node.get("F4").asText();
            String t2 = node.get("T2").asText();
            long id = node.get("id").asLong();
            TokenNode tmp = new TokenNode(t2, f4, h1, id);
            res.add(tmp);
        }
        return res;
    }

    @SneakyThrows
    public static ConcurrentHashMap<Integer, node> getNodeList600(String fileName,
                                                                ConcurrentHashMap<Long, Integer> Id2Index,
                                                                ConcurrentHashMap<Long, Long> inI2I,
                                                                ConcurrentHashMap<Long, Long> outI2I) {
        String jsonFile = readJsonFile(fileName);
        ObjectMapper mapper = new ObjectMapper();
        JsonNode root = mapper.readTree(jsonFile);
        ConcurrentHashMap<Integer, node> res = new ConcurrentHashMap<Integer, node>();
        SecureRandom rng = new SecureRandom(new byte[8]);
        
        // 第一遍：收集所有节点ID并建立索引映射
        Iterator<Map.Entry<String, JsonNode>> it = root.fields();
        List<String> nodeIds = new ArrayList<>();
        
        // 计算坐标范围
        double xmax = -1000.0, ymax = -500.0, xmin = 1000.0, ymin = 500.0;
        while (it.hasNext()) {
            Map.Entry<String, JsonNode> entry = it.next();
            String nodeId = entry.getKey();
            nodeIds.add(nodeId);
            
            JsonNode nodeData = entry.getValue();
            JsonNode pointNode = nodeData.get("point");
            if (pointNode != null && pointNode.isArray() && pointNode.size() >= 2) {
                double lat = pointNode.get(0).asDouble();  // 纬度
                double lon = pointNode.get(1).asDouble();  // 经度
                
                xmax = Math.max(xmax, lon);
                xmin = Math.min(xmin, lon);
                ymax = Math.max(ymax, lat);
                ymin = Math.min(ymin, lat);
            }
        }
        
        double xone = (xmax - xmin) / 100.0;
        double yone = (ymax - ymin) / 100.0;
        
        // 建立ID到索引的映射
        for (int i = 0; i < nodeIds.size(); i++) {
            String nodeId = nodeIds.get(i);
            long id = Long.parseLong(nodeId);
            Id2Index.put(id, i);
            
            long tl;
            do {
                tl = rng.nextLong();
            } while (new BigInteger(String.valueOf(tl)).toByteArray().length != 8);
            inI2I.put(id, tl);
            outI2I.put(tl, id);
        }
        
        // 第二遍：创建节点对象
        it = root.fields();
        while (it.hasNext()) {
            Map.Entry<String, JsonNode> entry = it.next();
            String nodeId = entry.getKey();
            long id = Long.parseLong(nodeId);
            JsonNode nodeData = entry.getValue();
            
            node tmpNode = new node();
            
            // 解析坐标 - 从point数组
            JsonNode pointNode = nodeData.get("point");
            if (pointNode != null && pointNode.isArray() && pointNode.size() >= 2) {
                double lat = pointNode.get(0).asDouble();  // 纬度
                double lon = pointNode.get(1).asDouble();  // 经度
                
                int xi = (int) ((lon - xmin) / xone);  // 经度对应x
                int yi = (int) ((lat - ymin) / yone);  // 纬度对应y
                
                tmpNode.x = xi;
                tmpNode.y = yi;
            }
            
            // 解析邻居和距离 - 从nearby对象
            JsonNode nearbyNode = nodeData.get("nearby");
            ArrayList<Double> tmpd = new ArrayList<>();
            ArrayList<Integer> tmpn = new ArrayList<>();
            
            if (nearbyNode != null) {
                Iterator<Map.Entry<String, JsonNode>> nearbyFields = nearbyNode.fields();
                while (nearbyFields.hasNext()) {
                    Map.Entry<String, JsonNode> nearbyEntry = nearbyFields.next();
                    String neighborId = nearbyEntry.getKey();
                    double distance = nearbyEntry.getValue().asDouble();
                    
                    // 通过映射找到邻居的索引
                    if (Id2Index.containsKey(Long.parseLong(neighborId))) {
                        tmpd.add(distance);
                        tmpn.add(Id2Index.get(Long.parseLong(neighborId)));
                    }
                }
            }
            
            tmpNode.Dis = tmpd;
            tmpNode.Neb = tmpn;
            tmpNode.id = id;
            tmpNode.index = Id2Index.get(id);
            res.put(tmpNode.index, tmpNode);
        }
        
        return res;
    }

    @SneakyThrows
    public static ConcurrentHashMap<Integer, node> getNodeList1(String fileName,
                                                                ConcurrentHashMap<Long, Integer> Id2Index,  //id找索引
                                                                ConcurrentHashMap<Long, Long> inI2I,        //地图ID到算法ID
                                                                ConcurrentHashMap<Long, Long> outI2I) {     //算法ID到地图ID
        String jsonFile = readJsonFile(fileName);
        ObjectMapper mapper = new ObjectMapper();
        JsonNode root = mapper.readTree(jsonFile);
        ConcurrentHashMap<Integer, node> res = new ConcurrentHashMap<Integer, node>();
        SecureRandom rng = new SecureRandom(new byte[8]);
        Iterator<ConcurrentHashMap.Entry<String, JsonNode>> it = root.fields();
        Iterator<ConcurrentHashMap.Entry<String, JsonNode>> it1 = root.fields();
        Iterator<String> tmpIt = root.fieldNames();
        HashSet<String> tmpSet = new HashSet<>();
        tmpIt.forEachRemaining(tmpSet::add);
        double xmax = -1000.0, ymax = -500.0, xmin = 1000.0, ymin = 500.0;
        while (it.hasNext()) {
            JsonNode JSvalue = it.next().getValue();
            JsonNode LON = JSvalue.get("LON");
            double lon = Double.parseDouble(LON.asText());
            xmax = Math.max(xmax, lon);
            xmin = Math.min(xmin, lon);
            JsonNode LAT = JSvalue.get("LAT");
            double lat = Double.parseDouble(LAT.asText());
            ymax = Math.max(ymax, lat);
            ymin = Math.min(ymin, lat);
        }
        double xone = (xmax - xmin) / 100.0;
        double yone = (ymax - ymin) / 100.0;
        while (it1.hasNext()) {
            Map.Entry<String, JsonNode> next = it1.next();
            Long id = Long.parseLong(next.getKey());
            JsonNode valueNode = next.getValue();
            int index1 = Integer.parseInt(valueNode.get("Index").asText());
            Id2Index.put(id, index1);
            long tl;
            do {
                tl = rng.nextLong();
            } while (new BigInteger(String.valueOf(tl)).toByteArray().length != 8);
            inI2I.put(id, tl);//地图ID到算法ID
            outI2I.put(tl, id);//算法ID到地图ID
        }
        var it2 = root.fields();
        while (it2.hasNext()) {
            node tmpNode = new node();

            ConcurrentHashMap.Entry<String, JsonNode> next = it2.next();
            if (next.getValue() == null || next.getKey() == null) {
                break;
            }
            long id = Long.parseLong(next.getKey());
            JsonNode JSvalue = next.getValue();
            if (JSvalue == null) {
                continue;
            }
            JsonNode LON = JSvalue.get("LON");
            JsonNode LAT = JSvalue.get("LAT");
            JsonNode neighbor = JSvalue.get("Neighbor");
            JsonNode distance = JSvalue.get("Distance");
            double x = Double.parseDouble(LON.asText());
            double y = Double.parseDouble(LAT.asText());
            int xi = (int) ((x - xmin) / xone);
            int yi = (int) ((y - ymin) / yone);

            int len = neighbor.size();

            ArrayList<Double> tmpd = new ArrayList<>();
            ArrayList<Integer> tmpn = new ArrayList<>();
            for (int i = 0; i < len; i++) {
                double dis = Double.parseDouble(distance.get(i).asText());
                int ne = Integer.parseInt(neighbor.get(i).asText());
                tmpd.add(dis);
                tmpn.add(ne);
            }
            tmpNode.Dis = tmpd;
            tmpNode.Neb = tmpn;
            tmpNode.x = xi;
            tmpNode.y = yi;
            tmpNode.id = id;
            tmpNode.index = Id2Index.get(id);
            res.put(tmpNode.index, tmpNode);
        }
        return res;
    }

    public static void makeMatrix(String fileName, double[][] disMatrix) {
        StringBuilder res = new StringBuilder();
        for (int i = 0; i < disMatrix.length; i++) {
            for (int j = 0; j < disMatrix[i].length; j++) {
                res.append(disMatrix[i][j]);
                res.append(",");
            }
            res.deleteCharAt(res.length() - 1);
            res.append(";");
        }
        res.deleteCharAt(res.length() - 1);
        try {
            File file = new File(fileName);
            if (!file.exists()) {
                file.getParentFile().mkdirs();
                file.createNewFile();
            }
            FileWriter fw = new FileWriter(file);
            fw.write(res.toString());
            fw.flush();
            fw.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    public static double[][] getMatrix(String fileName) throws IOException {

        BufferedReader reader = new BufferedReader(new FileReader(fileName));
        StringBuilder stringBuilder = new StringBuilder();
        String line = null;
        String ls = System.getProperty("line.separator");
        while ((line = reader.readLine()) != null) {
            stringBuilder.append(line);
            stringBuilder.append(ls);
        }
// 删除最后一个新行分隔符
        stringBuilder.deleteCharAt(stringBuilder.length() - 1);
        reader.close();
        String content = stringBuilder.toString();
        String[] row = content.split(";");
        double[][] res = new double[row.length][row.length];
        for (int i = 0; i < row.length; i++) {
            String[] eles = row[i].split(",");
            for (int j = 0; j < eles.length; j++) {
                res[i][j] = Double.parseDouble(eles[j]);
            }
        }
        return res;

    }
}
