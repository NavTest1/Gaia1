package util;

import Class.PartialOrder;
import Class.TokenNode;
import java.util.ArrayList;
import java.util.List;

/**
 * 偏序关系配置工具类
 * 用于方便地定义和管理偏序关系
 */
public class PartialOrderConfig {
    
    /**
     * 创建偏序关系列表
     * @param pairs 偏序关系对数组，格式为 [PStId1, SStId1, PStId2, SStId2, ...]
     * @return 偏序关系列表
     */
    public static List<PartialOrder> createPartialOrders(long... pairs) {
        List<PartialOrder> pos = new ArrayList<>();
        if (pairs.length % 2 != 0) {
            throw new IllegalArgumentException("偏序关系对必须是偶数个参数");
        }
        
        for (int i = 0; i < pairs.length; i += 2) {
            long pStId = pairs[i];
            long sStId = pairs[i + 1];
            
            TokenNode PSt = new TokenNode();
            PSt.setId(pStId);
            
            TokenNode SSt = new TokenNode();
            SSt.setId(sStId);
            
            PartialOrder po = new PartialOrder(PSt, SSt);
            pos.add(po);
        }
        return pos;
    }
    
    /**
     * 从字符串创建偏序关系
     * @param poString 格式: "1001->1002,1003->1004,1005->1006"
     * @return 偏序关系列表
     */
    public static List<PartialOrder> createPartialOrdersFromString(String poString) {
        List<PartialOrder> pos = new ArrayList<>();
        if (poString == null || poString.trim().isEmpty()) {
            return pos;
        }
        
        String[] pairs = poString.split(",");
        for (String pair : pairs) {
            String[] nodes = pair.split("->");
            if (nodes.length == 2) {
                try {
                    long pStId = Long.parseLong(nodes[0].trim());
                    long sStId = Long.parseLong(nodes[1].trim());
                    
                    TokenNode PSt = new TokenNode();
                    PSt.setId(pStId);
                    
                    TokenNode SSt = new TokenNode();
                    SSt.setId(sStId);
                    
                    PartialOrder po = new PartialOrder(PSt, SSt);
                    pos.add(po);
                } catch (NumberFormatException e) {
                    System.err.println("无效的节点ID格式: " + pair);
                }
            }
        }
        return pos;
    }
}