package util;

import java.io.*;
import java.util.*;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.dom4j.*;
import org.dom4j.io.SAXReader;
import com.fasterxml.jackson.databind.ObjectMapper;

public class OsmtoJson {
    // 添加类级别的静态变量
    private static List<Long> wayIds = new ArrayList<>();
    private static List<Map<String, Object>> relationInfoList = new ArrayList<>();
    private static Map<GridKey, Set<Long>> spatialGrid = new HashMap<>();

    // 添加标签处理的常量
    private static final Set<String> WALKABLE_HIGHWAYS = new HashSet<>(Arrays.asList(
        "footway", "path", "pedestrian", "steps", "residential", "service"
    ));
    
    private static final Set<String> BARRIER_TYPES = new HashSet<>(Arrays.asList(
        "wall", "fence", "hedge", "retaining_wall"
    ));

    public static void getMap(String inpath, String outpath) throws IOException, DocumentException {
        // 清空静态列表，避免多次调用时数据混淆
        wayIds.clear();
        relationInfoList.clear();
        spatialGrid.clear();

        Map<Long, Map<String, Object>> nodeMap = new HashMap<>();
        Map<Long, Integer> idToRandomIndex = new HashMap<>();
        List<List<Long>> wayNodeLists = new ArrayList<>();
        List<List<Long>> relationNodeLists = new ArrayList<>();
        Random random = new Random();

        SAXReader reader = new SAXReader();
        Document document = reader.read(new File(inpath));
        Element root = document.getRootElement();

        for (Iterator<Element> it = root.elementIterator(); it.hasNext(); ) {
            Element element = it.next();

            if (element.getName().equals("node")) {
                Long id = Long.parseLong(element.attributeValue("id"));
                Double lat = Double.parseDouble(element.attributeValue("lat"));
                Double lon = Double.parseDouble(element.attributeValue("lon"));
                Map<String, Object> nodeInfo = new HashMap<>();
                nodeInfo.put("LON", lon);
                nodeInfo.put("LAT", lat);
                nodeInfo.put("Neighbor", new ArrayList<Integer>());
                nodeInfo.put("Distance", new ArrayList<Double>());
                
                // 添加标签信息
                Map<String, String> tags = new HashMap<>();
                for (Iterator<Element> tagIt = element.elementIterator("tag"); tagIt.hasNext();) {
                    Element tag = tagIt.next();
                    tags.put(tag.attributeValue("k"), tag.attributeValue("v"));
                }
                nodeInfo.put("tags", tags);
                nodeMap.put(id, nodeInfo);
            } else if (element.getName().equals("way")) {
                Long wayId = Long.parseLong(element.attributeValue("id")); // 获取way的ID
                List<Long> wayNodes = new ArrayList<>();
                for (Iterator<Element> wayIt = element.elementIterator(); wayIt.hasNext(); ) {
                    Element ndElement = wayIt.next();
                    if (ndElement.getName().equals("nd")) {
                        wayNodes.add(Long.parseLong(ndElement.attributeValue("ref")));
                    }
                }
                wayNodeLists.add(wayNodes);
                wayIds.add(wayId); // 保存way的ID
            } else if (element.getName().equals("relation")) {
                List<Long> relationNodes = new ArrayList<>();
                List<Long> relationWays = new ArrayList<>();
                
                for (Iterator<Element> relIt = element.elementIterator(); relIt.hasNext(); ) {
                    Element member = relIt.next();
                    if (member.getName().equals("member")) {
                        String type = member.attributeValue("type");
                        if ("node".equals(type)) {
                            relationNodes.add(Long.parseLong(member.attributeValue("ref")));
                        } else if ("way".equals(type)) {
                            relationWays.add(Long.parseLong(member.attributeValue("ref")));
                        }
                    }
                }
                
                Map<String, Object> relationInfo = new HashMap<>();
                relationInfo.put("nodes", relationNodes);
                relationInfo.put("ways", relationWays);
                relationInfoList.add(relationInfo);
                relationNodeLists.add(relationNodes);
            }
        }

        Set<Integer> usedIndexes = new HashSet<>();
        for (Long nodeId : nodeMap.keySet()) {
            int index;
            do {
                index = random.nextInt(nodeMap.size());
            } while (!usedIndexes.add(index));
            idToRandomIndex.put(nodeId, index);
        }

        // 处理way中的连接
        for (int i = 0; i < wayNodeLists.size(); i++) {
            List<Long> wayNodes = wayNodeLists.get(i);
            for (int j = 0; j < wayNodes.size() - 1; j++) {
                Long current = wayNodes.get(j);
                Long next = wayNodes.get(j + 1);
                
                if (nodeMap.containsKey(current) && nodeMap.containsKey(next)) {
                    addConnection(nodeMap, idToRandomIndex, current, next);
                }
            }
        }

        // 创建way ID到节点列表的映射
        Map<Long, List<Long>> wayIdToNodes = new HashMap<>();
        for (int i = 0; i < wayNodeLists.size(); i++) {
            wayIdToNodes.put(wayIds.get(i), wayNodeLists.get(i));
        }

        // 处理relation
        for (Map<String, Object> relationInfo : relationInfoList) {
            @SuppressWarnings("unchecked")
            List<Long> relationNodes = (List<Long>) relationInfo.get("nodes");
            @SuppressWarnings("unchecked")
            List<Long> relationWays = (List<Long>) relationInfo.get("ways");
            
            // 处理relation中的直接节点连接
            for (int i = 0; i < relationNodes.size() - 1; i++) {
                Long current = relationNodes.get(i);
                Long next = relationNodes.get(i + 1);
                if (nodeMap.containsKey(current) && nodeMap.containsKey(next)) {
                    addConnection(nodeMap, idToRandomIndex, current, next);
                }
            }
            
            // 处理relation中的way
            for (Long wayId : relationWays) {
                List<Long> wayNodes = wayIdToNodes.get(wayId);
                if (wayNodes != null) {
                    // 连接way内的节点
                    for (int i = 0; i < wayNodes.size() - 1; i++) {
                        Long current = wayNodes.get(i);
                        Long next = wayNodes.get(i + 1);
                        if (nodeMap.containsKey(current) && nodeMap.containsKey(next)) {
                            addConnection(nodeMap, idToRandomIndex, current, next);
                        }
                    }
                    
                    // 如果way是relation的一部分，确保way的端点与relation的其他节点连接
                    if (!wayNodes.isEmpty()) {
                        Long wayStart = wayNodes.get(0);
                        Long wayEnd = wayNodes.get(wayNodes.size() - 1);
                        
                        for (Long relationNode : relationNodes) {
                            if (nodeMap.containsKey(relationNode)) {
                                if (nodeMap.containsKey(wayStart)) {
                                    addConnection(nodeMap, idToRandomIndex, relationNode, wayStart);
                                }
                                if (nodeMap.containsKey(wayEnd)) {
                                    addConnection(nodeMap, idToRandomIndex, relationNode, wayEnd);
                                }
                            }
                        }
                    }
                }
            }
        }

        // 在处理完way和relation后，添加对交叉点的处理
        handleIntersections(nodeMap, idToRandomIndex);

        for (Map.Entry<Long, Map<String, Object>> entry : nodeMap.entrySet()) {
            Long nodeId = entry.getKey();
            entry.getValue().put("Index", idToRandomIndex.get(nodeId));
        }

        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(SerializationFeature.INDENT_OUTPUT);
        mapper.writeValue(new File(outpath), nodeMap);
        System.out.println("JSON 文件已写入: " + outpath);

        // 更新统计信息方法
        printStatistics(nodeMap, wayNodeLists, relationNodeLists);
    }

    private static double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
        final int R = 6371;
        double latDist = Math.toRadians(lat2 - lat1);
        double lonDist = Math.toRadians(lon2 - lon1);
        double a = Math.sin(latDist / 2) * Math.sin(latDist / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(lonDist / 2) * Math.sin(lonDist / 2);
        return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)) * 1000;
    }

    // 添加一个辅助方法来处理连接
    private static void addConnection(Map<Long, Map<String, Object>> nodeMap, 
                                    Map<Long, Integer> idToRandomIndex,
                                    Long node1, Long node2) {
        Integer index1 = idToRandomIndex.get(node1);
        Integer index2 = idToRandomIndex.get(node2);
        
        // 计算一次距离，确保双向一致
        double distance = calculateDistance(
            (Double) nodeMap.get(node1).get("LAT"),
            (Double) nodeMap.get(node1).get("LON"),
            (Double) nodeMap.get(node2).get("LAT"),
            (Double) nodeMap.get(node2).get("LON"));
        
        Map<String, Object> node1Info = nodeMap.get(node1);
        Map<String, Object> node2Info = nodeMap.get(node2);
        
        @SuppressWarnings("unchecked")
        List<Integer> neighbors1 = (List<Integer>) node1Info.get("Neighbor");
        @SuppressWarnings("unchecked")
        List<Double> distances1 = (List<Double>) node1Info.get("Distance");
        
        @SuppressWarnings("unchecked")
        List<Integer> neighbors2 = (List<Integer>) node2Info.get("Neighbor");
        @SuppressWarnings("unchecked")
        List<Double> distances2 = (List<Double>) node2Info.get("Distance");
        
        // 移除已存在的连接（如果有）
        int idx1 = neighbors1.indexOf(index2);
        int idx2 = neighbors2.indexOf(index1);
        
        if (idx1 >= 0) {
            neighbors1.remove(idx1);
            distances1.remove(idx1);
        }
        if (idx2 >= 0) {
            neighbors2.remove(idx2);
            distances2.remove(idx2);
        }
        
        // 添加新的连接，确保使用相同的距离值
        neighbors1.add(index2);
        distances1.add(distance);
        
        neighbors2.add(index1);
        distances2.add(distance);
    }

    // 修改handleIntersections方法为更智能的连接处理
    private static void handleIntersections(Map<Long, Map<String, Object>> nodeMap, 
                                          Map<Long, Integer> idToRandomIndex) {
        double gridSize = 0.0001; // 约11米
        Map<Long, Set<Long>> connectedComponents = new HashMap<>();

        // 建立空间索引和初始化连通分量
        buildSpatialIndex(nodeMap, connectedComponents, gridSize);
        
        // 合并已连接节点的连通分量
        mergeConnectedComponents(nodeMap, idToRandomIndex, connectedComponents);

        // 找出不同的连通分量
        Set<Set<Long>> uniqueComponents = new HashSet<>(connectedComponents.values());
        List<Set<Long>> componentsList = new ArrayList<>(uniqueComponents);

        // 第一步：处理孤立的连通分量
        for (int i = 0; i < componentsList.size(); i++) {
            Set<Long> currentComp = componentsList.get(i);
            if (currentComp.size() < 5) { // 对小的连通分量特殊处理
                connectSmallComponent(currentComp, nodeMap, idToRandomIndex, spatialGrid);
            }
        }

        // 第二步：增加额外的连接以提高可达性
        for (Long nodeId : nodeMap.keySet()) {
            addAdditionalConnections(nodeId, nodeMap, idToRandomIndex, spatialGrid);
        }
    }

    private static void connectSmallComponent(Set<Long> component,
                                            Map<Long, Map<String, Object>> nodeMap,
                                            Map<Long, Integer> idToRandomIndex,
                                            Map<GridKey, Set<Long>> spatialGrid) {
        for (Long nodeId : component) {
            Map<String, Object> nodeInfo = nodeMap.get(nodeId);
            double lat = (Double) nodeInfo.get("LAT");
            double lon = (Double) nodeInfo.get("LON");
            
            // 寻找最近的三个其他连通分量的节点
            PriorityQueue<NodeDistance> nearestNodes = new PriorityQueue<>(
                Comparator.comparingDouble(nd -> nd.distance)
            );
            
            Set<Long> nearbyNodes = getNearbyNodes(nodeId, nodeMap, spatialGrid, 50.0);
            for (Long nearbyId : nearbyNodes) {
                if (!component.contains(nearbyId)) {
                    double dist = calculateDistance(
                        lat, lon,
                        (Double) nodeMap.get(nearbyId).get("LAT"),
                        (Double) nodeMap.get(nearbyId).get("LON")
                    );
                    nearestNodes.offer(new NodeDistance(nearbyId, dist));
                }
            }
            
            // 连接到最近的三个节点
            int connectCount = 0;
            while (!nearestNodes.isEmpty() && connectCount < 3) {
                NodeDistance nd = nearestNodes.poll();
                if (!crossesUnpassableArea(nodeId, nd.nodeId, nodeMap)) {
                    addConnection(nodeMap, idToRandomIndex, nodeId, nd.nodeId);
                    connectCount++;
                }
            }
        }
    }

    private static void addAdditionalConnections(Long nodeId,
                                               Map<Long, Map<String, Object>> nodeMap,
                                               Map<Long, Integer> idToRandomIndex,
                                               Map<GridKey, Set<Long>> spatialGrid) {
        Map<String, Object> nodeInfo = nodeMap.get(nodeId);
        @SuppressWarnings("unchecked")
        List<Integer> currentNeighbors = (List<Integer>) nodeInfo.get("Neighbor");
        
        // 如果当前节点连接数较少，尝试添加更多连接
        if (currentNeighbors.size() < 4) {
            double lat = (Double) nodeInfo.get("LAT");
            double lon = (Double) nodeInfo.get("LON");
            
            // 获取50米范围内的节点
            Set<Long> nearbyNodes = getNearbyNodes(nodeId, nodeMap, spatialGrid, 50.0);
            List<NodeDistance> potentialConnections = new ArrayList<>();
            
            for (Long nearbyId : nearbyNodes) {
                if (!nodeId.equals(nearbyId)) {
                    double dist = calculateDistance(
                        lat, lon,
                        (Double) nodeMap.get(nearbyId).get("LAT"),
                        (Double) nodeMap.get(nearbyId).get("LON")
                    );
                    
                    // 检查是否已经是邻居
                    Integer nearbyIndex = idToRandomIndex.get(nearbyId);
                    if (!currentNeighbors.contains(nearbyIndex)) {
                        potentialConnections.add(new NodeDistance(nearbyId, dist));
                    }
                }
            }
            
            // 按距离排序
            potentialConnections.sort(Comparator.comparingDouble(nd -> nd.distance));
            
            // 添加最近的合适连接
            for (NodeDistance nd : potentialConnections) {
                // 检查是否应该与这个节点建立连接
                if (shouldConnect(nodeId, nd.nodeId, nodeMap, idToRandomIndex)) {
                    addConnection(nodeMap, idToRandomIndex, nodeId, nd.nodeId);
                    // 每次添加连接后重新获取当前邻居数
                    currentNeighbors = (List<Integer>) nodeMap.get(nodeId).get("Neighbor");
                    if (currentNeighbors.size() >= 4) break;
                }
            }
        }
    }

    // 添加新的辅助方法来判断是否应该建立连接
    private static boolean shouldConnect(Long node1, Long node2,
                                      Map<Long, Map<String, Object>> nodeMap,
                                      Map<Long, Integer> idToRandomIndex) {
        // 如果穿过不可通过区域，直接返回false
        if (crossesUnpassableArea(node1, node2, nodeMap)) {
            return false;
        }

        // 获取两个节点的坐标
        Map<String, Object> info1 = nodeMap.get(node1);
        Map<String, Object> info2 = nodeMap.get(node2);
        double lat1 = (Double) info1.get("LAT");
        double lon1 = (Double) info1.get("LON");
        double lat2 = (Double) info2.get("LAT");
        double lon2 = (Double) info2.get("LON");
        double directDist = calculateDistance(lat1, lon1, lat2, lon2);

        // 获取所有可能的路径选项
        List<PathOption> pathOptions = new ArrayList<>();
        pathOptions.add(new PathOption(Arrays.asList(node1, node2), directDist));

        // 在一定范围内搜索可能的中间节点
        Set<Long> potentialIntermediates = getNearbyNodes(node1, nodeMap, spatialGrid, 30.0);
        potentialIntermediates.addAll(getNearbyNodes(node2, nodeMap, spatialGrid, 30.0));

        // 检查通过其他节点的路径
        for (Long intermediateId : potentialIntermediates) {
            if (!intermediateId.equals(node1) && !intermediateId.equals(node2)) {
                Map<String, Object> intermediateInfo = nodeMap.get(intermediateId);
                double iLat = (Double) intermediateInfo.get("LAT");
                double iLon = (Double) intermediateInfo.get("LON");

                // 计算通过这个中间节点的总距离
                double dist1 = calculateDistance(lat1, lon1, iLat, iLon);
                double dist2 = calculateDistance(iLat, iLon, lat2, lon2);
                double totalDist = dist1 + dist2;

                // 检查方向性
                double directionality = calculateDirectionality(
                    lat1, lon1, iLat, iLon, lat2, lon2);

                // 如果路径基本保持方向，且总距离不会增加太多
                if (directionality > 0.7 && totalDist < directDist * 1.2) {
                    pathOptions.add(new PathOption(Arrays.asList(node1, intermediateId, node2), totalDist));
                }
            }
        }

        // 按总距离排序路径选项
        pathOptions.sort(Comparator.comparingDouble(p -> p.totalDistance));

        // 如果最短路径不是直接连接，返回false
        return pathOptions.get(0).nodes.size() == 2;
    }

    // 添加计算方向性的辅助方法
    private static double calculateDirectionality(double lat1, double lon1, 
                                               double lat2, double lon2,
                                               double lat3, double lon3) {
        // 计算两个向量
        double[] vector1 = {lat2 - lat1, lon2 - lon1};
        double[] vector2 = {lat3 - lat2, lon3 - lon2};

        // 标准化向量
        double len1 = Math.sqrt(vector1[0] * vector1[0] + vector1[1] * vector1[1]);
        double len2 = Math.sqrt(vector2[0] * vector2[0] + vector2[1] * vector2[1]);
        
        vector1[0] /= len1;
        vector1[1] /= len1;
        vector2[0] /= len2;
        vector2[1] /= len2;

        // 计算点积（越接近1表示方向越一致）
        return vector1[0] * vector2[0] + vector1[1] * vector2[1];
    }

    // 添加路径选项类
    private static class PathOption {
        final List<Long> nodes;
        final double totalDistance;

        PathOption(List<Long> nodes, double totalDistance) {
            this.nodes = nodes;
            this.totalDistance = totalDistance;
        }
    }

    // 获取指定范围内的节点
    private static Set<Long> getNearbyNodes(Long nodeId,
                                          Map<Long, Map<String, Object>> nodeMap,
                                          Map<GridKey, Set<Long>> spatialGrid,
                                          double maxDistance) {
        Set<Long> result = new HashSet<>();
        Map<String, Object> nodeInfo = nodeMap.get(nodeId);
        double lat = (Double) nodeInfo.get("LAT");
        double lon = (Double) nodeInfo.get("LON");
        
        // 计算搜索范围内的网格
        double gridSize = 0.0001;
        int searchRadius = (int) Math.ceil(maxDistance / (gridSize * 111000));
        
        GridKey baseKey = new GridKey(Math.floor(lat / gridSize), Math.floor(lon / gridSize));
        
        for (int i = -searchRadius; i <= searchRadius; i++) {
            for (int j = -searchRadius; j <= searchRadius; j++) {
                GridKey searchKey = new GridKey(baseKey.lat + i, baseKey.lon + j);
                Set<Long> nodesInGrid = spatialGrid.get(searchKey);
                if (nodesInGrid != null) {
                    for (Long node : nodesInGrid) {
                        if (calculateDistance(
                                lat, lon,
                                (Double) nodeMap.get(node).get("LAT"),
                                (Double) nodeMap.get(node).get("LON")) <= maxDistance) {
                            result.add(node);
                        }
                    }
                }
            }
        }
        
        return result;
    }

    // 辅助方法：找到节点所属的连通分量
    private static Set<Long> findComponent(Map<Long, Set<Long>> components, Long nodeId) {
        return components.get(nodeId);
    }

    private static String classifyNode(Map<String, String> tags) {
        if (tags == null) return "passable";
        
        // 检查是否是不可跨越区域
        if (tags.containsKey("natural") && Arrays.asList("water", "cliff").contains(tags.get("natural"))) {
            return "unpassable";
        }
        if (tags.containsKey("waterway")) {
            return "unpassable";
        }
        
        return "passable";
    }

    private static boolean crossesUnpassableArea(Long node1, Long node2, 
                                               Map<Long, Map<String, Object>> nodeMap) {
        // 获取两个节点的坐标
        Map<String, Object> info1 = nodeMap.get(node1);
        Map<String, Object> info2 = nodeMap.get(node2);
        double lat1 = (Double) info1.get("LAT");
        double lon1 = (Double) info1.get("LON");
        double lat2 = (Double) info2.get("LAT");
        double lon2 = (Double) info2.get("LON");

        // 计算连线的方向向量
        double dx = lon2 - lon1;
        double dy = lat2 - lat1;
        double dist = Math.sqrt(dx * dx + dy * dy);

        // 如果距离太远，认为不安全
        if (dist > 0.001) { // 约110米
            return true;
        }

        // 简单的检查：如果两个点都不是不可跨越区域，则允许连接
        @SuppressWarnings("unchecked")
        Map<String, String> tags1 = (Map<String, String>) info1.get("tags");
        @SuppressWarnings("unchecked")
        Map<String, String> tags2 = (Map<String, String>) info2.get("tags");
        
        return "unpassable".equals(classifyNode(tags1)) || 
               "unpassable".equals(classifyNode(tags2));
    }

    // 网格键类
    private static class GridKey {
        final double lat;
        final double lon;

        GridKey(double lat, double lon) {
            this.lat = lat;
            this.lon = lon;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            GridKey gridKey = (GridKey) o;
            return Double.compare(gridKey.lat, lat) == 0 && 
                   Double.compare(gridKey.lon, lon) == 0;
        }

        @Override
        public int hashCode() {
            return Objects.hash(lat, lon);
        }
    }

    // 添加NodePair类
    private static class NodePair {
        final Long node1;
        final Long node2;
        final double distance;

        NodePair(Long node1, Long node2, double distance) {
            this.node1 = node1;
            this.node2 = node2;
            this.distance = distance;
        }
    }

    // 添加buildSpatialIndex方法
    private static void buildSpatialIndex(Map<Long, Map<String, Object>> nodeMap,
                                        Map<Long, Set<Long>> connectedComponents,
                                        double gridSize) {
        for (Map.Entry<Long, Map<String, Object>> entry : nodeMap.entrySet()) {
            Long nodeId = entry.getKey();
            Map<String, Object> nodeInfo = entry.getValue();
            double lat = (Double) nodeInfo.get("LAT");
            double lon = (Double) nodeInfo.get("LON");
            
            // 添加到空间网格
            GridKey key = new GridKey(Math.floor(lat / gridSize), Math.floor(lon / gridSize));
            spatialGrid.computeIfAbsent(key, k -> new HashSet<>()).add(nodeId);
            
            // 初始化连通分量
            connectedComponents.put(nodeId, new HashSet<>(Collections.singletonList(nodeId)));
        }
    }

    // 添加mergeConnectedComponents方法
    private static void mergeConnectedComponents(Map<Long, Map<String, Object>> nodeMap,
                                               Map<Long, Integer> idToRandomIndex,
                                               Map<Long, Set<Long>> connectedComponents) {
        for (Map.Entry<Long, Map<String, Object>> entry : nodeMap.entrySet()) {
            Long nodeId = entry.getKey();
            @SuppressWarnings("unchecked")
            List<Integer> neighbors = (List<Integer>) entry.getValue().get("Neighbor");
            
            for (Integer neighborIndex : neighbors) {
                // 找到对应的nodeId
                Long neighborId = null;
                for (Map.Entry<Long, Integer> idMapping : idToRandomIndex.entrySet()) {
                    if (idMapping.getValue().equals(neighborIndex)) {
                        neighborId = idMapping.getKey();
                        break;
                    }
                }
                
                if (neighborId != null) {
                    Set<Long> comp1 = findComponent(connectedComponents, nodeId);
                    Set<Long> comp2 = findComponent(connectedComponents, neighborId);
                    if (comp1 != comp2) {
                        comp1.addAll(comp2);
                        for (Long node : comp2) {
                            connectedComponents.put(node, comp1);
                        }
                    }
                }
            }
        }
    }

    // 添加findClosestPair方法
    private static NodePair findClosestPair(Set<Long> comp1, Set<Long> comp2,
                                          Map<Long, Map<String, Object>> nodeMap) {
        double minDist = Double.MAX_VALUE;
        Long bestNode1 = null;
        Long bestNode2 = null;

        for (Long node1 : comp1) {
            Map<String, Object> info1 = nodeMap.get(node1);
            double lat1 = (Double) info1.get("LAT");
            double lon1 = (Double) info1.get("LON");
            
            for (Long node2 : comp2) {
                Map<String, Object> info2 = nodeMap.get(node2);
                double lat2 = (Double) info2.get("LAT");
                double lon2 = (Double) info2.get("LON");
                
                double dist = calculateDistance(lat1, lon1, lat2, lon2);
                if (dist < minDist) {
                    minDist = dist;
                    bestNode1 = node1;
                    bestNode2 = node2;
                }
            }
        }

        return bestNode1 != null ? new NodePair(bestNode1, bestNode2, minDist) : null;
    }

    // 更新统计信息方法
    private static void printStatistics(Map<Long, Map<String, Object>> nodeMap, 
                                      List<List<Long>> wayNodeLists,
                                      List<List<Long>> relationNodeLists) {
        System.out.println("\n=== OSM文件统计 ===");
        System.out.println("总节点数: " + nodeMap.size());
        System.out.println("总way数: " + wayNodeLists.size());
        System.out.println("总relation数: " + relationNodeLists.size());
        
        // 统计way中的节点
        int totalWayNodes = wayNodeLists.stream()
            .mapToInt(List::size)
            .sum();
        System.out.println("Way中的节点总数: " + totalWayNodes);
        
        // 统计relation中的way
        int totalRelationWays = relationInfoList.stream()
            .mapToInt(r -> ((List<Long>)r.get("ways")).size())
            .sum();
        System.out.println("Relation中way的总数: " + totalRelationWays);
        
        // 连通性统计
        int connectedNodes = 0;
        int totalEdges = 0;
        for (Map.Entry<Long, Map<String, Object>> entry : nodeMap.entrySet()) {
            @SuppressWarnings("unchecked")
            List<Integer> neighbors = (List<Integer>) entry.getValue().get("Neighbor");
            if (!neighbors.isEmpty()) {
                connectedNodes++;
                totalEdges += neighbors.size();
            }
        }
        
        System.out.println("\n=== 连通性统计 ===");
        System.out.println("连通节点数: " + connectedNodes + "/" + nodeMap.size());
        System.out.println("连通率: " + String.format("%.2f%%", (double)connectedNodes/nodeMap.size() * 100));
        System.out.println("平均边数: " + String.format("%.2f", (double)totalEdges/nodeMap.size()));

        // 添加交叉点统计
        int intersectionNodes = 0;
        for (Map.Entry<Long, Map<String, Object>> entry : nodeMap.entrySet()) {
            @SuppressWarnings("unchecked")
            List<Integer> neighbors = (List<Integer>) entry.getValue().get("Neighbor");
            if (neighbors.size() > 2) {  // 超过2个连接的点可能是交叉点
                intersectionNodes++;
            }
        }
        
        System.out.println("潜在交叉点数量: " + intersectionNodes);
    }

    // 添加NodeDistance辅助类
    private static class NodeDistance {
        final Long nodeId;
        final double distance;

        NodeDistance(Long nodeId, double distance) {
            this.nodeId = nodeId;
            this.distance = distance;
        }
    }

    public static void main(String[] args) throws DocumentException, IOException {

        String inputh = "D:\\Gaia\\src\\main\\resources\\Test.osm";
        String outputh = "D:\\Gaia\\src\\main\\resources\\Test.json";
        getMap(inputh,outputh);
    }
}
