package util;

import Class.node;
import ckks.CKKSHelper;
import lombok.SneakyThrows;

import java.io.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 加密图管理器 - 按阻塞比例保存和加载加密的地图数据
 * 修复版：增加了 ii2i 和 oi2i 的保存与加载
 */
public class EncryptedGraphManager {
    // 请确保路径正确
    private static final String ENCRYPTED_GRAPH_DIR = "D:\\NavTest\\encrypted_graphs";
    
    @SneakyThrows
    public static void saveEncryptedGraph(String graphKey, double blockageRatio,
                                        ConcurrentHashMap<Integer, node> apl,
                                        ConcurrentHashMap<Long, Integer> i2i,
                                        ConcurrentHashMap<Long, Long> ii2i,  // 👈 新增参数
                                        ConcurrentHashMap<Long, Long> oi2i,  // 👈 新增参数
                                        CKKSHelper ckks) {
        File dir = new File(ENCRYPTED_GRAPH_DIR);
        if (!dir.exists()) dir.mkdirs();
        
        String blockageKey = String.format("%.0f", blockageRatio * 100);
        String filePath = ENCRYPTED_GRAPH_DIR + "\\encrypted_graph_" + graphKey + "_blockage" + blockageKey + ".ser";
        
        // 创建包含所有映射的数据对象
        EncryptedGraphData graphData = new EncryptedGraphData(apl, i2i, ii2i, oi2i, blockageRatio);
        
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filePath))) {
            oos.writeObject(graphData);
        }
        
        System.out.println("✅ 加密图(含完整映射)已保存: " + filePath);
    }
    
    @SneakyThrows
    public static EncryptedGraphData loadEncryptedGraph(String graphKey, double blockageRatio) {
        String blockageKey = String.format("%.0f", blockageRatio * 100);
        String filePath = ENCRYPTED_GRAPH_DIR + "\\encrypted_graph_" + graphKey + "_blockage" + blockageKey + ".ser";
        File file = new File(filePath);
        
        if (!file.exists()) {
            return null;
        }
        
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filePath))) {
            EncryptedGraphData graphData = (EncryptedGraphData) ois.readObject();
            System.out.println("✅ 加密图(含完整映射)已加载: " + filePath);
            return graphData;
        } catch (Exception e) {
            System.err.println("⚠️ 缓存文件损坏或版本不兼容，自动删除: " + e.getMessage());
            file.delete();
            return null;
        }
    }
    
    public static boolean encryptedGraphExists(String graphKey, double blockageRatio) {
        String blockageKey = String.format("%.0f", blockageRatio * 100);
        String filePath = ENCRYPTED_GRAPH_DIR + "\\encrypted_graph_" + graphKey + "_blockage" + blockageKey + ".ser";
        return new File(filePath).exists();
    }
    
    public static void printCacheStatus(String graphKey, double[] allBlockageRatios) {
        System.out.println("\n📁 加密图缓存状态:");
        for (double targetRatio : allBlockageRatios) {
            boolean exists = encryptedGraphExists(graphKey, targetRatio);
            System.out.printf("  阻塞比例 %.0f%%: %s\n", targetRatio * 100, exists ? "✅ 已缓存" : "❌ 未缓存");
        }
    }
    
    /**
     * 数据容器类
     */
    public static class EncryptedGraphData implements Serializable {
        private static final long serialVersionUID = 2L; // 版本号升级
        
        private ConcurrentHashMap<Integer, node> apl;
        private ConcurrentHashMap<Long, Integer> i2i;
        private ConcurrentHashMap<Long, Long> ii2i; // 👈 新增字段
        private ConcurrentHashMap<Long, Long> oi2i; // 👈 新增字段
        private double blockageRatio;
        
        public EncryptedGraphData(ConcurrentHashMap<Integer, node> apl, 
                                ConcurrentHashMap<Long, Integer> i2i,
                                ConcurrentHashMap<Long, Long> ii2i,
                                ConcurrentHashMap<Long, Long> oi2i,
                                double blockageRatio) {
            this.apl = apl; // 不再深拷贝，提高效率
            this.i2i = i2i;
            this.ii2i = ii2i;
            this.oi2i = oi2i;
            this.blockageRatio = blockageRatio;
        }
        
        public ConcurrentHashMap<Integer, node> getApl() { return apl; }
        public ConcurrentHashMap<Long, Integer> getI2i() { return i2i; }
        public ConcurrentHashMap<Long, Long> getIi2i() { return ii2i; } // 👈 Getter
        public ConcurrentHashMap<Long, Long> getOi2i() { return oi2i; } // 👈 Getter
        public double getBlockageRatio() { return blockageRatio; }
    }
}