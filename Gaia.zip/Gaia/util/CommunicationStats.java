package util;

import java.io.Serializable;

/**
 * 通信统计 - 基于实际密码学参数
 */
public class CommunicationStats implements Serializable {
    private static final long serialVersionUID = 1L;
    
    // 基于论文Table II的参数
    private static final int PUBLIC_KEY_SIZE = 1024;    // |pk| = 1024 bits = 128 bytes
    private static final int SECRET_KEY_SIZE = 512;     // |sk| = 512 bits = 64 bytes (每个ki)
    private static final int PRP_SIZE = 256;            // |PRP| = 256 bits = 32 bytes
    private static final int HASH_SIZE = 256;           // |H1| = SHA256 = 32 bytes
    private static final int HMAC_SIZE = 256;           // |H2| = HMAC-SHA256 = 32 bytes
    private static final int RANDOM_NUMBER_SIZE = 64;   // |r| = 64 bits = 8 bytes
    private static final int CIPHERTEXT_SIZE = 2048;    // CKKS密文大小估算
    
    // 通信组件大小（字节）
    private long encryptedGraphUploadSize;
    private long tokenUploadSize;  
    private long resultDownloadSize;
    private long interactionDataSize;
    private int interactionRounds;
    
    // 计时相关（可选）
    private long graphUploadStartTime;
    private long graphUploadEndTime;
    private long tokenUploadStartTime;
    private long tokenUploadEndTime;
    private long resultDownloadStartTime;
    private long resultDownloadEndTime;
    
    public CommunicationStats() {}
    
    // 🔥 新增：计时方法
    /**
     * 模拟加密图上传开始
     */
    public void startGraphUpload() {
        this.graphUploadStartTime = System.currentTimeMillis();
        System.out.println("  📤 开始加密图上传模拟...");
    }

    /**
     * 模拟加密图上传结束
     */
    public void endGraphUpload() {
        this.graphUploadEndTime = System.currentTimeMillis();
        long duration = graphUploadEndTime - graphUploadStartTime;
        System.out.println("  ✅ 加密图上传模拟完成 (" + duration + " ms)");
    }

    /**
     * 模拟令牌上传开始
     */
    public void startTokenUpload() {
        this.tokenUploadStartTime = System.currentTimeMillis();
        System.out.println("  📤 开始令牌上传模拟...");
    }

    /**
     * 模拟令牌上传结束
     */
    public void endTokenUpload() {
        this.tokenUploadEndTime = System.currentTimeMillis();
        long duration = tokenUploadEndTime - tokenUploadStartTime;
        System.out.println("  ✅ 令牌上传模拟完成 (" + duration + " ms)");
    }

    /**
     * 模拟结果下载开始
     */
    public void startResultDownload() {
        this.resultDownloadStartTime = System.currentTimeMillis();
        System.out.println("  📥 开始结果下载模拟...");
    }

    /**
     * 模拟结果下载结束
     */
    public void endResultDownload() {
        this.resultDownloadEndTime = System.currentTimeMillis();
        long duration = resultDownloadEndTime - resultDownloadStartTime;
        System.out.println("  ✅ 结果下载模拟完成 (" + duration + " ms)");
    }
    
    /**
     * 基于实际密码学参数估算通信量
     */
    public void calculateForScenario(int nodeCount, int waypointCount, int constraintPairs) {
        // 1. 加密图上传 = 公钥 + 加密的节点坐标
        // 每个节点：2个坐标 × 密文大小
        this.encryptedGraphUploadSize = PUBLIC_KEY_SIZE + (nodeCount * 2 * CIPHERTEXT_SIZE);
        
        // 2. 令牌上传 = 起点 + 终点 + 途径点的加密令牌
        // 每个TokenNode: 2个加密坐标 + 身份信息
        int tokenNodeSize = (2 * CIPHERTEXT_SIZE) + 64; // 64 bytes for ID etc.
        this.tokenUploadSize = (2 + waypointCount) * tokenNodeSize; // 起点+终点+途径点
        
        // 3. 结果下载 = 加密路径结果
        // 每个路径段: 加密节点 + 路径信息
        int pathSegmentSize = CIPHERTEXT_SIZE + 128; // 加密距离 + 路径数据
        this.resultDownloadSize = (waypointCount + 1) * pathSegmentSize; // 段数 = 途径点+1
        
        // 4. 交互数据 = GC协议交互 (基于FastGC)
        // 每轮交互: 混淆电路数据 + 随机数
        int gcRoundSize = 4096; // FastGC每轮交互大小估算
        this.interactionRounds = 2 + constraintPairs; // 基础2轮 + 约束相关轮数
        this.interactionDataSize = interactionRounds * gcRoundSize;
    }
    
    /**
     * 基于论文参数的详细计算
     */
    public void calculateDetailedForScenario(int nodeCount, int waypointCount, int constraintPairs) {
        // 加密图组件
        long publicKeyComponent = PUBLIC_KEY_SIZE;
        long nodeCoordinatesComponent = nodeCount * 2 * CIPHERTEXT_SIZE;
        this.encryptedGraphUploadSize = publicKeyComponent + nodeCoordinatesComponent;
        
        // 令牌组件
        long tokenBaseSize = 2 * (2 * CIPHERTEXT_SIZE + 64); // 起点终点
        long waypointTokensSize = waypointCount * (2 * CIPHERTEXT_SIZE + 64);
        this.tokenUploadSize = tokenBaseSize + waypointTokensSize;
        
        // 结果组件  
        long pathBaseSize = 2 * CIPHERTEXT_SIZE; // 基础路径信息
        long waypointResultsSize = waypointCount * (CIPHERTEXT_SIZE + 128);
        this.resultDownloadSize = pathBaseSize + waypointResultsSize;
        
        // 交互组件 (GC协议)
        long gcBaseRounds = 2 * 4096; // 基础2轮GC
        long constraintRounds = constraintPairs * 2048; // 每个约束增加的开销
        this.interactionRounds = 2 + constraintPairs;
        this.interactionDataSize = gcBaseRounds + constraintRounds;
    }
    
    /**
     * 计算总通信量（字节）
     */
    public long getTotalCommunicationBytes() {
        return encryptedGraphUploadSize + tokenUploadSize + resultDownloadSize + interactionDataSize;
    }
    
    /**
     * 计算总通信量（KB）
     */
    public double getTotalCommunicationKB() {
        return getTotalCommunicationBytes() / 1024.0;
    }
    
    /**
     * 获取基于论文的通信代价公式
     */
    public String getCommunicationFormula(int nodeCount, int waypointCount, int constraintPairs) {
        calculateDetailedForScenario(nodeCount, waypointCount, constraintPairs);
        
        // 提取系数
        double baseComm = (encryptedGraphUploadSize + 2 * (2 * CIPHERTEXT_SIZE + 64) + 2 * CIPHERTEXT_SIZE + 2 * 4096) / 1024.0;
        double kCoefficient = ((2 * CIPHERTEXT_SIZE + 64) + (CIPHERTEXT_SIZE + 128)) / 1024.0;
        double cCoefficient = 2048.0 / 1024.0;
        
        return String.format(
            "基于论文参数的通信代价公式:\n" +
            "Total_Comm(N, k, c) = %.1f + %.2fk + %.1fc (KB)\n\n" +
            "参数说明:\n" +
            "- N = %d (节点数)\n" + 
            "- k = %d (途径点数)\n" +
            "- c = %d (约束对数)\n" +
            "- |pk| = %d bytes\n" +
            "- |sk_i| = %d bytes\n" + 
            "- |PRP| = %d bytes\n" +
            "- |H1| = |H2| = %d bytes\n" +
            "- 密文大小 ≈ %d bytes\n" +
            "- GC交互 ≈ %d bytes/轮",
            baseComm, kCoefficient, cCoefficient,
            nodeCount, waypointCount, constraintPairs,
            PUBLIC_KEY_SIZE, SECRET_KEY_SIZE, PRP_SIZE, HASH_SIZE,
            CIPHERTEXT_SIZE, 4096
        );
    }
    
    /**
     * 生成技术细节报告
     */
    public String getTechnicalDetails() {
        return String.format(
            "密码学参数配置:\n" +
            "├─ 公钥大小 (pk): %,d bytes\n" +
            "├─ 私钥大小 (sk_i): %,d bytes × 4\n" + 
            "├─ PRP大小: %,d bytes\n" +
            "├─ 哈希函数: SHA-256 (%,d bytes)\n" +
            "├─ 随机数 r: %,d bytes\n" +
            "├─ 密文大小: ≈ %,d bytes\n" +
            "└─ GC电路: FastGC, %,d bytes/轮\n\n" +
            "通信组件:\n" +
            "├─ 加密图: %,d bytes\n" +
            "├─ 令牌: %,d bytes\n" +
            "├─ 结果: %,d bytes\n" +
            "├─ 交互: %,d bytes (%d 轮)\n" +
            "└─ 总计: %,d bytes (%.2f KB)",
            PUBLIC_KEY_SIZE, SECRET_KEY_SIZE, PRP_SIZE, HASH_SIZE,
            RANDOM_NUMBER_SIZE, CIPHERTEXT_SIZE, 4096,
            encryptedGraphUploadSize, tokenUploadSize, resultDownloadSize,
            interactionDataSize, interactionRounds, getTotalCommunicationBytes(), getTotalCommunicationKB()
        );
    }
    
    // Getters
    public long getEncryptedGraphUploadSize() { return encryptedGraphUploadSize; }
    public long getTokenUploadSize() { return tokenUploadSize; }
    public long getResultDownloadSize() { return resultDownloadSize; }
    public long getInteractionDataSize() { return interactionDataSize; }
    public int getInteractionRounds() { return interactionRounds; }
    
    /**
     * 生成CSV行数据
     */
    public String toCSVLine() {
        return String.format("%d,%d,%d,%d,%d,%d,%.2f", 
            encryptedGraphUploadSize, tokenUploadSize, resultDownloadSize, 
            interactionDataSize, interactionRounds, getTotalCommunicationBytes(),
            getTotalCommunicationKB());
    }
    
    /**
     * 打印详细统计
     */
    public void printDetailedStats(int nodeCount, int waypointCount, int constraintPairs) {
        calculateDetailedForScenario(nodeCount, waypointCount, constraintPairs);
        
        System.out.println("\n📊 基于论文参数的通信统计:");
        System.out.println("  📁 加密图上传: " + String.format("%,d", encryptedGraphUploadSize) + " bytes");
        System.out.println("    ├─ 公钥: " + PUBLIC_KEY_SIZE + " bytes");
        System.out.println("    └─ 节点坐标: " + String.format("%,d", nodeCount * 2 * CIPHERTEXT_SIZE) + " bytes (" + nodeCount + "节点)");
        
        System.out.println("  🎫 令牌上传: " + String.format("%,d", tokenUploadSize) + " bytes");
        System.out.println("    ├─ 起点终点: " + String.format("%,d", 2 * (2 * CIPHERTEXT_SIZE + 64)) + " bytes");
        System.out.println("    └─ 途径点: " + String.format("%,d", waypointCount * (2 * CIPHERTEXT_SIZE + 64)) + " bytes (" + waypointCount + "个)");
        
        System.out.println("  📥 结果下载: " + String.format("%,d", resultDownloadSize) + " bytes");
        System.out.println("    ├─ 基础路径: " + String.format("%,d", 2 * CIPHERTEXT_SIZE) + " bytes");
        System.out.println("    └─ 途径段: " + String.format("%,d", waypointCount * (CIPHERTEXT_SIZE + 128)) + " bytes");
        
        System.out.println("  🔄 交互数据: " + String.format("%,d", interactionDataSize) + " bytes (" + interactionRounds + " 轮GC)");
        System.out.println("    ├─ 基础交互: " + String.format("%,d", 2 * 4096) + " bytes (2轮)");
        System.out.println("    └─ 约束交互: " + String.format("%,d", constraintPairs * 2048) + " bytes (" + constraintPairs + "约束)");
        
        System.out.println("  📡 总通信量: " + String.format("%,d", getTotalCommunicationBytes()) + " bytes (" + 
                         String.format("%.2f", getTotalCommunicationKB()) + " KB)");
    }
}