package User;

import Algorithm.Floyd_Warshall_1;
import Omega.NewOmega;
import Omega.PK;
import Class.node;
import Omega.SK;
import ckks.CKKSHelper;
import ckks.Ciphertext;
import ckks.PublicKeys;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import it.unisa.dia.gas.jpbc.Element;
import lombok.Getter;
import lombok.Setter;
import lombok.SneakyThrows;
import org.apache.commons.codec.binary.Base64;

import java.io.File;
import java.math.BigInteger;
import java.util.concurrent.ConcurrentHashMap;

@Getter
@Setter
public class PreEnc {

    private final Ciphertext[][] Encnode;//0:x,1:y
    private final Ciphertext[][] Encesd;
//    private PK pk;

    public PreEnc(Ciphertext[][] encnode, Ciphertext[][] encesd) {
        Encnode = encnode;
        Encesd = encesd;
    }

    @SneakyThrows
    public PreEnc(ConcurrentHashMap<Integer, node> apl, Floyd_Warshall_1 fw, CKKSHelper ckks) {


        Encesd = new Ciphertext[apl.size()][apl.size()];
        //Encesd存放距离
        Encnode = new Ciphertext[apl.size() ][2];
        //Encnode[node.index] = m(node.x),m(node.y)里存放的是每个节点x和y的加密


        for (node node : apl.values()) {

            Ciphertext[] res = new Ciphertext[2];

            //res[0] = omega.Enc(BigInteger.valueOf(node.x));
            res[0] = ckks.encrypt(node.x);
            //res[1] = omega.Enc(BigInteger.valueOf(node.y));
            res[1] = ckks.encrypt(node.y);
            Encnode[node.index] = res;


        }



        var g = fw.getGraph();
        //int ww = 0;
        for (int i = 0; i < apl.size(); i++) {

            for (int j = 0; j <= i; j++) {
                int dis = g[i][j];
                //Element tmp = omega.Enc(new BigInteger(String.valueOf(dis)));
                Ciphertext tmp = ckks.encrypt(dis);
                if (i == j) {
                    //Encesd[i][j] = pk.get_G1().newOneElement();
                    Encesd[i][j] = ckks.encrypt(0);
                    continue;
                }

                Encesd[i][j] = tmp;
                Encesd[j][i] = tmp;

            }
        }

    }




}
