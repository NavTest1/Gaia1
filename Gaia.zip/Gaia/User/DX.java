package User;

import Class.node;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.Data;
import lombok.SneakyThrows;
import org.apache.commons.codec.binary.Base64;

import javax.crypto.IllegalBlockSizeException;
import java.io.File;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.concurrent.ConcurrentHashMap;

import static java.lang.System.arraycopy;

@Data
public class DX {


    private  PRF_PRP_Hash pph;
    private final ConcurrentHashMap<BigInteger, byte[]> dx;
    private  SecureRandom rng;
    private  ConcurrentHashMap<Long, Long> ii2i;
    private BigInteger kv;

    public DX(PRF_PRP_Hash pph, ConcurrentHashMap<Long, Long> ii2i) {
        this.pph = pph;
        this.ii2i = ii2i;
        rng = new SecureRandom();
        dx = new ConcurrentHashMap<>();
    }
    public DX(ConcurrentHashMap<BigInteger, byte[]> _dx){
        this.dx=_dx;

    }
//    Set<String>codeset= Sets.newConcurrentHashSet();
    public BigInteger getKv() {
        return kv;
    }
    public int getLen(){
        return dx.size();
    }
    /*
     * 参数：对应数组的下标，临时密钥的长度，点对象
     * */
    public void add(node n1) throws IllegalBlockSizeException {//生成256位的暂时密钥
        byte[] f4 = new byte[32];
        do {
            n1.kv = new BigInteger(256, rng);
        } while (n1.kv.toByteArray().length != 32);
        //n1.kv长度为32位
        do {
            n1.rv = new BigInteger(256, rng);
        } while (n1.rv.toByteArray().length != 32);
        //n1.rv长度为32位
        pph.use_F4(BigInteger.valueOf(ii2i.get(n1.id)).toByteArray(), f4);
        //f4 = f4(节点suanid) 32位
        byte[] tsecondB = new byte[32];
        byte[] btmp = ByteTools.XOR(n1.kv.toByteArray(), f4);
        //btmp = f4(n1suanid) 异或 n1.kv
        arraycopy(btmp, 0, tsecondB, 0, btmp.length);
        //tsecondB = f4(n1suanid) 异或 n1.kv
        byte[] secondB = ByteTools.merge(BigInteger.valueOf(n1.index).toByteArray(), tsecondB);
        //secondB = n1索引||f4(n1suanid) 异或 n1.kv
        byte[] k = BigInteger.valueOf(ii2i.get(n1.id)).toByteArray(), k1 = new byte[k.length];
        pph.use_T2(k, k1);
        //k1 = t2(n1suanid)
        BigInteger bk1 = new BigInteger(k1);
        dx.put(bk1, secondB);
        //dx 放入 (T2(suanid),n1索引||f4(n1suanid) 异或 n1.kv)

    }

    protected int get_addr(node n1) throws IllegalBlockSizeException {//加密时候用的API
        byte[] msg = new byte[32];
        String ts = String.valueOf(ii2i.get(n1.id));
        pph.use_F4(ts.getBytes(), msg);
        //msg = f4(n1suanid)
        byte[] k = BigInteger.valueOf(ii2i.get(n1.id)).toByteArray(), k1 = new byte[k.length];
        pph.use_T2(k, k1);
        //k1 = t2(n1suanid)
        BigInteger bk1 = new BigInteger(k1);
        //bk1 = t2(n1suanid)
        byte[] sv = dx.get(bk1);
        //sv = n1索引||f4(n1suanid) 异或 n1.kv
        byte[] ind = new byte[sv.length - 32];
        arraycopy(sv, 0, ind, 0, sv.length - 32);
        //ind = 索引
        return new BigInteger(ind).intValue();

    }


    public int getIndex(String T2v, String F4v) {//解密时候用的API
        byte[] bF4v = new BigInteger(F4v).toByteArray();
        byte[] b1 = dx.get(new BigInteger(T2v));
        //b1 = n1索引||f4(n1suanid) 异或 n1.kv
        byte[] secondB = new byte[32];
        byte[] firstB = new byte[b1.length - 32];
        for (int i = b1.length - 32, j = 0; i < b1.length; i++) {
            secondB[j] = b1[i];
            ++j;
        }
        arraycopy(b1, 0, firstB, 0, b1.length - 32);
        //firstB = n1索引
        //secondB = f4(n1suanid) 异或 n1.kv
        this.kv = new BigInteger(ByteTools.XOR(secondB, bF4v));
        //this.kv = n1.kv
        return new BigInteger(firstB).intValue();
        //返回n1的索引值
    }
    @SneakyThrows
    public void writeDX(String fileName)  {
        ObjectMapper mapper=new ObjectMapper();
        ObjectNode rootNode=mapper.createObjectNode();
        ArrayNode data=mapper.createArrayNode();
        dx.forEachEntry(ii2i.mappingCount()<<2,e->{
            rootNode.put(String.valueOf(e.getKey()), Base64.encodeBase64String(e.getValue()));
        });
        mapper.writeValue(new File(fileName),rootNode);
    }
}
