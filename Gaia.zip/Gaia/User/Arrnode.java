package User;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;
import java.math.BigInteger;

@Getter
@Setter
@AllArgsConstructor
public class Arrnode implements Serializable {
    private final byte[] first;
    private final BigInteger second;
    //     first = ex||ey 异或 H2（n1.kv||n1.rv）
    //     second = n1.rv

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("first", new BigInteger(first))
                .append("second", second).toString();
    }
}
