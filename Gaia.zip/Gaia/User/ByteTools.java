package User;

import java.nio.ByteBuffer;
import java.util.Arrays;
import java.nio.ByteOrder;

public class ByteTools {
    public static byte[] merge(byte[] b1, byte[] b2) {
        byte[] res = new byte[b1.length + b2.length];
        System.arraycopy(b1, 0, res, 0, b1.length);
        System.arraycopy(b2, 0, res, b1.length, b2.length);
        return res;
    }

    public static byte[] merge3(byte[] b1, byte[] b2, byte[] b3) {
        byte[] res = new byte[b1.length + b2.length + b3.length];
        System.arraycopy(b1, 0, res, 0, b1.length);
        System.arraycopy(b2, 0, res, b1.length, b2.length);
        System.arraycopy(b3, 0, res, b1.length + b2.length, b3.length);
        return res;
    }

    public static byte[] XOR(byte[] A, byte[] B) {
        int n = A.length;
        int m = B.length;
        int k = Math.max(n, m);
        byte[] res = new byte[k];
        for (int i = 0; i < k; i++) {
            res[i] = (byte) (A[i % n] ^ B[i % m]);
        }
        return res;

    }

    public static byte[] XOR1(byte[] A, byte[] B) {
        int n = A.length;
        int m = B.length;
//        int k = Math.min(n, m);
        byte[] res = new byte[A.length];
        for (int i = 0; i < A.length; i++) {
            res[i] = (byte) (A[i % n] ^ B[i % m]);
        }
        return res;

    }

    public static byte[] DelRearZero(byte[] A) {
        int len = 0;
        for (int i = A.length - 1; i >= 0; i--) {
            if (A[i] != (byte) 0) {
                len = i + 1;
                break;
            }

        }
        return Arrays.copyOfRange(A, 0, len);
    }

    public static void _DEBUGBYTES(byte[] a) {
//        System.out.printf("%s: ", a.);
        for (int i = 0; i < a.length; i++) {
            System.out.printf("%d:%d ", i, a[i]);
        }
        System.out.println();

    }
    // long[] 转 byte[]
    public static byte[] longArrayToBytes(long[] longs) {
        if (longs == null) {
            throw new IllegalArgumentException("Input array cannot be null");
        }
        ByteBuffer buffer = ByteBuffer.allocate(longs.length * 8);
        buffer.order(ByteOrder.BIG_ENDIAN);  // 明确指定字节序
        for (long value : longs) {
            buffer.putLong(value);
        }
        return buffer.array();
    }

    // byte[] 转回 long[]
    public static long[] bytesToLongArray(byte[] bytes) {
        if (bytes == null) {
            throw new IllegalArgumentException("Input array cannot be null");
        }
        if (bytes.length % 8 != 0) {
            throw new IllegalArgumentException("Input byte array length must be a multiple of 8");
        }
        ByteBuffer buffer = ByteBuffer.wrap(bytes);
        buffer.order(ByteOrder.BIG_ENDIAN);  // 明确指定字节序
        long[] longs = new long[bytes.length / 8];
        for (int i = 0; i < longs.length; i++) {
            longs[i] = buffer.getLong();
        }
        return longs;
    }
    public static void main(String[] args) {
//        byte[] kv = {47, -59, -18, -51};
//        byte[] btmp ={-48, 98, -93, -86} ;
//        byte[] bf4v = {-89, 77, 1 - 3, 60};
//        byte[] res1 = XOR(bf4v, btmp);
//        _DEBUGBYTES(res1);
//        byte[] res = XOR(kv, bf4v);
//        _DEBUGBYTES(res);
//        byte[] kv = {37, 61, 86, -52};
//        byte[] btmp = {16, 124, 79, 106};
//        byte[] bf4v = {53, 65, 25, -90};
//        byte[] res1 = XOR(bf4v, btmp);
//        _DEBUGBYTES(res1);
//        byte[] res = XOR(bf4v, kv);
//        _DEBUGBYTES(res);

        byte[] kv = {32, -83, 85, -36};
        byte[] btmp = {34, 30, -67, -112};
        byte[] bf4v = {2, -77, -24, 76};
        byte[] res1 = XOR(bf4v, btmp);
        _DEBUGBYTES(res1);
        byte[] res = XOR(bf4v, kv);
        _DEBUGBYTES(res);


    }

}
