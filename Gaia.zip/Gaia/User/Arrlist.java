package User;


import Algorithm.Floyd_Warshall_1;
import Class.node;
import Class.PD_oracle;
import com.baomidou.mybatisplus.core.toolkit.SystemClock;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.SneakyThrows;
import org.apache.commons.codec.binary.Base64;

import javax.crypto.IllegalBlockSizeException;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;

@Data
@NoArgsConstructor
public class Arrlist {
    public Arr[] data;
    private ConcurrentHashMap<Long, Long> ii2i;

    public Arrlist(Floyd_Warshall_1 _fw, ConcurrentHashMap<Integer, node> apl, PRF_PRP_Hash pph, DX dx, PreEnc preEnc, ConcurrentHashMap<Long, Long> ii2i, PD_oracle pdo) throws IllegalBlockSizeException, InterruptedException, IOException {
        this.ii2i = ii2i;
        data = new Arr[ii2i.size()];

        for (int i = 0; i < apl.size(); i++) {
//            long prenodest=System.currentTimeMillis();
            node tmpNode = apl.get(i);
            //索引获取节点
            Arr tmpArr = new Arr(tmpNode, pph, _fw, pdo, apl, preEnc, ii2i);

            //index = 节点索引
            tmpArr. buildArr();
            data[tmpNode.index] = tmpArr;
        }

    }

    public Arrlist(ConcurrentHashMap<Long, Arrnode>[] data1, ConcurrentHashMap<Long, Long> ii2i1) {
        this.ii2i = ii2i1;
        data = new Arr[data1.length];
        for (int i = 0; i < data1.length; i++) {
            data[i]=new Arr();
            data[i].data = new ConcurrentHashMap<>();
            data[i].data = data1[i];
        }
    }



    @SneakyThrows
    public void WriteArrList(String fillName) {
        ObjectMapper mapper = new ObjectMapper();
        ObjectNode rootNode = mapper.createObjectNode();
        for (int i = 0, dataLength = data.length; i < dataLength; i++) {
            Arr datum = data[i];
            ObjectNode rootNode1 = mapper.createObjectNode();
            ConcurrentHashMap<Long, Arrnode> map = datum.data;
            map.forEachEntry(ii2i.mappingCount() << 2, e -> {
                ObjectNode rootNode2 = mapper.createObjectNode();
                String key = String.valueOf(e.getKey());
                Arrnode arrnode = e.getValue();
                rootNode2.put("first", Base64.encodeBase64String(arrnode.getFirst()));
                rootNode2.put("second", arrnode.getSecond());
                rootNode1.set(key, rootNode2);
            });
            rootNode.set(String.valueOf(i), rootNode1);
        }
        mapper.writeValue(new File(fillName), rootNode);
    }


}
