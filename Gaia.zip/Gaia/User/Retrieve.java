package User;

import Omega.NewOmega;
import Omega.PK;
import Omega.SK;
import Proxy.CT;
import Class.TokenNode;
import Class.PathRecovery;
import ckks.CKKSHelper;
import ckks.Ciphertext;
import ckks.Context;
import ckks.PublicKeys;
import it.unisa.dia.gas.jpbc.Element;
import lombok.SneakyThrows;

import java.io.IOException;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.ConcurrentHashMap;

import static util.JsonUtil.*;

public class Retrieve {
    public static String asp;
    private static ConcurrentHashMap<Long, Long> ii2i = new ConcurrentHashMap<>();
    private static ConcurrentHashMap<Long, Long> oi2i = new ConcurrentHashMap<>();
    private static ConcurrentHashMap<Long, Integer> i2i = new ConcurrentHashMap<>();
    private static DX dx;
    private static PublicKeys pk;
    private static Context context;
    private static CKKSHelper ckks;
    private static ConcurrentHashMap<Long, Arrnode>[] arrlist;
    private static PRF_PRP_Hash pph;
   // private static NewOmega omega;

    public static void TestSetter(ConcurrentHashMap<Long, Long> ii2i1, ConcurrentHashMap<Long, Integer> i2i1, DX dx1, ConcurrentHashMap<Long, Arrnode>[] arrlist1, PRF_PRP_Hash pph1, ConcurrentHashMap<Long, Long> oi2i1, PublicKeys pk1,Context mcontext) throws IOException {
        ii2i = ii2i1;
        oi2i = oi2i1;
        i2i = i2i1;
        dx = dx1;
        arrlist = arrlist1;
        pph = pph1;
        pk = pk1;
        context =mcontext;
        ckks = new CKKSHelper(2, 4, 10, 20);
        ckks.SetContext(context);
        ckks.SetPublicKeys(pk);

    }

//    public static void getDxAndArr(String userPath) {
//        ConcurrentHashMap<Long, Arrnode>[] arrfromJSON = getArrfromJSON(userPath + "/ArrList.json");
//        ConcurrentHashMap<BigInteger, byte[]> dXformJSON = getDXformJSON(userPath + "/DX.json");
//        SK sk = GetSKFromJson(userPath + "/pphsk.json");
//        getMapInJson(i2i, ii2i, oi2i);
//        pph = new PRF_PRP_Hash(sk);
//        dx = new DX(dXformJSON);
//        arrlist = arrfromJSON;
//        omega = new NewOmega();
//        pk = omega.getPK("D:\\Gaia\\src\\main\\resources\\PK.json");
//        omega.SetByPk(pk);
//    }
//i2i 地图id --- 索引
//ii2i 地图id  ---  算法id
//oi2i 算法id  ---  地图id
//tokennode 里id  为 算法id

    @SneakyThrows
    public static PathRecovery getEncShortestDistanceAndShortestPath(ArrayList<TokenNode> list) {
//        Omega omega = new Omega();
//        PK pk = omega.getPK("resources/PK.json");
//        omega.SetByPk(pk);
        //Element res = omega.Enc(BigInteger.ZERO);
        Ciphertext res = ckks.encrypt(0);
        //res = m(0)
        TokenNode p1 = list.get(0);
        //StringBuilder aspBuilder = new StringBuilder();
        ArrayList<String> path = new ArrayList();

        //添加的是索引
        //aspBuilder.append(i2i.get(oi2i.get(p1.id)));
        path.add(String.valueOf(i2i.get(oi2i.get(p1.id))));

        //aspBuilder.append("->");

        for (int i = 1; i < list.size(); i++) {
            System.out.println(i);
            TokenNode p2 = list.get(i);
            byte[] p2msg = BigInteger.valueOf(p2.id).toByteArray(), //msg需要ii2i变换一下
                    p2tag = new byte[p2msg.length];
            //p2msg = p2.vi
            pph.use_T1(p2msg, p2tag);
            //p2tag = p2.T1(vi)
            int index = dx.getIndex(p1.T2str, p1.F4str);
            //index = p1.vi
            //dx.kv = p1.kv
            ConcurrentHashMap<Long, Arrnode> map = arrlist[index];

            //map =            (H1(vj)||SPvivj异或F3(H1(rvj))||Esdvivj   异或   tagh2 = H2(kvi||rvj)   ,   rvj)
            Arrnode arrnode = map.get(new BigInteger(p2tag).longValue());
            byte[] rv2 = arrnode.getSecond().toByteArray();
            //rv2 = p2.rv
            byte[] first = arrnode.getFirst();
            //first = (H1(vj)||SPvivj异或F3(H1(rvj))||Esdvivj   异或   tagh2 = H2(kvi||rvj)
            byte[] kv1 = dx.getKv().toByteArray();
            //kv1 = p1.kv
            byte[] h2msg = ByteTools.merge(kv1, rv2), h2tag = new byte[32];
            //h2msg = p1.kv || p2.rv
            pph.use_H2(h2msg, h2tag);
            //h2tag = H2(p1.kv || p2.rv)
            byte[] xorFirst = ByteTools.XOR(first, h2tag);
            //xorFirst = (H1(vj)||SPvivj异或F3(H1(rvj))||Esdvivj
            byte[] esd = Arrays.copyOfRange(xorFirst, xorFirst.length - 516, xorFirst.length);
            byte[] correctEsd = ByteTools.DelRearZero(esd);

            //Element ElemEsd = pk.get_G().newElementFromBytes(correctEsd);
            Ciphertext ElemEsd =new Ciphertext(context);
            ElemEsd.deserialize(ByteTools.bytesToLongArray(correctEsd));
            //res = omega.add(res, ElemEsd);
            res =ckks.add(res,ElemEsd);
            //开始解码，获得esd，并用同态加法加和

            byte[] BspXorF3H1 = Arrays.copyOfRange(xorFirst, 32, xorFirst.length - 516);
            byte[] f3h1 = new byte[32];
            pph.use_F3(pph.use_H1(rv2), f3h1);
            byte[] Bsp = ByteTools.XOR1(BspXorF3H1, f3h1);
            String sp12 = new String(Bsp, StandardCharsets.UTF_8);
            //aspBuilder.append(sp12);
            // 使用 split 方法拆分字符串
            String[] parts = sp12.split("->");

            // 将拆分后的元素添加到 ArrayList 中
            for (String part : parts) {
                if (!part.isEmpty()) {
                    path.add(part);
                }
            }

            //aspBuilder.append("->");//这个箭头不用加，esp结尾正好有多的一个箭头
            //aspBuilder.append(i2i.get(oi2i.get(p2.id)));
            path.add(String.valueOf(i2i.get(oi2i.get(p2.id))));
            //aspBuilder.append("->");
            p1 = p2;//开始迭代
//            CT ct=new CT(pk);
//            System.out.println("omega.Dec(res,pk,ct.getSk()) = " + omega.Dec(res, pk, ct.getSk()));

        }
        //aspBuilder.delete(aspBuilder.length() - 2, aspBuilder.length());
        //asp = aspBuilder.toString();
        //System.out.println(asp);
        //CT ct=new CT(pk);


        PathRecovery pathRecovery = new PathRecovery(res,path);
        return pathRecovery;
    }
}
