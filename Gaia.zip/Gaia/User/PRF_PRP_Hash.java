package User;


import Omega.SK;
import ckks.SecretKey;
import edu.biu.scapi.exceptions.FactoriesException;
import edu.biu.scapi.primitives.hash.CryptographicHash;
import edu.biu.scapi.primitives.hash.bc.BcSHA256;
import edu.biu.scapi.primitives.prf.PseudorandomFunction;
import edu.biu.scapi.primitives.prf.PseudorandomPermutation;
import edu.biu.scapi.primitives.prf.bc.BcHMAC;
import edu.biu.scapi.tools.Factories.PrfFactory;
import lombok.SneakyThrows;
import org.bouncycastle.util.encoders.Base64;

import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.spec.SecretKeySpec;
import java.math.BigInteger;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidParameterSpecException;
import java.util.Arrays;

public class PRF_PRP_Hash {
    private final PseudorandomFunction prfF3;
    private final PseudorandomFunction prfF4;
    private final PseudorandomPermutation prpT1;
    private final PseudorandomPermutation prpT2;
   //import edu.biu.scapi.primitives.prf.PseudorandomPermutation;
    private final BcHMAC H1;
    private final CryptographicHash H2;


    public PRF_PRP_Hash(int sksize, SK sk) throws FactoriesException, InvalidKeyException, NoSuchAlgorithmException, InvalidParameterSpecException {
        prpT2 = (PseudorandomPermutation) PrfFactory.getInstance().getObject("PrpFromPrfVarying");
        prpT1 = (PseudorandomPermutation) PrfFactory.getInstance().getObject("PrpFromPrfVarying");
        prfF4 = PrfFactory.getInstance().getObject("HMac(SHA-256)");
        prfF3 = PrfFactory.getInstance().getObject("HMac(SHA-256)");

        SecretKeySpec[] spec = getAlgorithmParameterSpec(sksize, sk);

        prpT1.setKey(spec[0]);
        prpT2.setKey(spec[1]);
        prfF3.setKey(spec[2]);
        prfF4.setKey(spec[3]);



        H1 = new BcHMAC("SHA-256");
        H1.setKey(spec[4]);
        H2 = new BcSHA256();
    }
    public PRF_PRP_Hash(int sksize, SecretKey sk) throws FactoriesException, InvalidKeyException, NoSuchAlgorithmException, InvalidParameterSpecException {
        prpT2 = (PseudorandomPermutation) PrfFactory.getInstance().getObject("PrpFromPrfVarying");
        prpT1 = (PseudorandomPermutation) PrfFactory.getInstance().getObject("PrpFromPrfVarying");
        prfF4 = PrfFactory.getInstance().getObject("HMac(SHA-256)");
        prfF3 = PrfFactory.getInstance().getObject("HMac(SHA-256)");

        SecretKeySpec[] spec = getAlgorithmParameterSpec(sksize, sk);

        prpT1.setKey(spec[0]);
        prpT2.setKey(spec[1]);
        prfF3.setKey(spec[2]);
        prfF4.setKey(spec[3]);



        H1 = new BcHMAC("SHA-256");
        H1.setKey(spec[4]);
        H2 = new BcSHA256();
    }
    @SneakyThrows
    public PRF_PRP_Hash(SecretKey sk) {
        prpT2 = (PseudorandomPermutation) PrfFactory.getInstance().getObject("PrpFromPrfVarying");
        prpT1 = (PseudorandomPermutation) PrfFactory.getInstance().getObject("PrpFromPrfVarying");
        prfF4 = PrfFactory.getInstance().getObject("HMac(SHA-256)");
        prfF3 = PrfFactory.getInstance().getObject("HMac(SHA-256)");
        H1 = new BcHMAC("SHA-256");
        H2 = new BcSHA256();//不用setKey
        String[] hash64 = sk.getHash64();

        // 添加 null 检查
        if (hash64 == null || hash64.length < 5) {
            throw new IllegalArgumentException("SecretKey的hash64数组不能为null且长度必须至少为5");
        }

        SecretKeySpec[] spec = new SecretKeySpec[5];
        KeyGenerator kg = KeyGenerator.getInstance("AES");
        byte[][] b64 = new byte[5][];
        for (int i = 0; i < hash64.length; i++) {
            if (hash64[i] == null) {
                throw new IllegalArgumentException("SecretKey的hash64数组第" + i + "个元素为null");
            }
            b64[i] = Base64.decode(hash64[i]);
            spec[i] = new SecretKeySpec(b64[i], kg.getAlgorithm());
        }
        prpT1.setKey(spec[0]);
        prpT2.setKey(spec[1]);
        prfF3.setKey(spec[2]);
        prfF4.setKey(spec[3]);
        H1.setKey(spec[4]);
    }

    @SneakyThrows
    private static SecretKeySpec[] getAlgorithmParameterSpec(int sksize, SK sk) {
        SecretKeySpec[] res = new SecretKeySpec[5];
        KeyGenerator kg = KeyGenerator.getInstance("AES");
        String[] base64str = new String[5];
        SecureRandom rng = new SecureRandom();
        byte[] seed = new byte[sksize / 8];
        for (int i = 0; i < 5; i++) {
            rng.nextBytes(seed);
            base64str[i] = new String(Base64.encode(seed));
            SecretKeySpec spec = new SecretKeySpec(seed, kg.getAlgorithm());
            res[i] = spec;
        }
        sk.set_K(base64str);
        return res;
    }
    @SneakyThrows
    private static SecretKeySpec[] getAlgorithmParameterSpec(int sksize, SecretKey sk) {
        SecretKeySpec[] res = new SecretKeySpec[5];
        KeyGenerator kg = KeyGenerator.getInstance("AES");
        String[] base64str = new String[5];
        SecureRandom rng = new SecureRandom();
        byte[] seed = new byte[sksize / 8];
        for (int i = 0; i < 5; i++) {
            rng.nextBytes(seed);
            base64str[i] = new String(Base64.encode(seed));
            SecretKeySpec spec = new SecretKeySpec(seed, kg.getAlgorithm());
            res[i] = spec;
        }
        sk.set_K(base64str);
        return res;
    }
    public static void main(String[] args) throws FactoriesException, NoSuchAlgorithmException, InvalidKeyException, IllegalBlockSizeException, InvalidParameterSpecException {
        SK sk = new SK();
        PRF_PRP_Hash pph = new PRF_PRP_Hash(256, sk);

        // 测试use_T1
        byte[] inputT1 = new BigInteger("12780234").toByteArray();
        byte[] outputT1 = new byte[inputT1.length];
        System.out.println("input1: " + "12780234");
        pph.use_T1(inputT1, outputT1);
        System.out.println("use_T1结果: " + new BigInteger(outputT1));

        // 测试use_T2
        byte[] inputT2 = new BigInteger("46769845").toByteArray();
        System.out.println("input2: " + "46769845");
        byte[] outputT2 = new byte[inputT2.length];
        pph.use_T2(inputT2, outputT2);
        System.out.println("use_T2结果: " + new BigInteger(outputT2));

        // 测试use_F3
        byte[] inputF3 = "Hello, World!".getBytes();
        byte[] outputF3 = new byte[32];
        pph.use_F3(inputF3, outputF3);
        System.out.println("use_F3结果: " + Arrays.toString(outputF3));

        // 测试use_F4
        byte[] inputF4 = "Another test".getBytes();
        byte[] outputF4 = new byte[32];
        pph.use_F4(inputF4, outputF4);
        System.out.println("use_F4结果: " + Arrays.toString(outputF4));

        // 测试use_H1
        byte[] inputH1 = "Message for H1".getBytes();
        byte[] outputH1 = pph.use_H1(inputH1);
        System.out.println("use_H1结果: " + Arrays.toString(outputH1));

        // 测试use_H2
        byte[] inputH2 = "Message for H2".getBytes();
        byte[] outputH2 = new byte[32];
        pph.use_H2(inputH2, outputH2);
        System.out.println("use_H2结果: " + Arrays.toString(outputH2));

        // 测试use_invT1
        byte[] inputInvT1 = outputT1;
        byte[] outputInvT1 = new byte[inputInvT1.length];
        System.out.println(inputInvT1.length);
        System.out.println(outputInvT1.length);
        pph.use_invT1(inputInvT1, outputInvT1);
        System.out.println("use_invT1结果: " + new BigInteger(outputInvT1));

        // 测试use_invT2
        byte[] inputInvT2 = outputT2;
        byte[] outputInvT2 = new byte[inputInvT2.length];
        pph.use_invT2(inputInvT2, outputInvT2);
        System.out.println("use_invT2结果: " + new BigInteger(outputInvT2));
    }

    @SneakyThrows
    public void SetKeyPPH(SK sk) {
        String[] hash64 = sk.getHash64();
        SecretKeySpec[] spec = new SecretKeySpec[5];
        KeyGenerator kg = KeyGenerator.getInstance("AES");
        byte[][] b64 = new byte[5][];
        for (int i = 0; i < hash64.length; i++) {
            b64[i] = Base64.decode(hash64[i]);
            spec[i] = new SecretKeySpec(b64[i], kg.getAlgorithm());
        }
        prpT1.setKey(spec[0]);
        prpT2.setKey(spec[1]);
        prfF3.setKey(spec[2]);
        prfF4.setKey(spec[3]);
        H1.setKey(spec[4]);
    }

    public void use_T1(byte[] in, byte[] out) throws IllegalBlockSizeException {
        prpT1.computeBlock(in, 0, in.length, out,0, out.length);

    }

    public void use_T2(byte[] in, byte[] out) {
        try {
            prpT2.computeBlock(in, 0, in.length, out, 0, out.length);
        } catch (IllegalBlockSizeException e) {
            System.out.println("in.length = " + in.length);
            e.printStackTrace();


        }

    }

    public void use_F3(byte[] in, byte[] out) throws IllegalBlockSizeException {

        prfF3.computeBlock(in, 0, in.length, out, 0, 32);

    }

    public void use_F4(byte[] in, byte[] out) throws IllegalBlockSizeException {
        prfF4.computeBlock(in, 0, in.length, out, 0, 32);
    }

    public byte[] use_H1(byte[] msg) {//BcHMAC("SHA-256")
        return H1.mac(msg, 0, msg.length);
    }

    public void use_H2(byte[] msg, byte[] tag) {    //BcSHA256


        H2.update(msg, 0, msg.length);
        H2.hashFinal(tag, 0);

    }

    @SneakyThrows
    public void use_invT1(byte[] in, byte[] out) {
        prpT1.invertBlock(in, 0, out, 0,in.length);
    }

    @SneakyThrows
    public void use_invT2(byte[] in, byte[] out) {
        prpT2.invertBlock(in, 0, out, 0,in.length);
    }

}
