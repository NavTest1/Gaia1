package User;

import Class.TokenNode;
import Class.node;
import ckks.CKKSHelper;
import ckks.Ciphertext;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.SneakyThrows;

import javax.crypto.IllegalBlockSizeException;
import java.io.File;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;

public class QueryTokenGen {

    private final PRF_PRP_Hash pph;
    private final ArrayList<Long> querylist;
    private final ConcurrentHashMap<Long, Long> ii2i;
    private final ConcurrentHashMap<Long, Integer> i2i;
    private final ConcurrentHashMap<Integer, node> apl;
    private final CKKSHelper ckks;
    private ArrayList<TokenNode> data;

    /**
     * 新版构造：把明文坐标加密后塞进 TokenNode
     */
    public QueryTokenGen(PRF_PRP_Hash pph,
                         ArrayList<Long> querylist,
                         ConcurrentHashMap<Long, Long> ii2i,
                         ConcurrentHashMap<Long, Integer> i2i,
                         ConcurrentHashMap<Integer, node> apl,
                         CKKSHelper ckks) throws IllegalBlockSizeException {
        long tokenst = System.currentTimeMillis();
        this.ii2i = ii2i;
        this.i2i   = i2i;
        this.apl   = apl;
        this.ckks  = ckks;
        this.pph   = pph;
        this.querylist = querylist;

        data = new ArrayList<>();
        for (long t : querylist) {
            long mapId = t; 
            Long val = ii2i.get(t);          // 算法 id
            int  idx = i2i.get(t);           // 算法索引
            node nd  = apl.get(idx);         // 明文坐标

            byte[] Imsg = BigInteger.valueOf(val).toByteArray();
            byte[] t2Tag = new byte[Imsg.length];
            byte[] f4Tag = new byte[32];
            byte[] h1Tag = pph.use_H1(Imsg);

            pph.use_T2(Imsg, t2Tag);
            pph.use_F4(Imsg, f4Tag);

            String st2 = new BigInteger(t2Tag).toString();
            String sf4 = new BigInteger(f4Tag).toString();
            String sh1 = new BigInteger(h1Tag).toString();

            // 加密坐标
            Ciphertext xEnc = ckks.encrypt(nd.x);
            Ciphertext yEnc = ckks.encrypt(nd.y);

            TokenNode e = new TokenNode(st2, sf4, sh1, mapId, xEnc, yEnc, nd.x, nd.y);
            data.add(e);
        }
        long tokenet = System.currentTimeMillis();
        // System.out.println("token产生(tokenet-tokenst) = " + (tokenet - tokenst) + "ms");
    }

    @SneakyThrows
    public static void writeJsonToken(String filiName, ArrayList<TokenNode> data) {
        ObjectMapper mapper = new ObjectMapper();
        ObjectNode rootNode = mapper.createObjectNode();
        ArrayNode arrayNode = mapper.createArrayNode();
        data.forEach(e -> {
            ObjectNode objNode = mapper.createObjectNode();
            objNode.put("H1", e.H1str);
            objNode.put("F4", e.F4str);
            objNode.put("T2", e.T2str);
            objNode.put("id", String.valueOf(e.id));
            arrayNode.add(objNode);
        });
        rootNode.set("tokens", arrayNode);
        mapper.writeValue(new File(filiName), rootNode);
    }

    public ArrayList<TokenNode> getData() {
        return data;
    }

    public void setData(ArrayList<TokenNode> data) {
        this.data = data;
    }
}