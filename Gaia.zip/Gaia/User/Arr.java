package User;

import Algorithm.Floyd_Warshall_1;
import Class.node;
import Class.PD_oracle;
import Omega.NewOmega;
import Omega.PK;
import ckks.CKKSHelper;
import ckks.Ciphertext;
import it.unisa.dia.gas.jpbc.Element;
import lombok.NoArgsConstructor;

import javax.crypto.IllegalBlockSizeException;
import java.io.IOException;
import java.io.Serializable;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.concurrent.ConcurrentHashMap;

@NoArgsConstructor
public class Arr implements Serializable {
    private  PRF_PRP_Hash pph;
    private  int mainid;
    private Floyd_Warshall_1 fw;
    private node n1;
    private PD_oracle pdo;
    private  ConcurrentHashMap<Integer,node> apl;
    private  Ciphertext[][] Encnode;//0:x,1:y
    private  Ciphertext[][] Encesd;
    private  ConcurrentHashMap<Long, Long> ii2i;
    public ConcurrentHashMap<Long, Arrnode> data;


    public Arr(node _n1, PRF_PRP_Hash _pph, Floyd_Warshall_1 _fw, PD_oracle _pdo, ConcurrentHashMap<Integer,node> _apl, PreEnc _preEnc, ConcurrentHashMap<Long, Long> ii2i) {//创建first
        pph = _pph;
        n1 = _n1;
        mainid = _n1.index;
        //mainid = 索引
        fw = _fw;
        this.ii2i = ii2i;
        data = new ConcurrentHashMap<>();
        apl = _apl;
        Encnode = _preEnc.getEncnode();
        Encesd = _preEnc.getEncesd();
        pdo = _pdo;
        byte[] tmpkr = ByteTools.merge(n1.kv.toByteArray(), n1.rv.toByteArray());
        //tmpkr = n1.kv||n1.rv

        byte[] res = new byte[32];
        pph.use_H2(tmpkr, res);//SHA256,|out|=256bits
        //res = H2（n1.kv||n1.rv）
        Ciphertext[] elements = Encnode[n1.index];
        Ciphertext ex = elements[0];
        Ciphertext ey = elements[1];
        //ex和ey是加密后的节点xy坐标
        //System.out.println(ex.duplicate().toBytes().length);
        //System.out.println(ey.duplicate().toBytes().length);
        //byte[] bexy = ByteTools.merge(ex.duplicate().toBytes(), ey.duplicate().toBytes());
        byte[] bexy = ByteTools.merge(ByteTools.longArrayToBytes(ex.serialize()),ByteTools.longArrayToBytes(ey.serialize()));
        //System.out.println(bexy.length);
        //bexy = ex||ey
        byte[] firstB = ByteTools.XOR(bexy, res);
        //firstB = ex||ey 异或 H2（n1.kv||n1.rv）
        Arrnode tmp = new Arrnode(firstB, n1.rv);
        //tmp:
        //     first = ex||ey 异或 H2（n1.kv||n1.rv）
        //     second = n1.rv
        data.put((long) 0, tmp);
        //data 0:tmp
    }




    public void buildArr() throws IllegalBlockSizeException, IOException {
//        NewOmega omega =  new NewOmega();
//        PK pk = omega.getPK("D:\\Gaia\\src\\main\\resources\\PK.json");
//        omega.SetByPk(pk);

        for (int i = 0; i < apl.size(); i++) {
            int id2 = apl.get(i).index;
            if (mainid == id2) continue;
            Ciphertext esd = Encesd[mainid][id2];
            //-------------------------------------------------------
//            CKKSHelper ckks = new CKKSHelper(2, 2, 10, 20);
//            ckks.loadContext("D:\\Gaia\\src\\main\\resources");
//            ckks.loadPublicKeys("D:\\Gaia\\src\\main\\resources");
//            ckks.loadSecretKey("D:\\Gaia\\src\\main\\resources");
//            //-------------------------------------------------------
//            System.out.println("解密esd：    "+ckks.decrypt(esd));
            //byte[] tmp = esd.duplicate().toBytes();
            byte[] tmp = ByteTools.longArrayToBytes(esd.serialize());
            byte[] besd = new byte[516];

            System.arraycopy(tmp, 0, besd, 0, tmp.length);
            //besd = esd



            byte[] vidS = BigInteger.valueOf(ii2i.get(apl.get(i).id)).toByteArray();
            byte[] tagh1 = pph.use_H1(vidS);
//          tagh1 = H1(vj)
            byte[] tagt1 = new byte[vidS.length];
            pph.use_T1(vidS, tagt1);
            //tagt1 = T1(vj)


            var pd_oracle_node = pdo.find(mainid, id2);

            String spvv = pd_oracle_node.pd_pointlist;

            //spvv = 路径
            BigInteger rv2 = apl.get(i).rv;

            byte[] tagh2 = new byte[32];
            byte[] tmpkr = ByteTools.merge(n1.kv.toByteArray(), rv2.toByteArray());
            //tmpkr = kvi||rvj
            pph.use_H2(tmpkr, tagh2);
            //tagh2 = H2(kvi||rvj)
            byte[] msgh1_rv = rv2.toByteArray(), tagh1_rv, tagf3h1 = new byte[32];
            tagh1_rv = pph.use_H1(msgh1_rv);
            //tagh1_rv = H1(rvj)
            pph.use_F3(tagh1_rv, tagf3h1);
            //tagf3h1 = F3(H1(rvj))
            byte[] Bspvv = spvv.getBytes(StandardCharsets.UTF_8);

            //Bspvv = spvivj
            byte[] s2 = ByteTools.XOR1(Bspvv, tagf3h1);

            //s2 = spvivj异或F3(H1(rvj))
            byte[] tmpb1 = ByteTools.merge3(tagh1, s2, besd);

            //tmpb1 = H1(vj)||SPvivj异或F3(H1(rvj))||Esdvivj
            byte[] res = ByteTools.XOR(tmpb1, tagh2);
            //res = H1(vj)||SPvivj异或F3(H1(rvj))||Esdvivj   异或   tagh2 = H2(kvi||rvj)

//            //-------------------------------------------------------------------------
//            System.out.println("测验....................");
//
//            byte[] correct = ByteTools.XOR(res,tagh2);
//            System.out.println("correct:"+correct.length);
//            byte[] ses = ByteTools.DelRearZero(Arrays.copyOfRange(correct,correct.length-132,correct.length));
//            Element ElemEsd = pk.get_G().newElementFromBytes(ses);
//            lu = omega.add(lu, ElemEsd);
//            System.out.println(omega.Dec(lu,pk,NewOmega.readSK("D:\\Gaia\\src\\main\\resources\\SK.json")));
//
//            //-------------------------------------------------------------------------
            Arrnode arrnode = new Arrnode(res, rv2);
            data.put(new BigInteger(tagt1).longValue(), arrnode);
        }
    }

}

//F3(H1(rvj))