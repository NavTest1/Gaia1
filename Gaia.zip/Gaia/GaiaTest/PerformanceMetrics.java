package GaiaTest;

import Algorithm.Floyd_Warshall_1;
import Class.PartialOrder;
import Class.TokenNode;
import Class.node;
import NSP.EncNavigationTools;
import NSP.EncNode;
import NSP.EncGraph;
import NSP.EncVecTools;
import NSP.StopSet;
import Gaia.GaiaNavigationTools;
import User.*;
import ckks.CKKSHelper;
import ckks.Ciphertext;
import lombok.SneakyThrows;
// 在现有的import语句后面添加这些
import util.*;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import Proxy.CT;
import Gaia.ERGDistanceMap;
import analysis.CommunicationAnalysis;

import static util.JsonUtil.*;
import static util.ProcessList.getTokenList;
import java.util.stream.*;

public class PerformanceMetrics {
    private static final int TEST_ITERATIONS = 5;
    private static final int[] WAYPOINT_COUNTS = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
    private static final int[] CONSTRAINT_PAIRS = { 0, 1, 2, 3, 4, 5 };
    private static final double[] BLOCKAGE_RATIOS = { 0.00, 0.05, 0.10, 0.15, 0.20 };

    private static final String RESULT_DIR = "D:\\NavTest\\Testall\\400";
    private static final String RESULT_FILE = RESULT_DIR + "\\gaia_performance400.csv";
    private static final String LOG_FILE = RESULT_DIR + "\\Test3_performance400.log";

    // 🔥 新增的常量 - 智能加密图管理
    private static final boolean USE_ENCRYPTED_GRAPH_CACHE = true; // 启用加密图缓存
    private static final String GRAPH_KEY = "400"; // 对应400个节点的地图
    private static boolean reportGenerated = false; // 确保报告只生成一次

    // 🔥 新增：缓存状态跟踪
    private static final Map<Double, Boolean> graphCacheStatus = new ConcurrentHashMap<>();

    @SneakyThrows
    public static void main(String[] args) {
        clearLogFile();
        java.io.FileOutputStream fos = new java.io.FileOutputStream(LOG_FILE, true);
        java.io.PrintStream ps = new PrintStream(fos, true, "UTF-8");
        System.setOut(ps);
        System.setErr(ps);
        System.out.println("=== 开始 Gaia 性能测试 ===");
        System.out.println("测试迭代次数: " + TEST_ITERATIONS);
        System.out.println("途径点数量配置: " + Arrays.toString(WAYPOINT_COUNTS));
        System.out.println("约束对数配置: " + Arrays.toString(CONSTRAINT_PAIRS));
        System.out.println("开始时间: " + new Date());
        System.out.println("日志文件: " + LOG_FILE);
        System.out.println("结果文件: " + RESULT_FILE);
        System.out.println("==========================================");
        performanceTest();
    }

    @SneakyThrows
    private static void clearLogFile() {
        File logFile = new File(LOG_FILE);
        if (logFile.exists()) {
            try (PrintWriter writer = new PrintWriter(new FileWriter(LOG_FILE, false))) {
                writer.print("");
            }
            System.out.println("已清空之前的日志文件: " + LOG_FILE);
        } else {
            File dir = new File(RESULT_DIR);
            if (!dir.exists()) {
                dir.mkdirs();
            }
            logFile.createNewFile();
            System.out.println("创建新的日志文件: " + LOG_FILE);
        }
    }

    @SneakyThrows
    public static void performanceTest() {
        File dir = new File(RESULT_DIR);
        if (!dir.exists())
            dir.mkdirs();

        // 🔥 新增：显示加密图缓存状态
        if (USE_ENCRYPTED_GRAPH_CACHE) {
            System.out.println("\n🔍 检查加密图缓存状态...");
            EncryptedGraphManager.printCacheStatus(GRAPH_KEY, BLOCKAGE_RATIOS);
        }

        try (PrintWriter writer = new PrintWriter(new FileWriter(RESULT_FILE))) {
            // 写入 CSV 表头
            writer.println(
                    "阻塞比例,途径点数量,约束对数,迭代次数,地图加载时间(ms),Floyd预处理时间(ms),CKKS初始化时间(ms),令牌生成时间(ms),导航时间(ms),路径恢复时间(ms),路径构建时间(ms),总时间(ms),"
                            + "距离偏差率(%),"
                            + "膨胀率_环境(vs原始),膨胀率_算法(vs最优),"
                            + "相似度_算法(vs最优%),相似度_环境(vs原始%),"
                            + "阻塞绕行成功率(%),偏序处理成功率(%),实际总距离(有阻塞),Gaia路径原始距离(无阻塞),理论最优距离(TSP基准),"
                            + "加密图上传(bytes),令牌上传(bytes),结果下载(bytes),交互数据(bytes),交互轮数,总通信量(bytes),总通信量(KB)");

            // --- 第一层循环：阻塞比例 (环境变化) ---
            for (double blockageRatio : BLOCKAGE_RATIOS) {
                System.out.println("\n" + "=".repeat(60));
                System.out.println("=== [环境初始化] 阻塞比例: " + String.format("%.0f%%", blockageRatio * 100) + " ===");
                System.out.println("=".repeat(60));

                // ==========================================
                // 🏗️ 阶段 1: 环境一次性初始化 (Map, Floyd, CKKS)
                // ==========================================
                long envSetupStart = System.currentTimeMillis();

                // 变量声明
                ConcurrentHashMap<Long, Integer> i2i = new ConcurrentHashMap<>();
                ConcurrentHashMap<Long, Long> ii2i = new ConcurrentHashMap<>();
                ConcurrentHashMap<Long, Long> oi2i = new ConcurrentHashMap<>();
                ConcurrentHashMap<Integer, node> apl;
                Floyd_Warshall_1 fw;
                CKKSHelper sharedCkks;

                // 时间记录
                long mapTime = 0;
                long floydTime = 0;
                long ckksTime = 0;

                // 1. CKKS 初始化 (只需一次)
                long t1 = System.currentTimeMillis();
                sharedCkks = initializeCKKS();
                ckksTime = System.currentTimeMillis() - t1;
                System.out.printf("  🔐 CKKS初始化完成: %d ms\n", ckksTime);

                // 2. 地图与Floyd初始化
                long t2 = System.currentTimeMillis();
                boolean useCachedGraph = USE_ENCRYPTED_GRAPH_CACHE &&
                        EncryptedGraphManager.encryptedGraphExists(GRAPH_KEY, blockageRatio);

                if (useCachedGraph) {
                    System.out.println("  🔄 使用已缓存的加密图结构...");
                    EncryptedGraphManager.EncryptedGraphData graphData = EncryptedGraphManager
                            .loadEncryptedGraph(GRAPH_KEY, blockageRatio);
                    apl = graphData.getApl();
                    i2i = graphData.getI2i();
                    ii2i = graphData.getIi2i();
                    oi2i = graphData.getOi2i();

                    // 模拟图上传通信开销（这里只记一次，或者在report里记）
                    graphCacheStatus.put(blockageRatio, true);

                    System.out.println("  🔄 创建Floyd实例 (基于缓存图)...");
                    fw = new Floyd_Warshall_1(apl, i2i, blockageRatio);
                    fw.setup();
                    System.out.println("  ⚡ 重新计算距离矩阵 (Compute)...");
                    fw.compute();
                } else {
                    System.out.println("  🆕 创建新的地图结构...");
                    String json = "D:\\Gaia\\src\\main\\resources\\400-2200junctions(Manhattan) (2)\\400\\400junction.json";
                    apl = JsonUtil.getNodeList600(json, i2i, ii2i, oi2i);
                    getMapInJson(i2i, ii2i, oi2i);
                    graphCacheStatus.put(blockageRatio, false);

                    System.out.println("  🆕 创建Floyd实例并计算...");
                    fw = new Floyd_Warshall_1(apl, i2i, blockageRatio);
                    fw.setup();
                    fw.compute();

                    // 如果是新的，保存缓存
                    if (USE_ENCRYPTED_GRAPH_CACHE) {
                        System.out.println("  💾 保存加密图缓存...");
                        EncryptedGraphManager.saveEncryptedGraph(GRAPH_KEY, blockageRatio, apl, i2i, ii2i, oi2i,
                                sharedCkks);
                        graphCacheStatus.put(blockageRatio, true);
                    }
                }

                long t3 = System.currentTimeMillis();
                mapTime = (t3 - t2) / 2; // 粗略分配一下时间，或者你可以详细打点
                floydTime = (t3 - t2) / 2;
                // 更精确的计时建议在if/else内部做，这里为了简化代码结构略作合并
                System.out.printf("  🗺️ 地图与Floyd准备完成，耗时: %d ms\n", (t3 - t2));

                // 3. 设置全局静态变量 (对所有后续测试通用)
                GaiaNavigationTools.setFloydInstance(fw);
                // 注意：CKKS 设置通常在导航前做，但如果有多线程需小心。这里串行没问题。

                // ==========================================
                // 🚀 阶段 2: 循环运行测试用例 (复用环境)
                // ==========================================

                for (int waypointCount : WAYPOINT_COUNTS) {
                    for (int constraintPairs : CONSTRAINT_PAIRS) {
                        // 过滤无效配置
                        if (constraintPairs > 0 && waypointCount < 2)
                            continue;
                        if (constraintPairs > getMaxConstraintPairs(waypointCount))
                            continue;

                        System.out.println("\n" + "-".repeat(40));
                        System.out.printf("配置: 途径点=%d, 约束=%d, 阻塞=%.0f%%\n", waypointCount, constraintPairs,
                                blockageRatio * 100);

                        // 累加器初始化
                        long totalTokenTime = 0;
                        long totalNavTime = 0;
                        long totalRecoveryTime = 0;
                        long totalPathTime = 0;
                        long totalOverallTime = 0;

                        double totalDistanceDeviation = 0;
                        double totalPER_Original = 0;
                        double totalPER_Optimal = 0;
                        double totalPS_Optimal = 0;
                        double totalPS_Original = 0;

                        double totalBlockageSuccess = 0;
                        double totalPartialOrderSuccess = 0;
                        double totalActualDistance = 0;
                        double totalgaiaPathOriginalDistance = 0;
                        double totalShortestDistance = 0;

                        int successfulIterations = 0;

                        // --- 循环迭代 (随机查询) ---
                        for (int iteration = 0; iteration < TEST_ITERATIONS; iteration++) {
                            long iterStart = System.currentTimeMillis();
                            try {
                                // 🔥 调用修改后的 runSingleTest，传入准备好的环境对象
                                TestResult result = runSingleTest(
                                        waypointCount, constraintPairs, blockageRatio,
                                        fw, sharedCkks, apl, i2i, ii2i, oi2i // 传入复用的对象
                                );

                                // 补全 Result 中的环境时间 (为了CSV记录完整性)
                                result.mapLoadingTime = mapTime;
                                result.floydTotalTime = floydTime;
                                result.ckksTotalTime = ckksTime;

                                long iterTime = System.currentTimeMillis() - iterStart;

                                // 累加数据
                                totalTokenTime += result.tokenGenerationTime;
                                totalNavTime += result.gaiaTotalTime;
                                totalRecoveryTime += result.pathRecoveryTime;
                                totalPathTime += result.pathConstructionTime;
                                totalOverallTime += iterTime;

                                if (result.distanceDeviationRate >= 0)
                                    totalDistanceDeviation += result.distanceDeviationRate;
                                if (result.per_Original >= 0)
                                    totalPER_Original += result.per_Original;
                                if (result.per_Optimal >= 0)
                                    totalPER_Optimal += result.per_Optimal;
                                if (result.ps_Optimal >= 0)
                                    totalPS_Optimal += result.ps_Optimal;
                                if (result.ps_Original >= 0)
                                    totalPS_Original += result.ps_Original;
                                if (result.blockageSuccessRate >= 0)
                                    totalBlockageSuccess += result.blockageSuccessRate;
                                if (result.partialOrderSuccessRate >= 0)
                                    totalPartialOrderSuccess += result.partialOrderSuccessRate;
                                if (result.actualTotalDistance >= 0)
                                    totalActualDistance += result.actualTotalDistance;
                                if (result.gaiaPathOriginalDistance >= 0)
                                    totalgaiaPathOriginalDistance += result.gaiaPathOriginalDistance;
                                if (result.shortestPathDistance >= 0)
                                    totalShortestDistance += result.shortestPathDistance;

                                successfulIterations++;

                                // 写入单次迭代结果
                                String iterationLine = String.format(
                                        "%.2f,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%s",
                                        blockageRatio, waypointCount, constraintPairs, iteration + 1,
                                        result.mapLoadingTime, result.floydTotalTime, result.ckksTotalTime,
                                        result.tokenGenerationTime, result.gaiaTotalTime, result.pathRecoveryTime,
                                        result.pathConstructionTime, iterTime,
                                        result.distanceDeviationRate,
                                        result.per_Original, result.per_Optimal,
                                        result.ps_Optimal, result.ps_Original,
                                        result.blockageSuccessRate, result.partialOrderSuccessRate,
                                        result.actualTotalDistance, result.gaiaPathOriginalDistance,
                                        result.shortestPathDistance, result.communicationStats.toCSVLine());
                                writer.println(iterationLine);
                                writer.flush();

                                System.out.printf("  Iter %d: 成功 (总时: %d ms)\n", iteration + 1, iterTime);

                            } catch (Exception e) {
                                System.err.printf("❌ 迭代 %d 失败: %s\n", iteration + 1, e.getMessage());
                                e.printStackTrace();
                                writer.println(
                                        String.format("%.2f,%d,%d,%d,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1",
                                                blockageRatio, waypointCount, constraintPairs, iteration + 1));
                            }
                        } // End Iterations

                        if (successfulIterations > 0) {
                            // 计算平均值
                            double avgTokenTime = (double) totalTokenTime / successfulIterations;
                            double avgNavTime = (double) totalNavTime / successfulIterations;
                            double avgRecoveryTime = (double) totalRecoveryTime / successfulIterations;
                            double avgPathTime = (double) totalPathTime / successfulIterations;
                            double avgOverallTime = (double) totalOverallTime / successfulIterations;

                            double avgDistanceDeviation = totalDistanceDeviation / successfulIterations;
                            double avgPER_Original = totalPER_Original / successfulIterations;
                            double avgPER_Optimal = totalPER_Optimal / successfulIterations;
                            double avgPS_Optimal = totalPS_Optimal / successfulIterations;
                            double avgPS_Original = totalPS_Original / successfulIterations;
                            double avgBlockageSuccess = totalBlockageSuccess / successfulIterations;
                            double avgPartialOrderSuccess = totalPartialOrderSuccess / successfulIterations;
                            double avgActualDistance = totalActualDistance / successfulIterations;
                            double avggaiaPathOriginalDistance = totalgaiaPathOriginalDistance / successfulIterations;
                            double avgShortestDistance = totalShortestDistance / successfulIterations;

                            // 写入平均值行 (注意：地图加载等环境时间使用初始化的值)
                            String avgLine = String.format(
                                    "%.2f,%d,%d,平均值,%d,%d,%d,%.0f,%.0f,%.0f,%.0f,%.0f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%s",
                                    blockageRatio, waypointCount, constraintPairs,
                                    mapTime, floydTime, ckksTime, // 环境时间
                                    avgTokenTime, avgNavTime, avgRecoveryTime, avgPathTime, avgOverallTime, // 平均运行时间
                                    avgDistanceDeviation,
                                    avgPER_Original, avgPER_Optimal,
                                    avgPS_Optimal, avgPS_Original,
                                    avgBlockageSuccess, avgPartialOrderSuccess,
                                    avgActualDistance, avggaiaPathOriginalDistance, avgShortestDistance,
                                    "N/A,N/A,N/A,N/A,N/A,N/A,N/A"); // 通信统计平均值暂略
                            writer.println(avgLine);
                            writer.flush();
                        }
                    } // End Constraint Loop
                } // End Waypoint Loop
            } // End Blockage Loop

            // 生成最终报告
            System.out.println("\n=== 测试完成 ===");
            if (USE_ENCRYPTED_GRAPH_CACHE)
                EncryptedGraphManager.printCacheStatus(GRAPH_KEY, BLOCKAGE_RATIOS);

            CommunicationAnalysis.generateTechnicalCommunicationReport(RESULT_FILE,
                    RESULT_DIR + "\\final_technical_communication_report400.md");
            CommunicationAnalysis.generateCommunicationTable(RESULT_DIR + "\\final_communication_estimates400.csv");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static int getMaxConstraintPairs(int waypointCount) {
        if (waypointCount <= 1)
            return 0;
        return waypointCount * (waypointCount - 1); // 全排列
    }

    // ⬇️ 修改方法签名，接收环境对象
    private static TestResult runSingleTest(int waypointCount, int constraintPairs, double blockageRatio,
            Floyd_Warshall_1 fw, CKKSHelper iterationCkks,
            ConcurrentHashMap<Integer, node> apl,
            ConcurrentHashMap<Long, Integer> i2i,
            ConcurrentHashMap<Long, Long> ii2i,
            ConcurrentHashMap<Long, Long> oi2i)
            throws Exception {

        System.gc(); // 保持GC调用以清理上一次迭代的临时对象
        // Thread.sleep(50); // 可选：如果觉得太快可以加

        TestResult result = new TestResult();
        long stageStart, stageEnd;

        // 创建通信统计对象
        CommunicationStats commStats = new CommunicationStats();
        // 模拟图上传通信 (使用传入的数据大小) - 这部分在外部只算一次，或者在这里算每次迭代的"分摊"
        // 这里为了兼容性，可以暂时不重新计算图上传，因为它在预处理阶段完成了

        // 1-3. ❌ 地图加载、Floyd、CKKS初始化 已在外部完成，此处跳过
        // 我们假设这些时间在外部已经赋值给了 result，或者在外部循环中处理

        // 4. 生成随机查询路径 (基于传入的 apl)
        ArrayList<Long> plainQuery = generateRandomPath(apl, waypointCount);

        // 5. 生成偏序约束
        List<PartialOrder> userPartialOrders = generatePartialOrders(plainQuery, constraintPairs);

        // 6. 令牌生成和上传模拟
        commStats.startTokenUpload();
        stageStart = System.currentTimeMillis();

        PRF_PRP_Hash pph = new PRF_PRP_Hash(iterationCkks.getSecretKey());
        // 使用传入的 maps
        QueryTokenGen gentoken = new QueryTokenGen(pph, plainQuery, ii2i, i2i, apl, iterationCkks);
        ArrayList<TokenNode> tokenList = gentoken.getData();

        // 重建 EncGraph 映射 (这是针对本次查询的Token节点的映射，必须每次做)
        rebuildEncGraphMapping(tokenList, iterationCkks);
        validateEncGraphMapping(tokenList);

        TokenNode E_S = tokenList.get(0);
        TokenNode E_D = tokenList.get(tokenList.size() - 1);
        List<TokenNode> E_Stops = tokenList.subList(1, tokenList.size() - 1);

        stageEnd = System.currentTimeMillis();
        commStats.endTokenUpload();
        result.tokenGenerationTime = stageEnd - stageStart;

        List<PartialOrder> gaiaPO = userPartialOrders;

        // 7. 导航预验证
        if (!preValidateNavigation(E_S, E_D, E_Stops)) {
            System.out.println("  ⚠️ 导航预验证失败，尝试修复...");
            // 如果预验证失败，这里的修复逻辑也需要使用传入的 fw 和 maps
            plainQuery = generateRobustRandomPath(apl, waypointCount, fw, i2i);
            gentoken = new QueryTokenGen(pph, plainQuery, ii2i, i2i, apl, iterationCkks);
            tokenList = gentoken.getData();
            rebuildEncGraphMapping(tokenList, iterationCkks);

            E_S = tokenList.get(0);
            E_D = tokenList.get(tokenList.size() - 1);
            E_Stops = tokenList.subList(1, tokenList.size() - 1);

            userPartialOrders = generatePartialOrders(plainQuery, constraintPairs);
            gaiaPO = userPartialOrders;
        }

        // 8. Gaia 导航
        stageStart = System.currentTimeMillis();
        CT ct;
        // 确保静态上下文是最新的 (虽然外部设置了，但为了安全这里可以再确认)
        synchronized (GaiaNavigationTools.class) {
            ct = new CT(iterationCkks.getPublicKeys(), iterationCkks.getContext());
            GaiaNavigationTools.setCKKS(iterationCkks, ct);
            EncNavigationTools.init(iterationCkks, ct, iterationCkks.getPublicKeys());
            EncVecTools.init(iterationCkks.getContext(), iterationCkks.getPublicKeys());
            // sk3 可以每次随机
            byte[] sk3 = new byte[32];
            new Random().nextBytes(sk3);
            GaiaNavigationTools.setSK3(sk3);
            // 确保Floyd实例是当前阻塞比例的实例
            GaiaNavigationTools.setFloydInstance(fw);
        }

        GaiaNavigationTools.EncryptedQueryResult eqr;
        List<TokenNode> navigatedStops;
        synchronized (GaiaNavigationTools.class) {
            GaiaNavigationTools.Navigator navigator = new GaiaNavigationTools.Navigator(E_S, E_D, E_Stops, gaiaPO, apl,
                    i2i);
            eqr = navigator.run();
            navigatedStops = new ArrayList<>(navigator.sortedStops);
        }

        stageEnd = System.currentTimeMillis();
        result.gaiaTotalTime = stageEnd - stageStart;

        // 9. 路径恢复
        commStats.startResultDownload();
        stageStart = System.currentTimeMillis();
        List<TokenNode> recoveredPath = recoverPath(E_S, E_D, navigatedStops, eqr, iterationCkks, fw, i2i, pph,
                tokenList, apl);
        stageEnd = System.currentTimeMillis();
        commStats.endResultDownload();
        result.pathRecoveryTime = stageEnd - stageStart;

        // 10. 路径构建
        stageStart = System.currentTimeMillis();
        List<TokenNode> navigationOrder = buildNavigationOrder(E_S, E_D, navigatedStops, eqr, recoveredPath);
        stageEnd = System.currentTimeMillis();
        result.pathConstructionTime = stageEnd - stageStart;

        // 11. 统计与计算
        commStats.calculateDetailedForScenario(apl.size(), waypointCount, constraintPairs);

        calculateMetrics(result, plainQuery, navigationOrder, fw, i2i, eqr, navigatedStops, E_S, E_D,
                userPartialOrders, apl, ii2i);

        result.communicationStats = commStats;

        return result;
    }

    // 生成偏序约束并验证可行性
    private static List<PartialOrder> generatePartialOrders(ArrayList<Long> plainQuery, int constraintPairs) {
        List<PartialOrder> partialOrders = new ArrayList<>();

        if (constraintPairs <= 0 || plainQuery.size() < 3) {
            return partialOrders;
        }
        List<Long> waypoints = plainQuery.subList(1, plainQuery.size() - 1);
        if (waypoints.size() < 2) {
            return partialOrders;
        }
        int maxPossiblePairs = waypoints.size() * (waypoints.size() - 1);
        if (constraintPairs > maxPossiblePairs) {
            constraintPairs = maxPossiblePairs;
            System.out.printf("    ⚠️ 调整约束对数为理论最大值: %d\n", constraintPairs);
        }
        Random random = new Random();
        final int MAX_RETRIES = 20;

        int retryCount = 0;

        while (retryCount < MAX_RETRIES) {
            retryCount++;
            partialOrders.clear();
            Set<String> usedPairs = new HashSet<>();

            System.out.printf("    第 %d 次尝试生成约束...\n", retryCount);

            for (int i = 0; i < constraintPairs; i++) {
                int maxAttempts = 50;
                boolean found = false;
                Long pStId = null, sStId = null;

                for (int attempt = 0; attempt < maxAttempts && !found; attempt++) {
                    int idx1 = random.nextInt(waypoints.size());
                    int idx2 = random.nextInt(waypoints.size());

                    if (idx1 == idx2)
                        continue;

                    pStId = waypoints.get(idx1);
                    sStId = waypoints.get(idx2);

                    String pairKey = Math.min(pStId, sStId) + "-" + Math.max(pStId, sStId);
                    if (!usedPairs.contains(pairKey)) {
                        usedPairs.add(pairKey);

                        TokenNode pStToken = new TokenNode("", "", "", pStId);
                        TokenNode sStToken = new TokenNode("", "", "", sStId);
                        PartialOrder po = new PartialOrder(pStToken, sStToken);
                        partialOrders.add(po);
                        found = true;

                        System.out.printf("      随机约束 %d: %d → %d\n", i + 1, pStId, sStId);
                    }
                }

                if (!found) {
                    System.out.println("      警告: 无法生成新的约束对，可能途径点数量不足");
                    break;
                }
            }

            if (areConstraintsFeasible(partialOrders)) {
                System.out.printf("    ✅ 第 %d 次尝试生成可行的约束集: %d 对约束\n",
                        retryCount, partialOrders.size());
                return partialOrders;
            } else {
                System.out.printf("    ⚠️ 第 %d 次尝试约束不可行，重新生成\n", retryCount);
            }
        }

        System.out.printf("    ❌ 经过 %d 次尝试仍无法生成可行约束，返回空集\n", MAX_RETRIES);
        return new ArrayList<>();
    }

    private static void calculateMetrics(TestResult result,
            ArrayList<Long> plainQuery,
            List<TokenNode> navigationOrder, // Gaia 最终生成的完整节点序列
            Floyd_Warshall_1 fw,
            ConcurrentHashMap<Long, Integer> i2i,
            GaiaNavigationTools.EncryptedQueryResult eqr,
            List<TokenNode> navigatedStops, // Gaia 决定的途径点顺序
            TokenNode E_S, TokenNode E_D,
            List<PartialOrder> userPartialOrders,
            ConcurrentHashMap<Integer, node> apl,
            ConcurrentHashMap<Long, Long> ii2i) {

        try {
            System.out.println("\n  📊 开始计算全面性能指标 (Global Metrics)...");

            // --- 1. 准备基础数据 ---

            // A. Gaia 确定的顺序 (Stop Sequence)
            List<TokenNode> gaiaSequence = new ArrayList<>();
            gaiaSequence.add(E_S);
            if (navigatedStops != null)
                gaiaSequence.addAll(navigatedStops);
            gaiaSequence.add(E_D);

            // B. 最优全排列顺序 (Optimal Sequence) - 需考虑偏序约束和阻塞图
            // 注意：findOptimalSequence 是原有方法，保留使用
            List<TokenNode> optimalStops = findOptimalSequence(E_S, E_D, navigatedStops, userPartialOrders, fw, i2i);
            List<TokenNode> optimalSequence = new ArrayList<>();
            optimalSequence.add(E_S);
            optimalSequence.addAll(optimalStops);
            optimalSequence.add(E_D);

            // --- 2. 计算距离指标 & 膨胀率 ---

            // (1) Gaia 在阻塞图中的实际距离 (useBlockedMatrix = true)
            double distGaiaBlocked = calculateTotalDistance(E_S, E_D, navigatedStops, fw, i2i, true);

            // (2) Gaia 在无阻塞图中的原始距离 (useBlockedMatrix = false)
            double distGaiaUnblocked = calculateTotalDistance(E_S, E_D, navigatedStops, fw, i2i, false);

            // (3) 最优顺序 在阻塞图中的距离 (useBlockedMatrix = true)
            double distOptimalBlocked = calculateTotalDistance(E_S, E_D, optimalStops, fw, i2i, true);

            // 赋值给 Result 对象
            result.actualTotalDistance = distGaiaBlocked;
            result.gaiaPathOriginalDistance = distGaiaUnblocked;
            result.shortestPathDistance = distOptimalBlocked;

            // 计算距离偏差率 (Optimality Gap)
            if (distOptimalBlocked > 0) {
                result.distanceDeviationRate = ((distGaiaBlocked - distOptimalBlocked) / distOptimalBlocked) * 100.0;
                // 修正微小负数误差
                if (result.distanceDeviationRate < 0 && result.distanceDeviationRate > -0.01)
                    result.distanceDeviationRate = 0;
            } else {
                result.distanceDeviationRate = 0;
            }

            // 🔥 计算两种膨胀率 (Path Expansion Rate)

            // PER_Original: 环境影响 (Blocked / Unblocked)
            if (distGaiaUnblocked > 0) {
                result.per_Original = distGaiaBlocked / distGaiaUnblocked;
            } else {
                result.per_Original = 1.0;
            }

            // PER_Optimal: 算法效率 (Gaia / Optimal)
            if (distOptimalBlocked > 0) {
                result.per_Optimal = distGaiaBlocked / distOptimalBlocked;
            } else {
                result.per_Optimal = 1.0;
            }

            System.out.printf("    📈 膨胀率(环境): %.2fx (Gaia阻塞/Gaia原始)\n", result.per_Original);
            System.out.printf("    📈 膨胀率(算法): %.2fx (Gaia阻塞/最优阻塞)\n", result.per_Optimal);

            // --- 3. 计算相似度指标 ---

            // 恢复三条完整路径的节点列表 (List<Long>)

            // Path A: Gaia 顺序在阻塞图中的完整路径 (实际走的)
            List<Long> pathGaiaBlocked = restoreCompletePath(gaiaSequence, fw, true);

            // Path B: 最优顺序在阻塞图中的完整路径 (理论最优走的)
            List<Long> pathOptimalBlocked = restoreCompletePath(optimalSequence, fw, true);

            // Path C: Gaia 顺序在无阻塞图中的完整路径 (原本应该走的)
            List<Long> pathGaiaUnblocked = restoreCompletePath(gaiaSequence, fw, false);

            // 🔥 计算两种相似度 (Path Similarity)

            // PS_Optimal: Gaia(Blocked) vs Optimal(Blocked) - 算法决策的几何接近度
            result.ps_Optimal = calculateCombinedSimilarity(pathGaiaBlocked, pathOptimalBlocked,
                    distGaiaBlocked, distOptimalBlocked,
                    apl, i2i, ii2i);

            // PS_Original: Gaia(Blocked) vs Gaia(Unblocked) - 阻塞导致几何变形程度
            result.ps_Original = calculateCombinedSimilarity(pathGaiaBlocked, pathGaiaUnblocked,
                    distGaiaBlocked, distGaiaUnblocked,
                    apl, i2i, ii2i);

            System.out.printf("    🔄 相似度(vs最优): %.2f%%\n", result.ps_Optimal);
            System.out.printf("    🔄 相似度(vs原始): %.2f%%\n", result.ps_Original);

            // --- 4. 其他指标 (成功率等) ---
            calculateSuccessRates(result, fw, navigationOrder, i2i, userPartialOrders);

        } catch (Exception e) {
            System.err.println("  ❌ 指标计算失败: " + e.getMessage());
            e.printStackTrace();
            setDefaultMetrics(result);
        }
    }

    // 通用路径恢复方法：根据节点序列恢复完整路径 (支持选择 阻塞路径 或 原始路径)
    private static List<Long> restoreCompletePath(List<TokenNode> sequence, Floyd_Warshall_1 fw,
            boolean useBlockedMatrix) {
        List<Long> fullPath = new ArrayList<>();

        for (int i = 0; i < sequence.size() - 1; i++) {
            long fromId = sequence.get(i).getId();
            long toId = sequence.get(i + 1).getId();

            String pathStr;
            // 🔥 根据标志选择从哪个列表获取路径字符串
            if (useBlockedMatrix) {
                pathStr = fw.getPathBetweenNodes(fromId, toId);
            } else {
                pathStr = fw.getOriginalPathBetweenNodes(fromId, toId);
            }

            List<Long> segment = parsePathNodes(pathStr);

            // 处理首尾连接，避免节点重复 (例如 A->B, B->C，不要变成 A,B,B,C)
            if (!segment.isEmpty()) {
                // 如果这不是第一段，且当前段的起点等于上一段的终点，移除当前段起点
                if (i > 0 && !fullPath.isEmpty() && segment.get(0).equals(fullPath.get(fullPath.size() - 1))) {
                    segment.remove(0);
                }
                fullPath.addAll(segment);
            } else {
                // 如果没有中间路径（直连或出错），至少保证连接性
                if (i == 0)
                    fullPath.add(fromId);
                // 只有当终点不同于起点时才添加，或者如果完全无法获取路径则直接连线
                if (fullPath.isEmpty() || !fullPath.get(fullPath.size() - 1).equals(toId)) {
                    fullPath.add(toId);
                }
            }
        }
        return removeDuplicateNodesById(fullPath);
    }

    // 封装相似度计算逻辑 (网格相似度 + 长度相似度)
    private static double calculateCombinedSimilarity(List<Long> path1, List<Long> path2,
            double dist1, double dist2,
            ConcurrentHashMap<Integer, node> apl,
            ConcurrentHashMap<Long, Integer> i2i,
            ConcurrentHashMap<Long, Long> ii2i) {
        // 1. 网格相似度 (70% 权重)
        // 注意：calculateGridSimilarity 方法是你原有代码中已经存在的，直接调用
        double gridSim = calculateGridSimilarity(path1, path2, apl, i2i, ii2i);

        // 2. 长度相似度 (30% 权重)
        double lenSim = 0.5; // 默认值
        if (dist1 > 0 && dist2 > 0) {
            lenSim = Math.min(dist1, dist2) / Math.max(dist1, dist2);
        }

        // 3. 加权综合
        return (gridSim * 0.7 + lenSim * 0.3) * 100.0;
    }

    /**
     * 暴力全排列寻找满足约束的最优途径点顺序
     */
    /**
     * 暴力全排列寻找满足约束的最优途径点顺序
     */
    private static List<TokenNode> findOptimalSequence(TokenNode s, TokenNode d, List<TokenNode> stops,
            List<PartialOrder> constraints, Floyd_Warshall_1 fw,
            ConcurrentHashMap<Long, Integer> i2i) {
        if (stops == null || stops.isEmpty())
            return new ArrayList<>();

        List<Integer> indices = new ArrayList<>();
        for (int i = 0; i < stops.size(); i++)
            indices.add(i);

        List<List<Integer>> perms = new ArrayList<>();
        generatePermutations(indices, 0, perms);

        double minDst = Double.MAX_VALUE;
        List<TokenNode> bestOrder = null;

        for (List<Integer> p : perms) {
            List<TokenNode> currentOrder = new ArrayList<>();
            for (int idx : p)
                currentOrder.add(stops.get(idx));

            // 检查是否满足偏序约束
            if (isOrderValid(currentOrder, constraints)) {
                // 计算总距离
                // 🔥 修复：添加 true 参数，表示计算最优路径时使用的是当前（含阻塞）的图
                double dst = calculateTotalDistance(s, d, currentOrder, fw, i2i, true);
                if (dst < minDst) {
                    minDst = dst;
                    bestOrder = new ArrayList<>(currentOrder);
                }
            }
        }
        // 如果找不到满足约束的，就返回原始顺序或者null
        return bestOrder != null ? bestOrder : stops;
    }

    private static void generatePermutations(List<Integer> arr, int k, List<List<Integer>> res) {
        for (int i = k; i < arr.size(); i++) {
            Collections.swap(arr, i, k);
            generatePermutations(arr, k + 1, res);
            Collections.swap(arr, i, k);
        }
        if (k == arr.size() - 1)
            res.add(new ArrayList<>(arr));
    }

    private static boolean isOrderValid(List<TokenNode> order, List<PartialOrder> constraints) {
        if (constraints == null)
            return true;
        Map<Long, Integer> idxMap = new HashMap<>();
        for (int i = 0; i < order.size(); i++)
            idxMap.put(order.get(i).getId(), i);
        for (PartialOrder po : constraints) {
            long p = po.getPSt().getId();
            long s = po.getSSt().getId();
            if (idxMap.containsKey(p) && idxMap.containsKey(s)) {
                if (idxMap.get(p) > idxMap.get(s))
                    return false;
            }
        }
        return true;
    }

    // 修改后的计算总距离方法
    private static double calculateTotalDistance(TokenNode s, TokenNode d, List<TokenNode> mids,
            Floyd_Warshall_1 fw, ConcurrentHashMap<Long, Integer> i2i,
            boolean useBlockedMatrix) {
        double total = 0;
        List<TokenNode> all = new ArrayList<>();
        all.add(s);
        if (mids != null)
            all.addAll(mids);
        all.add(d);

        // 获取两个矩阵
        double[][] blockedMatrix = fw.getGraph1();
        double[][] originalMatrix = fw.getOriginalGraph1();

        // 根据参数决定主要使用哪个矩阵
        double[][] primaryMatrix = useBlockedMatrix ? blockedMatrix : originalMatrix;

        for (int i = 0; i < all.size() - 1; i++) {
            Integer u = i2i.get(all.get(i).getId());
            Integer v = i2i.get(all.get(i + 1).getId());

            if (u != null && v != null) {
                double dist = primaryMatrix[u][v];

                // 🔥 修改开始：处理不可达情况
                if (dist >= 19000000.0) {
                    if (useBlockedMatrix) {
                        // 如果在阻塞图中不可达，尝试回退到原始距离（模拟强制通行或计算惩罚）
                        double fallbackDist = originalMatrix[u][v];
                        if (fallbackDist < 19000000.0) {
                            // 可以在这里加一个惩罚系数，比如 * 10，或者直接用原始距离
                            // 这里为了数据好看，直接用原始距离，代表“理论物理距离”
                            total += fallbackDist;
                            // System.out.println(" ⚠️ 路径段阻塞，使用原始距离回退: " + fallbackDist);
                        } else {
                            // 原始图也不通，那就是真不通
                            return 20000000.0;
                        }
                    } else {
                        return 20000000.0;
                    }
                } else {
                    total += dist;
                }
                // 🔥 修改结束
            }
        }
        return total;
    }

    private static void setDefaultMetrics(TestResult result) {
        result.distanceDeviationRate = 0;

        // 🔥 修复：初始化新字段
        result.per_Original = 1.0;
        result.per_Optimal = 1.0;
        result.ps_Optimal = 0;
        result.ps_Original = 0;

        result.blockageSuccessRate = 0;
        result.partialOrderSuccessRate = 0;
        // result.pathExpansionRate = 1.0; // 删除

        result.actualTotalDistance = 0;
        result.shortestPathDistance = 0;
        result.gaiaPathNodes = new ArrayList<>();
        result.shortestPathNodes = new ArrayList<>();
    }

    private static List<Long> restoreCompleteGaiaPath(TokenNode E_S, TokenNode E_D,
            List<TokenNode> navigatedStops,
            Floyd_Warshall_1 fw,
            ConcurrentHashMap<Integer, node> apl,
            ConcurrentHashMap<Long, Integer> i2i,
            ConcurrentHashMap<Long, Long> ii2i) {
        List<Long> completePath = new ArrayList<>();

        try {
            System.out.println("    🛠️  恢复完整Gaia路径（处理后矩阵）...");

            List<TokenNode> keyNodes = new ArrayList<>();
            keyNodes.add(E_S);
            if (navigatedStops != null) {
                keyNodes.addAll(navigatedStops);
            }
            keyNodes.add(E_D);

            System.out.printf("    🔑 关键节点序列(%d个): %s\n", keyNodes.size(),
                    keyNodes.stream().map(tn -> String.valueOf(tn.getId())).collect(Collectors.joining(" → ")));

            for (int i = 0; i < keyNodes.size() - 1; i++) {
                TokenNode from = keyNodes.get(i);
                TokenNode to = keyNodes.get(i + 1);

                System.out.printf("    📍 处理路径段 %d: %d → %d\n", i + 1, from.getId(), to.getId());

                String segmentPath = fw.getPathBetweenNodes(from.getId(), to.getId());
                List<Long> segmentNodes = parsePathNodes(segmentPath);

                double segmentDistance = fw.getDistanceBetweenNodes(from.getId(), to.getId());
                System.out.printf("      段距离: %.2f %s\n", segmentDistance,
                        segmentDistance < 20000000.0 ? "✅" : "❌");

                if (segmentNodes.isEmpty() || segmentDistance >= 20000000.0) {
                    System.out.printf("    ⚠️  路径段 %d→%d 不连通，直接连接\n", from.getId(), to.getId());
                    if (i == 0) {
                        completePath.add(from.getId());
                    }
                    completePath.add(to.getId());
                    continue;
                }

                if (!segmentNodes.get(0).equals(from.getId())) {
                    segmentNodes.add(0, from.getId());
                }
                if (!segmentNodes.get(segmentNodes.size() - 1).equals(to.getId())) {
                    segmentNodes.add(to.getId());
                }

                if (i == 0) {
                    completePath.addAll(segmentNodes);
                    System.out.printf("      ✅ 添加第一段: %d个节点\n", segmentNodes.size());
                } else {
                    if (segmentNodes.size() > 1) {
                        completePath.addAll(segmentNodes.subList(1, segmentNodes.size()));
                        System.out.printf("      ✅ 添加后续段: %d个节点\n", segmentNodes.size() - 1);
                    } else {
                        completePath.addAll(segmentNodes);
                        System.out.printf("      ✅ 添加单节点段: %d个节点\n", segmentNodes.size());
                    }
                }
            }

            List<Long> deduplicatedPath = removeDuplicateNodesById(completePath);

            System.out.printf("    ✅ Gaia完整路径恢复完成: %d → %d节点 (去重后)\n",
                    completePath.size(), deduplicatedPath.size());

            return deduplicatedPath;

        } catch (Exception e) {
            System.err.println("    ❌ 恢复完整Gaia路径失败: " + e.getMessage());
            List<Long> fallbackPath = new ArrayList<>();
            fallbackPath.add(E_S.getId());
            if (navigatedStops != null) {
                fallbackPath.addAll(navigatedStops.stream().map(TokenNode::getId).collect(Collectors.toList()));
            }
            fallbackPath.add(E_D.getId());
            return fallbackPath;
        }
    }

    private static List<Long> getCompleteOriginalPath(TokenNode E_S, TokenNode E_D, Floyd_Warshall_1 fw) {
        try {
            System.out.println("    🗺️  获取完整预处理路径（处理后矩阵）...");

            String pathStr = fw.getPathBetweenNodes(E_S.getId(), E_D.getId());
            List<Long> path = parsePathNodes(pathStr);

            if (path.isEmpty() || path.size() < 2) {
                System.out.println("    ⚠️ 处理后路径为空，尝试原始路径作为fallback");
                pathStr = fw.getOriginalPathBetweenNodes(E_S.getId(), E_D.getId());
                path = parsePathNodes(pathStr);
            }

            if (path.isEmpty() || path.size() < 2) {
                System.out.println("    ❌ 所有路径获取方法都失败，创建直连路径");
                path = new ArrayList<>();
                path.add(E_S.getId());
                path.add(E_D.getId());
            }

            System.out.printf("    ✅ 预处理路径获取完成: %d个节点\n", path.size());

            boolean isConnected = validatePathConnectivity(path, fw);
            System.out.printf("    🔗 路径连通性: %s\n", isConnected ? "✅ 连通" : "❌ 不连通");

            return path;

        } catch (Exception e) {
            System.err.println("    ❌ 获取预处理路径失败: " + e.getMessage());
            List<Long> fallbackPath = new ArrayList<>();
            fallbackPath.add(E_S.getId());
            fallbackPath.add(E_D.getId());
            return fallbackPath;
        }
    }

    private static boolean validatePathConnectivity(List<Long> path, Floyd_Warshall_1 fw) {
        if (path.size() < 2)
            return false;

        for (int i = 0; i < path.size() - 1; i++) {
            double distance = fw.getDistanceBetweenNodes(path.get(i), path.get(i + 1));
            if (distance >= 20000000.0 - 1) {
                System.out.printf("      ❌ 段 %d→%d 不连通: %.2f\n",
                        path.get(i), path.get(i + 1), distance);
                return false;
            }
        }
        return true;
    }

    private static double calculateGridSimilarity(List<Long> path1, List<Long> path2,
            ConcurrentHashMap<Integer, node> apl,
            ConcurrentHashMap<Long, Integer> i2i,
            ConcurrentHashMap<Long, Long> ii2i) {

        try {
            System.out.println("    🗂️  计算网格相似度...");

            double gridSize = 50.0;

            Map<String, Integer> gridCount1 = mapPathToGrid(path1, apl, i2i, gridSize, ii2i);
            Map<String, Integer> gridCount2 = mapPathToGrid(path2, apl, i2i, gridSize, ii2i);

            System.out.printf("    📊 网格统计: 路径1=%d网格, 路径2=%d网格\n",
                    gridCount1.size(), gridCount2.size());

            Set<String> allGrids = new HashSet<>();
            allGrids.addAll(gridCount1.keySet());
            allGrids.addAll(gridCount2.keySet());

            if (allGrids.isEmpty()) {
                System.out.println("    ⚠️  无网格数据，返回默认相似度");
                return 0.5;
            }

            // 构建频率向量并计算余弦相似度
            List<Integer> vector1 = new ArrayList<>();
            List<Integer> vector2 = new ArrayList<>();

            for (String grid : allGrids) {
                vector1.add(gridCount1.getOrDefault(grid, 0));
                vector2.add(gridCount2.getOrDefault(grid, 0));
            }

            double cosineSimilarity = calculateCosineSimilarity(vector1, vector2);
            System.out.printf("    ✅ 网格相似度: %.4f\n", cosineSimilarity);
            return cosineSimilarity;

        } catch (Exception e) {
            System.err.println("    ❌ 网格相似度计算失败: " + e.getMessage());
            return 0;
        }
    }

    private static Map<String, Integer> mapPathToGrid(List<Long> path,
            ConcurrentHashMap<Integer, node> apl,
            ConcurrentHashMap<Long, Integer> i2i,
            double gridSize,
            ConcurrentHashMap<Long, Long> ii2i) { // 新增参数

        Map<String, Integer> gridCount = new HashMap<>();
        int mappedNodes = 0;
        int failedNodes = 0;

        for (Long nodeId : path) {
            try {
                node nd = findNodeById(nodeId, apl, i2i, ii2i);
                if (nd != null) {
                    int gridX = (int) Math.floor(nd.x / gridSize);
                    int gridY = (int) Math.floor(nd.y / gridSize);
                    String gridKey = gridX + "," + gridY;
                    gridCount.put(gridKey, gridCount.getOrDefault(gridKey, 0) + 1);
                    mappedNodes++;
                } else {
                    failedNodes++;
                }
            } catch (Exception e) {
                failedNodes++;
            }
        }

        System.out.printf("      网格映射: 成功=%d, 失败=%d, 总网格=%d\n",
                mappedNodes, failedNodes, gridCount.size());

        return gridCount;
    }

    private static node findNodeById(Long nodeId, ConcurrentHashMap<Integer, node> apl,
            ConcurrentHashMap<Long, Integer> i2i,
            ConcurrentHashMap<Long, Long> ii2i) {

        // 情况1：如果nodeId是矩阵索引（小数字），通过ii2i找到实际节点ID
        if (nodeId < 10000 && ii2i != null) {
            Long actualNodeId = ii2i.get(nodeId);
            if (actualNodeId != null) {
                Integer idx = i2i.get(actualNodeId);
                if (idx != null) {
                    node nd = apl.get(idx);
                    if (nd != null) {
                        return nd;
                    }
                }
            }
        }

        // 情况2：nodeId已经是实际节点ID
        Integer idx = i2i.get(nodeId);
        if (idx != null) {
            node nd = apl.get(idx);
            if (nd != null) {
                return nd;
            }
        }

        // 情况3：nodeId可能是矩阵索引，直接尝试
        if (nodeId < Integer.MAX_VALUE) {
            int potentialIdx = nodeId.intValue();
            node nd = apl.get(potentialIdx);
            if (nd != null) {
                return nd;
            }
        }

        return null;
    }

    private static double calculateCosineSimilarity(List<Integer> vector1, List<Integer> vector2) {
        if (vector1.size() != vector2.size()) {
            throw new IllegalArgumentException("向量长度必须相同");
        }

        double dotProduct = 0;
        double norm1 = 0;
        double norm2 = 0;

        for (int i = 0; i < vector1.size(); i++) {
            dotProduct += vector1.get(i) * vector2.get(i);
            norm1 += Math.pow(vector1.get(i), 2);
            norm2 += Math.pow(vector2.get(i), 2);
        }

        if (norm1 == 0 || norm2 == 0) {
            return 0;
        }

        return dotProduct / (Math.sqrt(norm1) * Math.sqrt(norm2));
    }

    private static List<Long> removeDuplicateNodesById(List<Long> path) {
        List<Long> result = new ArrayList<>();
        Set<Long> seen = new HashSet<>();

        for (Long nodeId : path) {
            if (seen.add(nodeId)) {
                result.add(nodeId);
            }
        }

        return result;
    }

    // 偏序处理成功率计算
    private static void calculateSuccessRates(TestResult result,
            Floyd_Warshall_1 fw,
            List<TokenNode> navigationOrder,
            ConcurrentHashMap<Long, Integer> i2i,
            List<PartialOrder> userPartialOrders) {
        try {
            int blockageSuccessCount = 0;
            int blockageTotalCount = 0;
            int partialOrderSuccessCount = 0;
            int partialOrderTotalCount = userPartialOrders.size();

            double[][] distMatrix = fw.getGraph1();
            for (int i = 0; i < navigationOrder.size() - 1; i++) {
                TokenNode from = navigationOrder.get(i);
                TokenNode to = navigationOrder.get(i + 1);

                Integer fromIdx = i2i.get(from.getId());
                Integer toIdx = i2i.get(to.getId());

                if (fromIdx != null && toIdx != null) {
                    if (fw.isBlocked(fromIdx, toIdx)) {
                        blockageTotalCount++;

                        if (distMatrix[fromIdx][toIdx] < 20000000.0) {
                            blockageSuccessCount++;
                        }
                    }
                }
            }
            System.out.println("    🔍 偏序约束满足情况详细分析:");
            for (int i = 0; i < userPartialOrders.size(); i++) {
                PartialOrder po = userPartialOrders.get(i);
                long pStId = po.getPSt().getId();
                long sStId = po.getSSt().getId();

                boolean pStInPath = navigationOrder.stream().anyMatch(tn -> tn.getId() == pStId);
                boolean sStInPath = navigationOrder.stream().anyMatch(tn -> tn.getId() == sStId);

                boolean isSatisfied = isPartialOrderSatisfied(navigationOrder, pStId, sStId);

                if (isSatisfied) {
                    partialOrderSuccessCount++;
                    if (pStInPath && sStInPath) {
                        System.out.printf("      ✅ 约束%d满足: %d → %d (两节点都在路径中且顺序正确)\n",
                                i + 1, pStId, sStId);
                    } else if (!pStInPath && !sStInPath) {
                        System.out.printf("      ✅ 约束%d满足: %d → %d (两节点都不在路径中)\n",
                                i + 1, pStId, sStId);
                    } else if (!pStInPath) {
                        System.out.printf("      ✅ 约束%d满足: %d → %d (前驱不在路径中)\n",
                                i + 1, pStId, sStId);
                    } else {
                        System.out.printf("      ✅ 约束%d满足: %d → %d (后继不在路径中)\n",
                                i + 1, pStId, sStId);
                    }
                } else {
                    if (pStInPath && sStInPath) {
                        System.out.printf("      ❌ 约束%d违反: %d → %d (两节点都在路径中但顺序错误)\n",
                                i + 1, pStId, sStId);
                    } else if (pStInPath) {
                        System.out.printf("      ❌ 约束%d违反: %d → %d (前驱在路径中但后继不在)\n",
                                i + 1, pStId, sStId);
                    } else {
                        System.out.printf("      ❌ 约束%d违反: %d → %d (其他违反情况)\n",
                                i + 1, pStId, sStId);
                    }
                }
            }

            // 计算成功率
            result.blockageSuccessRate = blockageTotalCount > 0
                    ? (double) blockageSuccessCount / blockageTotalCount * 100
                    : 100;
            result.partialOrderSuccessRate = partialOrderTotalCount > 0
                    ? (double) partialOrderSuccessCount / partialOrderTotalCount * 100
                    : 100;

            System.out.printf("    ✅ 阻塞绕行成功率: %.2f%% (%d/%d)\n",
                    result.blockageSuccessRate, blockageSuccessCount, blockageTotalCount);
            System.out.printf("    ✅ 偏序处理成功率: %.2f%% (%d/%d)\n",
                    result.partialOrderSuccessRate, partialOrderSuccessCount, partialOrderTotalCount);

        } catch (Exception e) {
            System.err.println("    ❌ 成功率计算失败: " + e.getMessage());
            result.blockageSuccessRate = 0;
            result.partialOrderSuccessRate = 0;
        }
    }

    // 检查偏序约束是否满足
    private static boolean isPartialOrderSatisfied(List<TokenNode> path, long pStId, long sStId) {
        // 先去重再检查
        List<TokenNode> uniquePath = removeDuplicateNodes(path);

        int pStIndex = -1;
        int sStIndex = -1;

        // 正确计算节点在路径中的位置
        for (int i = 0; i < uniquePath.size(); i++) {
            long currentId = uniquePath.get(i).getId();
            if (currentId == pStId) {
                pStIndex = i;
            }
            if (currentId == sStId) {
                sStIndex = i;
            }
        }

        System.out.printf("      偏序检查详细: 约束 %d→%d\n", pStId, sStId);
        System.out.printf("        路径: %s\n",
                uniquePath.stream().map(tn -> String.valueOf(tn.getId())).collect(Collectors.joining(" → ")));
        System.out.printf("        前驱 %d 位置=%d, 后继 %d 位置=%d\n", pStId, pStIndex, sStId, sStIndex);

        if (pStIndex != -1 && sStIndex != -1) {
            boolean satisfied = pStIndex < sStIndex;
            System.out.printf("        结果: %s (前驱%s后继)\n",
                    satisfied ? "✅ 满足" : "❌ 违反",
                    satisfied ? "在" : "不在");
            return satisfied;
        }

        System.out.printf("        结果: ✅ 满足 (节点不全在路径中: 前驱%s, 后继%s)\n",
                (pStIndex == -1 ? "不在" : "在"),
                (sStIndex == -1 ? "不在" : "在"));
        return true;
    }

    private static List<TokenNode> validateAndCompletePath(List<TokenNode> currentPath,
            List<TokenNode> navigatedStops,
            Floyd_Warshall_1 fw,
            ConcurrentHashMap<Long, Integer> i2i) {

        List<TokenNode> completePath = removeDuplicateNodes(currentPath);

        Set<Long> currentNodes = completePath.stream()
                .map(TokenNode::getId)
                .collect(Collectors.toSet());

        int addedStops = 0;
        for (TokenNode stop : navigatedStops) {
            if (!currentNodes.contains(stop.getId())) {
                System.out.printf("    ➕ 补充缺失途径点: %d\n", stop.getId());

                int insertPosition = findInsertPositionByNavigationOrder(stop, completePath, navigatedStops);
                if (insertPosition != -1) {
                    completePath.add(insertPosition, stop);
                    addedStops++;
                    currentNodes.add(stop.getId());
                } else {
                    completePath.add(completePath.size() - 1, stop);
                    addedStops++;
                    currentNodes.add(stop.getId());
                }
            }
        }

        if (addedStops > 0) {
            System.out.printf("    ✅ 补充了 %d 个缺失途径点\n", addedStops);
        }
        return removeDuplicateNodes(completePath);
    }

    private static int findInsertPositionByNavigationOrder(TokenNode nodeToInsert,
            List<TokenNode> currentPath,
            List<TokenNode> navigatedStops) {

        int nodeIndexInNavOrder = -1;
        for (int i = 0; i < navigatedStops.size(); i++) {
            if (navigatedStops.get(i).getId() == nodeToInsert.getId()) {
                nodeIndexInNavOrder = i;
                break;
            }
        }

        if (nodeIndexInNavOrder == -1) {
            return -1;
        }

        for (int i = nodeIndexInNavOrder - 1; i >= 0; i--) {
            TokenNode prevNode = navigatedStops.get(i);
            for (int j = 0; j < currentPath.size(); j++) {
                if (currentPath.get(j).getId() == prevNode.getId()) {
                    return j + 1;
                }
            }
        }

        for (int i = nodeIndexInNavOrder + 1; i < navigatedStops.size(); i++) {
            TokenNode nextNode = navigatedStops.get(i);
            for (int j = 0; j < currentPath.size(); j++) {
                if (currentPath.get(j).getId() == nextNode.getId()) {
                    return j;
                }
            }
        }

        return -1;
    }

    // 重建EncGraph映射
    private static void rebuildEncGraphMapping(ArrayList<TokenNode> tokenList, CKKSHelper ckks) throws Exception {
        System.out.println("  重建EncGraph映射...");
        EncGraph.nodeSet.clear();
        System.out.println("    已清空现有EncGraph映射");
        int successCount = 0;
        int failCount = 0;

        for (TokenNode tn : tokenList) {
            try {
                if (tn.xEnc == null || tn.yEnc == null) {
                    System.out.println("    ⚠️ TokenNode " + tn.getId() + " 缺少加密坐标，跳过");
                    failCount++;
                    continue;
                }

                EncNode encNode = new EncNode(tn.xEnc, tn.yEnc, tn);

                EncNode existing = EncGraph.nodeSet.putIfAbsent(tn, encNode);

                if (existing != null) {
                    System.out.println("    ⚠️ TokenNode " + tn.getId() + " 已存在映射，使用现有映射");
                } else {
                    successCount++;
                }

            } catch (Exception e) {
                System.err.println("    ❌ 创建EncNode失败: " + tn.getId() + " - " + e.getMessage());
                failCount++;
            }
        }

        System.out.println("    映射重建完成: 成功=" + successCount + ", 失败=" + failCount);
    }

    // 验证EncGraph映射
    private static void validateEncGraphMapping(ArrayList<TokenNode> tokenList) {
        System.out.println("  验证EncGraph映射完整性...");

        int mappedCount = 0;
        int missingCount = 0;

        for (TokenNode tn : tokenList) {
            EncNode encNode = EncGraph.nodeSet.get(tn);

            if (encNode == null) {
                System.out.println("    ❌ TokenNode " + tn.getId() + " 在EncGraph中缺失映射");
                missingCount++;

                boolean foundById = false;
                long targetId = tn.getId();

                for (TokenNode key : EncGraph.nodeSet.keySet()) {
                    if (key.getId() == targetId) {
                        System.out.println("    🔍 通过ID找到匹配: " + key.getId());
                        foundById = true;
                        break;
                    }
                }

                if (!foundById) {
                    System.out.println("    ❌ 无法通过ID找到匹配的TokenNode");
                }
            } else {
                mappedCount++;
            }
        }

        System.out.println("    映射验证结果: 已映射=" + mappedCount + ", 缺失=" + missingCount);
        System.out.println("    EncGraph总映射数: " + EncGraph.nodeSet.size());

        if (missingCount > 0) {
            throw new RuntimeException("EncGraph映射不完整，缺失 " + missingCount + " 个节点的映射");
        }
    }

    private static boolean preValidateNavigation(TokenNode E_S, TokenNode E_D, List<TokenNode> E_Stops) {
        System.out.println("  导航预验证...");

        try {
            // 1. 验证EncGraph映射
            if (EncGraph.nodeSet.get(E_S) == null) {
                System.out.println("    ❌ 起点在EncGraph中缺失映射");
                return false;
            }
            if (EncGraph.nodeSet.get(E_D) == null) {
                System.out.println("    ❌ 终点在EncGraph中缺失映射");
                return false;
            }

            if (E_Stops == null || E_Stops.isEmpty()) {
                System.out.println("    ⚠️ 途径点列表为空，但这是允许的");
                return true;
            }

            for (TokenNode stop : E_Stops) {
                if (EncGraph.nodeSet.get(stop) == null) {
                    System.out.println("    ❌ 途径点 " + stop.getId() + " 在EncGraph中缺失映射");
                    return false;
                }
            }

            // 2. 预测试SecureGrouping
            StopSet[] groupingResult = EncNavigationTools.SecureGrouping(E_S, E_D, new ArrayList<>(E_Stops));

            if (groupingResult == null || groupingResult.length < 3) {
                System.out.println("    ❌ SecureGrouping返回无效结果");
                return false;
            }

            if (groupingResult[0].isEmpty() && groupingResult[1].isEmpty() && groupingResult[2].isEmpty()) {
                System.out.println("    ⚠️ SecureGrouping返回全空分组，但这是允许的");
            }

            int totalNodes = groupingResult[0].size() + groupingResult[1].size() + groupingResult[2].size();
            System.out.println("    SecureGrouping预测试: 总分组节点=" + totalNodes);

            return true;

        } catch (Exception e) {
            System.err.println("    ❌ 导航预验证失败: " + e.getMessage());
            return false;
        }
    }

    // 路径生成
    private static ArrayList<Long> generateRobustRandomPath(ConcurrentHashMap<Integer, node> apl,
            int waypointCount,
            Floyd_Warshall_1 fw,
            ConcurrentHashMap<Long, Integer> i2i) {
        ArrayList<Long> path = new ArrayList<>();
        Random random = new Random();
        List<Long> robustNodes = getRobustNodes(apl, fw, i2i);

        if (robustNodes.size() < waypointCount + 2) {
            System.out.println("  警告: 健壮节点不足，使用所有节点");
            robustNodes = getAllNodes(apl);
        }

        Set<Long> used = new HashSet<>();
        path.add(robustNodes.get(random.nextInt(robustNodes.size())));
        used.add(path.get(0));

        for (int i = 0; i < waypointCount; i++) {
            Long node;
            int attempts = 0;
            do {
                node = robustNodes.get(random.nextInt(robustNodes.size()));
                attempts++;
                if (attempts > 100) {
                    // 选择第一个未使用的节点
                    for (Long n : robustNodes) {
                        if (!used.contains(n)) {
                            node = n;
                            break;
                        }
                    }
                    break;
                }
            } while (used.contains(node));

            path.add(node);
            used.add(node);
        }

        // 选择终点
        Long endNode;
        do {
            endNode = robustNodes.get(random.nextInt(robustNodes.size()));
        } while (used.contains(endNode));
        path.add(endNode);

        System.out.println("  生成健壮路径: " + path);
        return path;
    }

    private static List<Long> getRobustNodes(ConcurrentHashMap<Integer, node> apl,
            Floyd_Warshall_1 fw,
            ConcurrentHashMap<Long, Integer> i2i) {
        List<Long> robustNodes = new ArrayList<>();

        for (int i = 0; i < apl.size(); i++) {
            node nd = apl.get(i);
            if (nd != null) {
                if (nd.Neb != null && nd.Neb.size() >= 2) {
                    robustNodes.add(nd.id);
                }
            }
        }

        if (robustNodes.isEmpty()) {
            robustNodes = getAllNodes(apl);
        }

        System.out.println("  健壮节点数量: " + robustNodes.size());
        return robustNodes;
    }

    private static List<Long> getAllNodes(ConcurrentHashMap<Integer, node> apl) {
        List<Long> allNodes = new ArrayList<>();
        for (int i = 0; i < apl.size(); i++) {
            node nd = apl.get(i);
            if (nd != null) {
                allNodes.add(nd.id);
            }
        }
        return allNodes;
    }

    private static List<TokenNode> recoverPath(TokenNode E_S, TokenNode E_D,
            List<TokenNode> navigatedStops,
            GaiaNavigationTools.EncryptedQueryResult eqr,
            CKKSHelper ckks, Floyd_Warshall_1 fw, ConcurrentHashMap<Long, Integer> i2i,
            PRF_PRP_Hash pph, ArrayList<TokenNode> tokenList,
            ConcurrentHashMap<Integer, node> apl) { // 🔥 新增参数

        List<TokenNode> recoveredPath = new ArrayList<>();
        recoveredPath.add(E_S);

        try {
            System.out.println("  🔍 开始路径恢复...");

            ensureNodeInIndexMapping(E_S, i2i, fw, apl);
            ensureNodeInIndexMapping(E_D, i2i, fw, apl);

            int recoveredSegments = 0;
            for (GaiaNavigationTools.EncryptedPathTriple triple : eqr.getTriples()) {
                TokenNode recoveredNode = triple.getESt();
                if (isValidNode(recoveredNode)) {
                    ensureNodeInIndexMapping(recoveredNode, i2i, fw, apl);
                    recoveredPath.add(recoveredNode);
                    recoveredSegments++;

                    System.out.println("      ✅ 恢复节点: " + recoveredNode.getId() +
                            " (映射: " + i2i.get(recoveredNode.getId()) + ")");
                }
            }

            recoveredPath.add(E_D);
            System.out.printf("    基础恢复完成: %d 个路径段\n", recoveredSegments);

            List<TokenNode> deduplicatedPath = removeDuplicateNodes(recoveredPath);
            System.out.printf("    去重后路径: %d → %d 个节点\n", recoveredPath.size(), deduplicatedPath.size());

            String basePathStr = deduplicatedPath.stream()
                    .map(tn -> String.valueOf(tn.getId()))
                    .collect(Collectors.joining(" → "));
            System.out.println("    基础恢复路径: " + basePathStr);

            List<TokenNode> completePath = validateAndCompletePath(deduplicatedPath, navigatedStops, fw, i2i);

            boolean isValid = validatePathDistancesEnhanced(completePath, fw, i2i, ckks);
            if (!isValid) {
                System.out.println("  ⚠️  路径距离验证失败，但继续使用恢复的路径");
            }

            List<TokenNode> finalPath = removeDuplicateNodes(completePath);

            validateFinalPathOrder(finalPath, E_S, E_D, navigatedStops);

            System.out.printf("  ✅ 路径恢复完成: %d 个节点 (去重后)\n", finalPath.size());

            String finalPathStr = finalPath.stream()
                    .map(tn -> String.valueOf(tn.getId()))
                    .collect(Collectors.joining(" → "));
            System.out.println("    最终路径: " + finalPathStr);

            return finalPath;

        } catch (Exception e) {
            System.err.println("  ❌ 路径恢复失败: " + e.getMessage());
            return removeDuplicateNodes(recoveredPath);
        }
    }

    private static void validateFinalPathOrder(List<TokenNode> finalPath,
            TokenNode E_S, TokenNode E_D, List<TokenNode> navigatedStops) {
        System.out.println("    🔍 验证最终路径顺序:");

        // 检查起点和终点位置
        int startIndex = -1;
        int endIndex = -1;
        for (int i = 0; i < finalPath.size(); i++) {
            if (finalPath.get(i).getId() == E_S.getId()) {
                startIndex = i;
            }
            if (finalPath.get(i).getId() == E_D.getId()) {
                endIndex = i;
            }
        }

        boolean startEndCorrect = startIndex < endIndex;
        System.out.printf("      起点 %d[位置%d] → 终点 %d[位置%d]: %s\n",
                E_S.getId(), startIndex, E_D.getId(), endIndex,
                startEndCorrect ? "✅ 正确" : "❌ 错误");

        if (!startEndCorrect) {
            System.out.println("      ⚠️ 警告：路径顺序可能被反转！");
        }
    }

    private static List<TokenNode> removeDuplicateNodes(List<TokenNode> path) {
        List<TokenNode> result = new ArrayList<>();
        Set<Long> seen = new HashSet<>();

        for (TokenNode node : path) {
            if (node != null && seen.add(node.getId())) { // 如果ID是新的才添加
                result.add(node);
            }
        }
        return result;
    }

    private static boolean isValidNode(TokenNode node) {
        if (node == null)
            return false;
        Long id = node.getId();
        return id != null && id > 0;
    }

    private static List<TokenNode> buildNavigationOrder(TokenNode E_S, TokenNode E_D,
            List<TokenNode> navigatedStops,
            GaiaNavigationTools.EncryptedQueryResult eqr,
            List<TokenNode> recoveredPath) {

        long startTime = System.currentTimeMillis();

        try {
            System.out.println("  🛣️  开始路径构建...");

            List<TokenNode> navigationOrder = removeDuplicateNodes(recoveredPath);

            String inputPathStr = navigationOrder.stream()
                    .map(tn -> String.valueOf(tn.getId()))
                    .collect(Collectors.joining(" → "));
            System.out.println("    输入路径: " + inputPathStr);
            if (!validatePathContinuity(navigationOrder)) {
                System.out.println("  ⚠️  路径连续性验证失败，重新排序");
                navigationOrder = reorderPath(navigationOrder);
            }

            navigationOrder = removeDuplicateNodes(navigationOrder);

            if (navigationOrder.size() < 2) {
                throw new RuntimeException("路径节点数量不足");
            }

            String outputPathStr = navigationOrder.stream()
                    .map(tn -> String.valueOf(tn.getId()))
                    .collect(Collectors.joining(" → "));
            System.out.println("    输出路径: " + outputPathStr);

            long endTime = System.currentTimeMillis();
            System.out.printf("  ✅ 路径构建完成: %d ms, %d 个节点 (已去重)\n",
                    (endTime - startTime), navigationOrder.size());

            return navigationOrder;

        } catch (Exception e) {
            System.err.println("  ❌ 路径构建失败: " + e.getMessage());
            List<TokenNode> simplePath = new ArrayList<>();
            simplePath.add(E_S);
            simplePath.addAll(navigatedStops);
            simplePath.add(E_D);
            return removeDuplicateNodes(simplePath);
        }
    }

    // 验证路径连续性
    private static boolean validatePathContinuity(List<TokenNode> path) {
        if (path.size() < 2)
            return false;

        for (int i = 0; i < path.size() - 1; i++) {
            if (path.get(i) == null || path.get(i + 1) == null) {
                return false;
            }
            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
            }
        }
        return true;
    }

    // 重新排序路径
    private static List<TokenNode> reorderPath(List<TokenNode> path) {
        List<TokenNode> sorted = path.stream()
                .filter(Objects::nonNull)
                .sorted(Comparator.comparing(TokenNode::getId))
                .collect(Collectors.toList());
        try {
            Thread.sleep(5);
        } catch (InterruptedException e) {
        }

        return sorted;
    }

    // 测试结果容器
    // 测试结果容器
    private static class TestResult {
        long mapLoadingTime;
        long floydTotalTime;
        long ckksTotalTime;
        long tokenGenerationTime;
        long gaiaTotalTime;
        long pathRecoveryTime;
        long pathConstructionTime;

        double distanceDeviationRate; // 距离偏差率 (Optimality Gap)

        // 🔥 新增：拆分后的膨胀率和相似度
        double per_Original; // 膨胀率 (环境影响: Gaia阻塞 / Gaia无阻塞)
        double per_Optimal; // 膨胀率 (算法影响: Gaia阻塞 / 最优阻塞)

        double ps_Optimal; // 相似度 (算法决策: Gaia阻塞 vs 最优阻塞)
        double ps_Original; // 相似度 (环境畸变: Gaia阻塞 vs Gaia无阻塞)

        double blockageSuccessRate;
        double partialOrderSuccessRate;

        double actualTotalDistance; // Gaia 在阻塞图中的距离
        double gaiaPathOriginalDistance; // Gaia 在无阻塞图中的距离
        double shortestPathDistance; // 最优顺序在阻塞图中的距离 (Optimal)

        List<Long> gaiaPathNodes = new ArrayList<>();
        List<Long> shortestPathNodes = new ArrayList<>();
        CommunicationStats communicationStats;
    }

    // CKKS 初始化方法
    private static CKKSHelper initializeCKKS() throws Exception {
        CKKSHelper ckks = new CKKSHelper(2, 4, 10, 20);
        String basePath = "D:\\Gaia\\src\\main\\resources";
        ckks.loadContext(basePath);
        ckks.loadPublicKeys(basePath);
        ckks.loadSecretKey(basePath);
        ckks.getSecretKey().set_K(GetSKFromJson(basePath + "\\pphsk.json"));

        if (ckks.getPublicKeys() == null) {
            throw new IllegalStateException("CKKS 公钥加载失败");
        }
        if (ckks.getSecretKey() == null) {
            throw new IllegalStateException("CKKS 私钥加载失败");
        }

        return ckks;
    }

    // 随机路径生成方法
    private static ArrayList<Long> generateRandomPath(ConcurrentHashMap<Integer, node> apl, int waypointCount) {
        ArrayList<Long> path = new ArrayList<>();
        Random random = new Random();
        Set<Long> usedNodes = new HashSet<>();

        if (apl.isEmpty()) {
            throw new RuntimeException("地图节点列表为空");
        }

        List<Long> availableNodes = new ArrayList<>();
        for (int i = 0; i < apl.size(); i++) {
            if (apl.get(i) != null) {
                availableNodes.add(apl.get(i).id);
            }
        }

        if (availableNodes.size() < waypointCount + 2) {
            throw new RuntimeException("可用节点数量不足");
        }

        Long startNode = availableNodes.get(random.nextInt(availableNodes.size()));
        path.add(startNode);
        usedNodes.add(startNode);

        for (int i = 0; i < waypointCount; i++) {
            Long nodeId;
            int attempts = 0;
            do {
                nodeId = availableNodes.get(random.nextInt(availableNodes.size()));
                attempts++;
                if (attempts > 50) {
                    for (Long candidate : availableNodes) {
                        if (!usedNodes.contains(candidate)) {
                            nodeId = candidate;
                            break;
                        }
                    }
                    break;
                }
            } while (usedNodes.contains(nodeId));

            path.add(nodeId);
            usedNodes.add(nodeId);
        }

        Long endNode;
        int attempts = 0;
        do {
            endNode = availableNodes.get(random.nextInt(availableNodes.size()));
            attempts++;
            if (attempts > 50) {
                for (int j = availableNodes.size() - 1; j >= 0; j--) {
                    Long candidate = availableNodes.get(j);
                    if (!usedNodes.contains(candidate)) {
                        endNode = candidate;
                        break;
                    }
                }
                break;
            }
        } while (usedNodes.contains(endNode));

        path.add(endNode);

        System.out.printf("  生成路径: %s\n", path.stream()
                .map(String::valueOf)
                .collect(Collectors.joining(" → ")));

        return path;
    }

    private static List<Long> parsePathNodes(String path) {
        List<Long> nodes = new ArrayList<>();
        if (path == null || path.isEmpty() || path.equals("原地踏步")) {
            return nodes;
        }

        try {
            String[] parts = path.split("->");
            for (String part : parts) {
                part = part.trim();
                if (!part.isEmpty()) {
                    if (part.matches("\\d+")) {
                        nodes.add(Long.parseLong(part));
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("    解析路径节点失败: " + path + " - " + e.getMessage());
        }

        return nodes;
    }

    private static boolean areConstraintsFeasible(List<PartialOrder> partialOrders) {
        if (partialOrders.isEmpty()) {
            return true;
        }

        // 构建约束图
        Map<Long, List<Long>> graph = new HashMap<>();
        Map<Long, Integer> inDegree = new HashMap<>();

        // 初始化图结构
        for (PartialOrder po : partialOrders) {
            Long from = po.getPSt().getId();
            Long to = po.getSSt().getId();

            graph.putIfAbsent(from, new ArrayList<>());
            graph.putIfAbsent(to, new ArrayList<>());
            inDegree.putIfAbsent(from, 0);
            inDegree.putIfAbsent(to, 0);
        }

        // 添加边
        for (PartialOrder po : partialOrders) {
            Long from = po.getPSt().getId();
            Long to = po.getSSt().getId();

            graph.get(from).add(to);
            inDegree.put(to, inDegree.get(to) + 1);
        }

        // 拓扑排序检测环
        Queue<Long> queue = new LinkedList<>();
        int visitedCount = 0;

        // 添加入度为0的节点
        for (Long node : inDegree.keySet()) {
            if (inDegree.get(node) == 0) {
                queue.offer(node);
            }
        }

        // 执行拓扑排序
        while (!queue.isEmpty()) {
            Long current = queue.poll();
            visitedCount++;

            if (graph.containsKey(current)) {
                for (Long neighbor : graph.get(current)) {
                    inDegree.put(neighbor, inDegree.get(neighbor) - 1);
                    if (inDegree.get(neighbor) == 0) {
                        queue.offer(neighbor);
                    }
                }
            }
        }

        // 如果所有节点都被访问，说明无环
        boolean isFeasible = visitedCount == graph.size();
        System.out.printf("      约束可行性检查: 节点%d/节点%d -> %s\n",
                visitedCount, graph.size(), isFeasible ? "可行" : "有环");
        return isFeasible;
    }

    private static void ensureNodeInIndexMapping(TokenNode node,
            ConcurrentHashMap<Long, Integer> i2i, Floyd_Warshall_1 fw,
            ConcurrentHashMap<Integer, node> apl) {

        if (!i2i.containsKey(node.getId())) {
            System.out.println("    🔧 修复节点索引映射: " + node.getId());

            // 方法1: 通过apl查找对应的索引
            for (Map.Entry<Integer, node> entry : apl.entrySet()) {
                if (entry.getValue() != null && entry.getValue().id == node.getId()) {
                    i2i.put(node.getId(), entry.getKey());
                    System.out.println("      ✅ 通过apl找到映射: " + node.getId() + " -> " + entry.getKey());
                    return;
                }
            }

            // 方法2: 如果节点ID是数字且较小，可能直接就是索引
            if (node.getId() < 2000 && node.getId() >= 0) {
                i2i.put(node.getId(), (int) node.getId());
                System.out.println("      ✅ 节点ID作为索引: " + node.getId() + " -> " + node.getId());
                return;
            }

            // 方法3: 通过EncGraph查找
            for (TokenNode existingNode : EncGraph.nodeSet.keySet()) {
                if (existingNode.getId() == node.getId()) {
                    // 再次尝试通过apl查找
                    for (Map.Entry<Integer, node> entry : apl.entrySet()) {
                        if (entry.getValue() != null && entry.getValue().id == node.getId()) {
                            i2i.put(node.getId(), entry.getKey());
                            System.out.println("      ✅ 通过EncGraph+apl找到映射: " + node.getId() + " -> " + entry.getKey());
                            return;
                        }
                    }
                    break;
                }
            }

            System.out.println("      ❌ 无法修复节点映射: " + node.getId());
        }
    }

    private static boolean validatePathDistancesEnhanced(List<TokenNode> path,
            Floyd_Warshall_1 fw,
            ConcurrentHashMap<Long, Integer> i2i,
            CKKSHelper ckks) {
        try {
            double totalDistance = 0;
            double[][] distMatrix = fw.getGraph1();
            int validSegments = 0;
            int invalidSegments = 0;
            int missingIndexSegments = 0;

            System.out.println("    🔍 增强路径验证:");

            for (int i = 0; i < path.size() - 1; i++) {
                TokenNode from = path.get(i);
                TokenNode to = path.get(i + 1);

                Integer fromIdx = i2i.get(from.getId());
                Integer toIdx = i2i.get(to.getId());

                if (fromIdx != null && toIdx != null) {
                    double segmentDistance = distMatrix[fromIdx][toIdx];
                    if (segmentDistance >= 0 && segmentDistance < 100000) {
                        totalDistance += segmentDistance;
                        validSegments++;
                        System.out.printf("      ✅ 段 %d->%d: 距离=%.2f\n",
                                from.getId(), to.getId(), segmentDistance);
                    } else {
                        System.out.printf("      ⚠️  段 %d->%d 距离异常: %.2f\n",
                                from.getId(), to.getId(), segmentDistance);
                        invalidSegments++;
                    }
                } else {
                    System.out.printf("      ⚠️  段 %d->%d 节点索引缺失 (fromIdx=%s, toIdx=%s)\n",
                            from.getId(), to.getId(), fromIdx, toIdx);
                    missingIndexSegments++;
                }
            }

            System.out.printf("    📏 路径验证统计: 有效=%d, 异常=%d, 缺失索引=%d, 总计=%d\n",
                    validSegments, invalidSegments, missingIndexSegments, path.size() - 1);

            double validRatio = (double) validSegments / (path.size() - 1);
            System.out.printf("    📊 有效段比例: %.1f%%\n", validRatio * 100);

            return validRatio >= 0.3;

        } catch (Exception e) {
            System.err.println("    ❌ 距离验证异常: " + e.getMessage());
            return true;
        }
    }
}