package GaiaTest;
import Algorithm.Floyd_Warshall_1;
import Class.PartialOrder;
import Class.TokenNode;
import Class.node;
import NSP.EncNavigationTools;
import NSP.EncNode;
import NSP.EncGraph;
import NSP.EncVecTools;
import Gaia.GaiaNavigationTools;
import User.*;
import ckks.CKKSHelper;
import lombok.SneakyThrows;
import util.*;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import Proxy.CT;

import static util.JsonUtil.*;
import java.util.stream.*;

public class Test3 {
    private static final int TEST_ITERATIONS = 5;
    // 你可以将途径点数量改回 {2} 或其他数值进行测试
    private static final int[] WAYPOINT_COUNTS = { 5 }; 
    private static final int[] CONSTRAINT_PAIRS = { 0, 1, 2, 3, 4, 5 };
    private static final double[] BLOCKAGE_RATIOS = { 0,0.05,0.10,0.15,0.20 };

    private static final String RESULT_DIR = "D:\\Gaia\\test_results";
    private static final String RESULT_FILE = RESULT_DIR + "\\gaia_optimality_results1000.csv";
    private static final String LOG_FILE = RESULT_DIR + "\\Test3_simplified1000.log";

    @SneakyThrows
    public static void main(String[] args) {
        clearLogFile();
        java.io.FileOutputStream fos = new java.io.FileOutputStream(LOG_FILE, true);
        java.io.PrintStream ps = new PrintStream(fos, true, "UTF-8");
        System.setOut(ps);
        System.setErr(ps);
        System.out.println("=== Gaia 最优性与相似度聚焦测试 (修正版) ===");
        performanceTest();
    }

    @SneakyThrows
    private static void clearLogFile() {
        File logFile = new File(LOG_FILE);
        if (logFile.exists()) {
            try (PrintWriter writer = new PrintWriter(new FileWriter(LOG_FILE, false))) { writer.print(""); }
        } else {
            File dir = new File(RESULT_DIR);
            if (!dir.exists()) dir.mkdirs();
            logFile.createNewFile();
        }
    }

    @SneakyThrows
    public static void performanceTest() {
        File dir = new File(RESULT_DIR);
        if (!dir.exists()) dir.mkdirs();

        try (PrintWriter writer = new PrintWriter(new FileWriter(RESULT_FILE))) {
            // CSV 表头
            writer.println("阻塞比例,途径点数量,约束对数,迭代轮次,Gaia距离,理论最优距离,导航最优差(%),最优路径相似度(%)");

            for (double blockageRatio : BLOCKAGE_RATIOS) {
                for (int waypointCount : WAYPOINT_COUNTS) {
                    
                    // 简单的过滤器：如果约束数量对于节点数来说太多，容易死锁，虽然代码能处理，但可以提前跳过
                    int maxReasonableConstraints = waypointCount * (waypointCount - 1); 

                    for (int constraintPairs : CONSTRAINT_PAIRS) {
                        if (constraintPairs > 0 && waypointCount < 2) continue;
                        if (constraintPairs > maxReasonableConstraints) continue;

                        System.out.printf("\n=== 配置: %d点 %d约束 %.0f%%阻塞 ===\n", waypointCount, constraintPairs, blockageRatio * 100);

                        // 累加器
                        double totalGaiaDist = 0;
                        double totalOptimalDist = 0;
                        double totalGap = 0;
                        double totalSimilarity = 0;
                        int validCount = 0;

                        for (int i = 0; i < TEST_ITERATIONS; i++) {
                            try {
                                TestResult res = runSingleTest(waypointCount, constraintPairs, blockageRatio);
                                
                                // 只有有效的测试结果才写入 CSV
                                if (res.isValid) {
                                    String line = String.format("%.2f,%d,%d,%d,%.2f,%.2f,%.2f,%.2f",
                                            blockageRatio, waypointCount, constraintPairs, i + 1,
                                            res.gaiaDistance, res.optimalDistance, res.optimalityGap, res.pathSimilarity);
                                    writer.println(line);
                                    writer.flush();

                                    totalGaiaDist += res.gaiaDistance;
                                    totalOptimalDist += res.optimalDistance;
                                    totalGap += res.optimalityGap;
                                    totalSimilarity += res.pathSimilarity;
                                    validCount++;
                                    
                                    System.out.printf("  [Iter %d] Gap: %.2f%% | Sim: %.2f%%\n", i+1, res.optimalityGap, res.pathSimilarity);
                                } else {
                                    // 无效结果（如死锁、不可达）不写入数据，或者写入 -1 标记
                                    // writer.println(String.format("%.2f,%d,%d,%d,-1,-1,-1,-1", blockageRatio, waypointCount, constraintPairs, i + 1));
                                    System.out.printf("  [Iter %d] 跳过无效测试 (约束冲突或不可达)\n", i+1);
                                }
                            } catch (Exception e) {
                                System.err.println("迭代异常: " + e.getMessage());
                            }
                        }

                        // 记录平均值
                        if (validCount > 0) {
                            String avgLine = String.format("%.2f,%d,%d,平均值,%.2f,%.2f,%.2f,%.2f",
                                    blockageRatio, waypointCount, constraintPairs,
                                    totalGaiaDist / validCount,
                                    totalOptimalDist / validCount,
                                    totalGap / validCount,
                                    totalSimilarity / validCount);
                            writer.println(avgLine);
                            writer.println(); // 空行分隔
                            writer.flush();
                        }
                    }
                }
            }
            System.out.println("测试完成，结果已保存: " + RESULT_FILE);
        }
    }

    private static class TestResult {
        boolean isValid = false;
        double gaiaDistance;
        double optimalDistance;
        double optimalityGap;
        double pathSimilarity;
    }

    private static TestResult runSingleTest(int waypointCount, int constraintPairs, double blockageRatio) throws Exception {
        System.gc();
        TestResult result = new TestResult();

        // 1. 环境初始化
        ConcurrentHashMap<Long, Integer> i2i = new ConcurrentHashMap<>();
        ConcurrentHashMap<Long, Long> ii2i = new ConcurrentHashMap<>();
        ConcurrentHashMap<Long, Long> oi2i = new ConcurrentHashMap<>();
        String json = "D:\\Gaia\\src\\main\\resources\\400-2200junctions(Manhattan) (2)\\2000\\2000junction.json";
        ConcurrentHashMap<Integer, node> apl = JsonUtil.getNodeList600(json, i2i, ii2i, oi2i);
        getMapInJson(i2i, ii2i, oi2i);

        Floyd_Warshall_1 fw = new Floyd_Warshall_1(apl, i2i, blockageRatio);
        fw.setup();
        fw.compute();
        GaiaNavigationTools.setFloydInstance(fw);

        CKKSHelper ckks = initializeCKKS();
        ArrayList<Long> plainQuery = generateRandomPath(apl, waypointCount);
        List<PartialOrder> userPartialOrders = generatePartialOrders(plainQuery, constraintPairs);

        PRF_PRP_Hash pph = new PRF_PRP_Hash(ckks.getSecretKey());
        QueryTokenGen gentoken = new QueryTokenGen(pph, plainQuery, ii2i, i2i, apl, ckks);
        ArrayList<TokenNode> tokenList = gentoken.getData();
        rebuildEncGraphMapping(tokenList, ckks);

        TokenNode E_S = tokenList.get(0);
        TokenNode E_D = tokenList.get(tokenList.size() - 1);
        List<TokenNode> E_Stops = tokenList.subList(1, tokenList.size() - 1);

        // 2. Gaia 导航执行
        CT ct;
        synchronized (GaiaNavigationTools.class) {
            ct = new CT(ckks.getPublicKeys(), ckks.getContext());
            GaiaNavigationTools.setCKKS(ckks, ct);
            EncNavigationTools.init(ckks, ct, ckks.getPublicKeys());
            EncVecTools.init(ckks.getContext(), ckks.getPublicKeys());
            byte[] sk3 = new byte[32];
            new Random().nextBytes(sk3);
            GaiaNavigationTools.setSK3(sk3);
        }

        GaiaNavigationTools.EncryptedQueryResult eqr;
        List<TokenNode> gaiaNavigatedStops;
        synchronized (GaiaNavigationTools.class) {
            GaiaNavigationTools.Navigator navigator = new GaiaNavigationTools.Navigator(E_S, E_D, E_Stops, userPartialOrders, apl, i2i);
            eqr = navigator.run();
            gaiaNavigatedStops = new ArrayList<>(navigator.sortedStops);
        }

        // 3. 路径恢复 (为了展示/调试，此处只取节点顺序)
        // List<TokenNode> recoveredPath = recoverPath(E_S, E_D, gaiaNavigatedStops, eqr, ckks, fw, i2i, apl);

        // 4. 🔥 核心指标计算

        // 4.1 计算理论最优序列 (Brute Force)
        // 如果无解（比如约束死锁），返回 null
        List<TokenNode> optimalStopOrder = findOptimalSequence(E_S, E_D, E_Stops, userPartialOrders, fw, i2i);

        // 4.2 验证测试有效性
        if (optimalStopOrder == null) {
            result.isValid = false; // 约束冲突，跳过
            return result;
        }
        if (gaiaNavigatedStops.size() != E_Stops.size()) {
            result.isValid = false; // Gaia 漏点，跳过
            return result;
        }

        // 4.3 计算距离
        double optimalDist = calculateTotalDistance(E_S, E_D, optimalStopOrder, fw, i2i);
        double gaiaDist = calculateTotalDistance(E_S, E_D, gaiaNavigatedStops, fw, i2i);

        result.gaiaDistance = gaiaDist;
        result.optimalDistance = optimalDist;

        if (optimalDist > 0 && optimalDist < 20000000.0) {
             double gap = gaiaDist - optimalDist;
             // 处理浮点误差，不允许出现负 Gap
             if (gap < 0 && gap > -1.0) gap = 0; 
             
             result.optimalityGap = (gap / optimalDist) * 100.0;
             result.isValid = true;
        } else {
            result.isValid = false; // 路径不连通
            return result;
        }

        // 5. 计算路径相似度 (Gaia vs Optimal)
        result.pathSimilarity = calculateSimilarityBetweenPaths(
                E_S, E_D, 
                gaiaNavigatedStops, 
                optimalStopOrder, 
                fw, apl, i2i, ii2i
        );

        return result;
    }

    /**
     * 暴力全排列寻找满足约束的最优途径点顺序
     * 修正：找不到返回 null
     */
    private static List<TokenNode> findOptimalSequence(TokenNode s, TokenNode d, List<TokenNode> stops, 
                                                     List<PartialOrder> constraints, Floyd_Warshall_1 fw, 
                                                     ConcurrentHashMap<Long, Integer> i2i) {
        if (stops == null || stops.isEmpty()) return new ArrayList<>();
        
        List<Integer> indices = new ArrayList<>();
        for (int i = 0; i < stops.size(); i++) indices.add(i);
        
        List<List<Integer>> perms = new ArrayList<>();
        generatePermutations(indices, 0, perms);
        
        double minDst = Double.MAX_VALUE;
        List<TokenNode> bestOrder = null; // 默认为 null
        
        for (List<Integer> p : perms) {
            List<TokenNode> currentOrder = new ArrayList<>();
            for (int idx : p) currentOrder.add(stops.get(idx));
            
            if (isOrderValid(currentOrder, constraints)) {
                double dst = calculateTotalDistance(s, d, currentOrder, fw, i2i);
                if (dst < minDst) {
                    minDst = dst;
                    bestOrder = new ArrayList<>(currentOrder);
                }
            }
        }
        return bestOrder;
    }

    private static double calculateSimilarityBetweenPaths(TokenNode s, TokenNode d, 
                                                        List<TokenNode> stopsA, List<TokenNode> stopsB,
                                                        Floyd_Warshall_1 fw, ConcurrentHashMap<Integer, node> apl,
                                                        ConcurrentHashMap<Long, Integer> i2i, ConcurrentHashMap<Long, Long> ii2i) {
        try {
            List<Long> fullPathA = restoreCompletePath(s, d, stopsA, fw);
            List<Long> fullPathB = restoreCompletePath(s, d, stopsB, fw);

            double gridSize = 50.0;
            Map<String, Integer> gridA = mapPathToGrid(fullPathA, apl, i2i, gridSize, ii2i);
            Map<String, Integer> gridB = mapPathToGrid(fullPathB, apl, i2i, gridSize, ii2i);
            
            Set<String> unionGrids = new HashSet<>(gridA.keySet());
            unionGrids.addAll(gridB.keySet());
            
            if (unionGrids.isEmpty()) return 0;
            
            List<Integer> vecA = new ArrayList<>();
            List<Integer> vecB = new ArrayList<>();
            for (String g : unionGrids) {
                vecA.add(gridA.getOrDefault(g, 0));
                vecB.add(gridB.getOrDefault(g, 0));
            }
            double geoSim = calculateCosineSimilarity(vecA, vecB);

            double lenA = calculateTotalDistance(s, d, stopsA, fw, i2i);
            double lenB = calculateTotalDistance(s, d, stopsB, fw, i2i);
            double lenSim = 0;
            if (lenA > 0 && lenB > 0) {
                lenSim = Math.min(lenA, lenB) / Math.max(lenA, lenB);
            }
            return (geoSim * 0.7 + lenSim * 0.3) * 100.0;
        } catch (Exception e) {
            return 0;
        }
    }

    // --- 辅助方法 ---

    private static List<Long> restoreCompletePath(TokenNode s, TokenNode d, List<TokenNode> mids, Floyd_Warshall_1 fw) {
        List<Long> full = new ArrayList<>();
        List<TokenNode> all = new ArrayList<>();
        all.add(s); all.addAll(mids); all.add(d);
        for (int i = 0; i < all.size() - 1; i++) {
            String pStr = fw.getPathBetweenNodes(all.get(i).getId(), all.get(i+1).getId());
            List<Long> seg = parsePathNodes(pStr);
            if (i > 0 && !seg.isEmpty() && seg.get(0).equals(all.get(i).getId())) seg.remove(0);
            if (seg.isEmpty()) { 
                if(i==0) full.add(all.get(i).getId());
                full.add(all.get(i+1).getId());
            } else {
                if(i==0 && !seg.get(0).equals(all.get(i).getId())) full.add(all.get(i).getId());
                full.addAll(seg);
                if(!full.get(full.size()-1).equals(all.get(i+1).getId())) full.add(all.get(i+1).getId());
            }
        }
        return full;
    }

    private static double calculateTotalDistance(TokenNode s, TokenNode d, List<TokenNode> mids, 
                                               Floyd_Warshall_1 fw, ConcurrentHashMap<Long, Integer> i2i) {
        double total = 0;
        List<TokenNode> all = new ArrayList<>();
        all.add(s); all.addAll(mids); all.add(d);
        for(int i=0; i<all.size()-1; i++) {
            Integer u = i2i.get(all.get(i).getId());
            Integer v = i2i.get(all.get(i+1).getId());
            if(u!=null && v!=null) {
                double dist = fw.getGraph1()[u][v];
                if(dist >= 19000000.0) return 20000000.0;
                total += dist;
            }
        }
        return total;
    }

    private static void generatePermutations(List<Integer> arr, int k, List<List<Integer>> res) {
        for (int i = k; i < arr.size(); i++) {
            Collections.swap(arr, i, k);
            generatePermutations(arr, k + 1, res);
            Collections.swap(arr, i, k);
        }
        if (k == arr.size() - 1) res.add(new ArrayList<>(arr));
    }

    private static boolean isOrderValid(List<TokenNode> order, List<PartialOrder> constraints) {
        if (constraints == null) return true;
        Map<Long, Integer> idxMap = new HashMap<>();
        for(int i=0; i<order.size(); i++) idxMap.put(order.get(i).getId(), i);
        for(PartialOrder po : constraints) {
            long p = po.getPSt().getId();
            long s = po.getSSt().getId();
            if(idxMap.containsKey(p) && idxMap.containsKey(s)) {
                if(idxMap.get(p) > idxMap.get(s)) return false;
            }
        }
        return true;
    }

    private static Map<String, Integer> mapPathToGrid(List<Long> path, ConcurrentHashMap<Integer, node> apl, 
                                                    ConcurrentHashMap<Long, Integer> i2i, double gSize, ConcurrentHashMap<Long, Long> ii2i) {
        Map<String, Integer> map = new HashMap<>();
        for(Long id : path) {
            node n = findNodeById(id, apl, i2i, ii2i);
            if(n!=null) {
                String k = (int)(n.x/gSize) + "," + (int)(n.y/gSize);
                map.put(k, map.getOrDefault(k, 0)+1);
            }
        }
        return map;
    }

    private static double calculateCosineSimilarity(List<Integer> v1, List<Integer> v2) {
        double dot=0, n1=0, n2=0;
        for(int i=0; i<v1.size(); i++) {
            dot += v1.get(i)*v2.get(i);
            n1 += Math.pow(v1.get(i), 2);
            n2 += Math.pow(v2.get(i), 2);
        }
        return (n1==0||n2==0) ? 0 : dot/(Math.sqrt(n1)*Math.sqrt(n2));
    }

    private static node findNodeById(Long id, ConcurrentHashMap<Integer, node> apl, ConcurrentHashMap<Long, Integer> i2i, ConcurrentHashMap<Long, Long> ii2i) {
        if(id < 10000 && ii2i!=null && ii2i.containsKey(id)) id = ii2i.get(id);
        Integer idx = i2i.get(id);
        if(idx!=null) return apl.get(idx);
        return null;
    }

    // 修正：long 无法与 null 比较，已移除 != null 检查
    private static boolean isValidNode(TokenNode node) { 
        return node != null && node.getId() > 0; 
    }

    private static CKKSHelper initializeCKKS() throws Exception {
        CKKSHelper ckks = new CKKSHelper(2, 4, 10, 20);
        String p = "D:\\Gaia\\src\\main\\resources";
        ckks.loadContext(p); ckks.loadPublicKeys(p);
        ckks.loadSecretKey(p); ckks.getSecretKey().set_K(GetSKFromJson(p + "\\pphsk.json"));
        return ckks;
    }
    
    private static ArrayList<Long> generateRandomPath(ConcurrentHashMap<Integer, node> apl, int cnt) {
        ArrayList<Long> p = new ArrayList<>();
        Random r = new Random();
        List<Long> ids = new ArrayList<>();
        for(node n : apl.values()) ids.add(n.id);
        Set<Long> used = new HashSet<>();
        for(int i=0; i<cnt+2; i++) {
            Long id;
            do { id = ids.get(r.nextInt(ids.size())); } while(used.contains(id));
            p.add(id); used.add(id);
        }
        return p;
    }

    private static List<PartialOrder> generatePartialOrders(ArrayList<Long> path, int cnt) {
        List<PartialOrder> pos = new ArrayList<>();
        if(cnt<=0) return pos;
        List<Long> mids = path.subList(1, path.size()-1);
        Random r = new Random();
        Set<String> used = new HashSet<>();
        while(pos.size() < cnt) {
            int i1 = r.nextInt(mids.size()), i2 = r.nextInt(mids.size());
            if(i1==i2) continue;
            String k = mids.get(i1) + "-" + mids.get(i2);
            if(used.add(k)) pos.add(new PartialOrder(new TokenNode("", "", "", mids.get(i1)), new TokenNode("", "", "", mids.get(i2))));
        }
        return pos;
    }
    
    private static void rebuildEncGraphMapping(ArrayList<TokenNode> list, CKKSHelper ckks) throws Exception {
        EncGraph.nodeSet.clear();
        for(TokenNode t : list) EncGraph.nodeSet.put(t, new EncNode(t.xEnc, t.yEnc, t));
    }
    
    private static List<TokenNode> recoverPath(TokenNode s, TokenNode d, List<TokenNode> mids, GaiaNavigationTools.EncryptedQueryResult res, CKKSHelper ckks, Floyd_Warshall_1 fw, ConcurrentHashMap<Long, Integer> i2i, ConcurrentHashMap<Integer, node> apl) {
        List<TokenNode> path = new ArrayList<>();
        path.add(s);
        for(GaiaNavigationTools.EncryptedPathTriple t : res.getTriples()) {
            TokenNode n = t.getESt();
            if(isValidNode(n)) path.add(n);
        }
        path.add(d);
        return removeDuplicateNodes(path);
    }

    private static List<TokenNode> removeDuplicateNodes(List<TokenNode> l) {
        List<TokenNode> r = new ArrayList<>();
        Set<Long> s = new HashSet<>();
        for(TokenNode n : l) if(n!=null && s.add(n.getId())) r.add(n);
        return r;
    }

    private static List<Long> parsePathNodes(String p) {
        List<Long> l = new ArrayList<>();
        if(p==null || p.isEmpty() || p.equals("原地踏步")) return l;
        for(String s : p.split("->")) if(s.matches("\\d+")) l.add(Long.parseLong(s));
        return l;
    }
}