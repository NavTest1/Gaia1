package GaiaTest;
import Algorithm.Floyd_Warshall_1;
import Class.TokenNode;
import Class.node;
import NSP.EncGraph;
import NSP.EncNavigationImpl.HermesEncNavigation;
import NSP.EncNavigationTools;
import NSP.EncNode;
import User.PRF_PRP_Hash;
import User.QueryTokenGen;
import ckks.CKKSHelper;
import util.EncryptedGraphManager;
import util.JsonUtil;
import Proxy.CT;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * Hermes 对比实验 - 使用缓存的加密图
 * 这里的目的是复现 Hermes 算法，但使用与 Gaia 实验完全相同的加密数据环境
 * 设定：阻塞率 0%，无偏序约束
 */
public class Testall {

    // 配置参数
    private static final String GRAPH_KEY = "400"; // 对应你实验的地图规模
    private static final double BLOCKAGE_RATIO = 0.00; // 0% 阻塞
    private static final int TEST_ITERATIONS = 5; // 测试次数
    private static final int[] WAYPOINT_COUNTS = {5}; // 途径点数量

    public static void main(String[] args) throws Exception {
        System.out.println("=== 开始 Hermes 复现实验 (基于缓存加密图) ===");
        System.out.println("目标: 0% 阻塞, 无偏序约束, 纯导航时间对比");

        // 1. 加载缓存的加密图 (与 Test3 逻辑一致)
        System.out.println("\n[1] 加载加密图缓存...");
        if (!EncryptedGraphManager.encryptedGraphExists(GRAPH_KEY, BLOCKAGE_RATIO)) {
            System.err.println("❌ 错误: 未找到 0% 阻塞的缓存文件。请先运行 Test3 生成一次缓存。");
            return;
        }

        EncryptedGraphManager.EncryptedGraphData graphData = 
            EncryptedGraphManager.loadEncryptedGraph(GRAPH_KEY, BLOCKAGE_RATIO);

        ConcurrentHashMap<Integer, node> apl = graphData.getApl();
        ConcurrentHashMap<Long, Integer> i2i = graphData.getI2i();
        ConcurrentHashMap<Long, Long> ii2i = graphData.getIi2i();
        
        System.out.println("✅ 缓存加载成功: 节点数 " + apl.size());

        // 2. 初始化 Floyd (Hermes 虽然逻辑不同，但可能需要基础距离判断，保持环境一致)
        Floyd_Warshall_1 fw = new Floyd_Warshall_1(apl, i2i, BLOCKAGE_RATIO);
        fw.setup();
        fw.computeOriginalFloydOnly(); // 0% 阻塞只需要计算原始矩阵

        // 3. 初始化 CKKS 和 Crypto Context (必须与缓存生成时一致)
        System.out.println("\n[2] 初始化密码学环境...");
        CKKSHelper ckks = initializeCKKS();
        PRF_PRP_Hash pph = new PRF_PRP_Hash(ckks.getSecretKey());
        
        // 初始化 CT 和 EncNavigationTools (Hermes 依赖这些静态工具)
        CT ct = new CT(ckks.getPublicKeys(), ckks.getContext());
        EncNavigationTools.init(ckks, ct, ckks.getPublicKeys());

        // 4. 开始循环测试
        System.out.println("\n[3] 开始性能测试循环...");
        System.out.println("途径点数, 迭代轮次, 导航耗时(ms)");

        for (int k : WAYPOINT_COUNTS) {
            long totalNavTime = 0;
            int successCount = 0;

            System.out.println("--- 测试途径点数量: " + k + " ---");

            for (int i = 0; i < TEST_ITERATIONS; i++) {
                try {
                    // 4.1 生成随机查询路径
                    ArrayList<Long> plainQuery = generateRandomPath(apl, k);
                    
                    // 4.2 生成令牌 (TokenGen)
                    // 注意：这里生成的 TokenNode 包含了加密坐标
                    QueryTokenGen gentoken = new QueryTokenGen(pph, plainQuery, ii2i, i2i, apl, ckks);
                    ArrayList<TokenNode> tokenList = gentoken.getData();
                    
                    // 4.3 重建 EncGraph 映射
                    // ⚠️ 关键步骤：Hermes 极其依赖 EncGraph.nodeSet 静态查找表
                    // 缓存中虽然有节点数据，但静态 Map 在程序重启后是空的，必须手动填回去
                    rebuildEncGraphMapping(tokenList);

                    // 准备 Hermes 需要的参数
                    TokenNode E_S = tokenList.get(0);
                    TokenNode E_D = tokenList.get(tokenList.size() - 1);
                    // 提取中间途径点数组
                    List<TokenNode> stopsList = tokenList.subList(1, tokenList.size() - 1);
                    TokenNode[] listStops = stopsList.toArray(new TokenNode[0]);

                    // 4.4 初始化 Hermes 导航器
                    HermesEncNavigation hermes = new HermesEncNavigation(ckks.getPublicKeys(), ckks.getContext());
                    ArrayList<TokenNode> resultPath = new ArrayList<>();
                    
                    // 添加起点 (Hermes 逻辑通常需要先把起点放进去)
                    resultPath.add(E_S);

                    // 4.5 🔥 核心计时：Hermes 导航
                    System.gc(); // 清理内存干扰
                    Thread.sleep(50); 
                    
                    long start = System.currentTimeMillis();
                    
                    // 调用 Hermes 的 SecureNavigation
                    hermes.SecureNavigation(resultPath, E_S, E_D, listStops);
                    
                    long end = System.currentTimeMillis();
                    long duration = end - start;

                    totalNavTime += duration;
                    successCount++;

                    System.out.printf("  Run %d: %d ms | 路径长度: %d\n", i + 1, duration, resultPath.size());

                } catch (Exception e) {
                    System.err.println("  Run " + (i + 1) + " Failed: " + e.getMessage());
                    e.printStackTrace();
                }
            }

            // 计算平均值
            if (successCount > 0) {
                double avgTime = (double) totalNavTime / successCount;
                System.out.println(">>> 平均导航时间 (k=" + k + "): " + String.format("%.2f", avgTime) + " ms");
            }
            System.out.println("--------------------------------");
        }
    }

    // --- 辅助方法 (复用自 Test3) ---

    private static CKKSHelper initializeCKKS() throws Exception {
        CKKSHelper ckks = new CKKSHelper(2, 4, 10, 20);
        String basePath = "D:\\Gaia\\src\\main\\resources"; // 确保路径与 Test3 一致
        ckks.loadContext(basePath);
        ckks.loadPublicKeys(basePath);
        ckks.loadSecretKey(basePath);
        // 如果有 pphsk.json 也加载
        try {
            ckks.getSecretKey().set_K(JsonUtil.GetSKFromJson(basePath + "\\pphsk.json"));
        } catch (Exception e) {
            System.out.println("提示: 未找到独立 pphsk.json，使用默认密钥");
        }
        return ckks;
    }

    /**
     * ⚠️ 关键方法：将本次查询生成的 TokenNode 注册到 EncGraph 的静态 Map 中
     * Hermes 内部调用 SecureOrienting 等方法时，会去 EncGraph.nodeSet 里查坐标
     */
    private static void rebuildEncGraphMapping(ArrayList<TokenNode> tokenList) {
        EncGraph.nodeSet.clear(); // 清空旧数据，防止干扰
        for (TokenNode tn : tokenList) {
            if (tn.xEnc != null && tn.yEnc != null) {
                EncNode encNode = new EncNode(tn.xEnc, tn.yEnc, tn);
                EncGraph.nodeSet.put(tn, encNode);
            }
        }
    }

    private static ArrayList<Long> generateRandomPath(ConcurrentHashMap<Integer, node> apl, int waypointCount) {
        ArrayList<Long> path = new ArrayList<>();
        Random random = new Random();
        List<Long> availableNodes = apl.values().stream().map(n -> n.id).collect(Collectors.toList());
        
        // 起点
        path.add(availableNodes.get(random.nextInt(availableNodes.size())));
        
        // 途径点
        for (int i = 0; i < waypointCount; i++) {
            long node;
            do {
                node = availableNodes.get(random.nextInt(availableNodes.size()));
            } while (path.contains(node));
            path.add(node);
        }
        
        // 终点
        long endNode;
        do {
            endNode = availableNodes.get(random.nextInt(availableNodes.size()));
        } while (path.contains(endNode));
        path.add(endNode);
        
        return path;
    }
}