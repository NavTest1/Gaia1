package NSP;

import Class.TokenNode;
import ckks.Ciphertext;
import it.unisa.dia.gas.jpbc.Element;
import lombok.Getter;

@Getter
public class EncNode {
    private final Ciphertext ex;
    private final Ciphertext ey;
    private final TokenNode id;

    public EncNode(Ciphertext ex, Ciphertext ey, TokenNode _id) {

//        this.esd = esd;
        this.id = _id;
        this.ex = ex;
        this.ey = ey;
    }
}
