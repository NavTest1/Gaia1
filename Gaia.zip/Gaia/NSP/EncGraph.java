package NSP;

import Omega.PK;
import Class.TokenNode;
import util.JsonUtil;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import it.unisa.dia.gas.jpbc.Element;
import lombok.Setter;
import lombok.SneakyThrows;
import org.apache.commons.codec.binary.Base64;

import java.io.File;
import java.util.concurrent.ConcurrentHashMap;

@Setter
public class EncGraph {
    static public ConcurrentHashMap<TokenNode, EncNode> nodeSet;

    static {
        nodeSet = new ConcurrentHashMap<>();
    }


//    @SneakyThrows
//    public static void WriteEncGraph(String fileName) {
//        ObjectMapper mapper = new ObjectMapper();
//        ObjectNode root = mapper.createObjectNode();
//        nodeSet.forEachEntry(nodeSet.mappingCount() << 1, ele -> {
//            ObjectNode node = mapper.createObjectNode();
//            String h1str = ele.getKey().H1str;
//            String f4str = ele.getKey().F4str;
//            String t2str = ele.getKey().T2str;
//            String id = String.valueOf(ele.getKey().getId());
//            String keyStr = t2str + "," + f4str + "," + h1str + "," + id;
//            String ex = Base64.encodeBase64String(ele.getValue().getEx().toBytes());
//            String ey = Base64.encodeBase64String(ele.getValue().getEy().toBytes());
//            node.put("x", ex);
//            node.put("y", ey);
//            root.set(keyStr, node);
//        });
//        mapper.writeValue(new File(fileName), root);
//    }

//    @SneakyThrows
//    public static ConcurrentHashMap<TokenNode, EncNode> getNodeSetFromJson(String fileName, PK pk) {
//        ConcurrentHashMap<TokenNode, EncNode> res = new ConcurrentHashMap<>();
//        String jsonFile = JsonUtil.readJsonFile(fileName);
//        ObjectMapper mapper = new ObjectMapper();
//        JsonNode rootNode = mapper.readTree(jsonFile);
//        rootNode.fields().forEachRemaining(e -> {
//            String key = e.getKey();
//            String[] tokennode = key.split(",");
//            String t2 = tokennode[0];
//            String f4 = tokennode[1];
//            String h1 = tokennode[2];
//            String id = tokennode[3];
//            TokenNode node = new TokenNode(t2, f4, h1, Long.parseLong(id));
//            JsonNode x = e.getValue().get("x");
//            JsonNode y = e.getValue().get("y");
//            byte[] valx = Base64.decodeBase64(x.asText());
//            byte[] valy = Base64.decodeBase64(y.asText());
//            Element ex = pk.get_G().newElementFromBytes(valx);
//
//            Element ey = pk.get_G().newElementFromBytes(valy);
//            EncNode node1 = new EncNode(ex, ey, node);
//
//            res.put(node, node1);
//        });
//        return res;
//    }

    
public static void checkNodeSet() {
    if (nodeSet == null) {
        System.out.println("nodeSet未初始化");
    } else if (nodeSet.isEmpty()) {
        System.out.println("nodeSet为空");
    } else {
        System.out.println("nodeSet内容如下：");
        for (var entry : nodeSet.entrySet()) {
            System.out.println("TokenNode: " + entry.getKey() + ", EncNode: " + entry.getValue());
        }
    }
}
}
