package NSP;

import Class.TokenNode;
import lombok.AllArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Setter
@AllArgsConstructor
public class StopSet implements Cloneable {
    public ArrayList<TokenNode> list = new ArrayList<>();

    public StopSet() {
        list = new ArrayList<>();
    }

    public StopSet(List<TokenNode> nodes) {
        this.list = new ArrayList<>(nodes);
    }

    // 🔥 修复：基于ID移除而非对象引用
    public boolean remove(TokenNode node) {
        return list.removeIf(n -> n.getId() == node.getId());
    }

    public TokenNode get(int index) {
        return list.get(index);
    }

    public int size() {
        return list.size();
    }

    public void add(TokenNode node) {
        list.add(node);
    }

    public void clear() {
        list.clear();
    }

    public boolean isEmpty() {
        return list.isEmpty();
    }

    public void show() {
        System.out.println("StopSet列表内容如下：");
        for (TokenNode node : list) {
            System.out.println(node);
        }
    }

    @Override
    public StopSet clone() {
        try {
            StopSet cloned = (StopSet) super.clone();
            cloned.list = new ArrayList<>(this.list);
            return cloned;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError(e);
        }
    }
}