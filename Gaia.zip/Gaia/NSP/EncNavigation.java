package NSP;

import Omega.PK;
import Class.TokenNode;
import lombok.SneakyThrows;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;

public interface EncNavigation {
    @SneakyThrows
    void SecureNavigation(ArrayList<TokenNode> res, TokenNode Is, TokenNode Id, TokenNode[] list/*, ArrayList<TokenNode> ALL*/)throws NoSuchAlgorithmException, IOException;
}
