package NSP;

import Omega.NewOmega;
import Omega.PK;
import ckks.CKKSHelper;
import ckks.Ciphertext;
import ckks.PublicKeys;
import it.unisa.dia.gas.jpbc.Element;

import java.io.IOException;

public class EncVec {
    private final Ciphertext[] Evec = new Ciphertext[2];
    private static PublicKeys pk;
    //private static NewOmega omega;
    private static CKKSHelper ckks;
    //node序号
//    private PK pk;
    static {
//         omega = new NewOmega();
//        pk = omega.getPK("D:\\Gaia\\src\\main\\resources\\PK.json");
//        omega.SetByPk(pk);
        ckks = new CKKSHelper(2, 4, 10, 20);
        try {
            ckks.loadContext("D:\\Gaia\\src\\main\\resources");
            ckks.loadPublicKeys("D:\\Gaia\\src\\main\\resources");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    EncVec(EncNode s, EncNode d) {//ENC向量SD=
        long evs = System.currentTimeMillis();

/*        System.out.println("d的ex："+d.getEx().getClass().toString());
        System.out.println("d的ey："+d.getEy().getClass().toString());
        System.out.println("s的ex："+d.getEx().getClass().toString());
        System.out.println("s的ey："+s.getEy().getClass().toString());*/

        Evec[0] = ckks.subtract(d.getEx(),s.getEx());
        Evec[1] = ckks.subtract(d.getEy(),s.getEy());
        //Evec[0] = omega.sub(d.getEx(), s.getEx());// s.getEx().div(d.getEx().duplicate()).mul(pk.getH().powZn(pk.getE().getZr().newRandomElement()));
        //Evec[1] = omega.sub(d.getEy(), s.getEy());// s.getEy().div(d.getEy().duplicate()).mul(pk.getH().powZn(pk.getE().getZr().newRandomElement()));

        //System.out.println("sub执行完毕！！！！");
        long eve = System.currentTimeMillis();

    }

    public EncVec(Ciphertext s, Ciphertext d) {
        long evs = System.currentTimeMillis();
        Evec[0] = s;
        Evec[1] = d;
        long eve = System.currentTimeMillis();
        Times.alltimes+=(eve-evs);
        Times.time234 +=(eve-evs);
    }

    public Ciphertext[] getEvec() {
        return Evec;
    }
}
