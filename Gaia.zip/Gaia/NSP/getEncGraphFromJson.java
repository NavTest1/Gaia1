package NSP;

import Algorithm.Floyd_Warshall;
import Omega.NewOmega;
import Omega.PK;
import Omega.SK;
import User.*;
import Class.*;

import ckks.CKKSHelper;
import ckks.Ciphertext;
import ckks.Context;
import ckks.PublicKeys;
import edu.biu.scapi.exceptions.FactoriesException;
import it.unisa.dia.gas.jpbc.Element;
import lombok.SneakyThrows;
import util.JsonUtil;
import util.OsmtoJson;

import javax.crypto.IllegalBlockSizeException;
import java.io.IOException;
import java.math.BigInteger;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;

import static util.JsonUtil.*;

public class getEncGraphFromJson {
    private final DX dx;
    private final Arrlist arrlist;
    private final PublicKeys pk;
    private final PRF_PRP_Hash pph;
    private final int LEN;
    private final CKKSHelper ckks;
    private final Context context;


    public getEncGraphFromJson(ArrayList<TokenNode> _token, DX _dx, Arrlist _arr, PRF_PRP_Hash _pph, PublicKeys _pk,Context context) throws IOException {

        dx = _dx;
        arrlist = _arr;
        pk = _pk;
        pph = _pph;
        LEN = dx.getLen();
        this.context = context;
        ckks = new CKKSHelper(2, 4, 10, 20);
        ckks.SetContext(this.context);
        ckks.SetPublicKeys(this.pk);
        //建立结点
        _token.forEach(tokenNode -> {
            String f4 = tokenNode.F4str;
            //f4 = f4(suanid)
            String t2 = tokenNode.T2str;
            //t2 = t2(suanid)
            int index = dx.getIndex(t2, f4);
            //index = 该节点的索引
            BigInteger kv1 = dx.getKv();//每次getindex后都会获取一次k
            //kv1 = 节点的kv
            Arrnode tmpvar = arrlist.data[index].data.get((long) 0);
            //tmpvar:
            //     first = ex||ey 异或 H2（n1.kv||n1.rv）
            //     second = n1.rv
            BigInteger rv1 = tmpvar.getSecond();
            //rv1 = n1.rv
            byte[] h2msg = ByteTools.merge(kv1.toByteArray(), rv1.toByteArray()), h2tag = new byte[32];
            pph.use_H2(h2msg, h2tag);
            //h2tag = H2(n1.kv||n2.rv)
            byte[] tmpB = ByteTools.XOR(tmpvar.getFirst(), h2tag);
            //tmpB = ex||ey
            byte[] bex = new byte[tmpB.length / 2], bey = new byte[tmpB.length / 2];
            System.arraycopy(tmpB, 0, bex, 0, tmpB.length / 2);
            System.arraycopy(tmpB, tmpB.length / 2, bey, 0, tmpB.length / 2);
            Ciphertext ex = new Ciphertext(context);
            Ciphertext ey = new Ciphertext(context);

            ex.deserialize(ByteTools.bytesToLongArray(bex));
            ey.deserialize(ByteTools.bytesToLongArray(bey));

            EncNode node = new EncNode(ex, ey, tokenNode);
            EncGraph.nodeSet.put(tokenNode, node);
        });

    }

    @SneakyThrows
    public static void main(String[] args) throws IllegalBlockSizeException, FactoriesException, NoSuchAlgorithmException, InvalidKeyException {

    }



}
