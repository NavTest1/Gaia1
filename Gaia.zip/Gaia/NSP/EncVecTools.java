package NSP;

import Omega.NewOmega;
import Omega.PK;
import ckks.*;
import it.unisa.dia.gas.jpbc.Element;

import java.io.IOException;

import Class.TokenNode;

public class EncVecTools {
    private static PublicKeys pk;
    //private static final NewOmega omega;
    private static Context context;
    public static CKKSHelper ckks = null;

   @Deprecated
    public EncVecTools(Context mcontext, PublicKeys publicKeys) throws IOException {
        init(mcontext, publicKeys); // 内部调用静态初始化方法
    }

    // 2. 新增静态初始化方法：专门初始化静态成员
    public static void init(Context mcontext, PublicKeys publicKeys) throws IOException {
        if (ckks == null) { // 避免重复初始化
            context = mcontext;
            pk = publicKeys;
            ckks = new CKKSHelper(2, 4, 10, 20);
            ckks.SetContext(context);
            ckks.SetPublicKeys(pk);
            ckks.loadSecretKey("D:\\Gaia\\src\\main\\resources");
            
            if (publicKeys == null || publicKeys.getA() == null || publicKeys.getB() == null) {
                throw new RuntimeException("PublicKeys 初始化失败：a 或 b 公钥分量为 null！");
            }
            // 2. 验证 Encryptor 是否有效（依赖 publicKeys 初始化）
            if (ckks.getEncryptor() == null) {
                throw new RuntimeException("Encryptor 初始化失败，可能与 PublicKeys 关联异常！");
            }
        // 3. 额外验证：公钥多项式的系数是否非空（以 a 为例）
            Polynomial pubA = publicKeys.getA();
            if (pubA.getCrt() == null || pubA.getCrt().length == 0) {
                throw new RuntimeException("公钥多项式 a 的系数为空，公钥无效！");
            }

        }
    }


    public static EncVec getOV(EncNode s, EncNode d){

//        Element sy = s.getEy().getImmutable();
//        Element sx = s.getEx().getImmutable();
//        Element dx = d.getEx().getImmutable();
//        Element dy = d.getEy().getImmutable();
//        return new EncVec(omega.sub(dy,sy), omega.sub(sx,dx));
        Ciphertext sy = s.getEy();
        Ciphertext sx = s.getEx();
        Ciphertext dx = d.getEx();
        Ciphertext dy = d.getEy();
        return new EncVec(ckks.subtract(dy,sy),ckks.subtract(sx,dx));
    }
    public static EncVec getVO(EncNode s,EncNode d){

//        Element sy = s.getEy().getImmutable();
//        Element sx = s.getEx().getImmutable();
//        Element dx = d.getEx().getImmutable();
//        Element dy = d.getEy().getImmutable();
//        return new EncVec(omega.sub(sy,dy), omega.sub(dx,sx));
        Ciphertext sy = s.getEy();
        Ciphertext sx = s.getEx();
        Ciphertext dx = d.getEx();
        Ciphertext dy = d.getEy();
        return new EncVec(ckks.subtract(sy,dy),ckks.subtract(dx,sx));
    }
    public static Ciphertext ENCS_SD_SP(EncVec esd, EncVec esp){
//        Element first = pk.getE().pairing(esd.getEvec()[0], esp.getEvec()[0]).getImmutable();
//        Element second = pk.getE().pairing(esd.getEvec()[1], esp.getEvec()[1]).getImmutable();
//
//        return omega.add_G1(first,second).getImmutable();
        Ciphertext first = ckks.multiply(esd.getEvec()[0], esp.getEvec()[0] );
        //Double first_re = ckks.decrypt(first);

        Ciphertext second = ckks.multiply(esd.getEvec()[1], esp.getEvec()[1] );

        // ****** 调试：解密看明文 ******
    double val1 = ckks.decrypt(first);
    double val2 = ckks.decrypt(second);
    System.out.printf("ENCS_SD_SP 明文 first=%.2f  second=%.2f%n", val1, val2);
        //Double second_re = ckks.decrypt(second);
        //Ciphertext first_new = ckks.encrypt(first_re);
        //Ciphertext second_new = ckks.encrypt(second_re);
        return ckks.add(first,second);

    }

    public static Ciphertext projection(TokenNode a, TokenNode b, TokenNode s, TokenNode d) {
        EncNode encA = new EncNode(a.xEnc, a.yEnc,a);
        EncNode encB = new EncNode(b.xEnc, b.yEnc,b);
        EncVec vecAB = EncVecTools.getVO(encA, encB);
        //EncVec vecAB = getVO(a, b);
        EncNode encS = new EncNode(s.xEnc, s.yEnc,s);
        EncNode encD = new EncNode(d.xEnc, d.yEnc,d);
        EncVec vecSD = EncVecTools.getVO(encA, encB);
        //EncVec vecSD = getVO(s, d);
        // 投影公式：proj = ((b,a) * vecAB - (b,s) * vecSD) / (a,s)
        Ciphertext projEnc = ckks.multiply(vecAB.getEvec()[0], ckks.subtract(b.xEnc, s.xEnc)); // 举例，具体公式需调整
        Ciphertext projSD = ckks.multiply(vecSD.getEvec()[1], ckks.subtract(b.yEnc, s.yEnc)); // 举例
        return ckks.add(projEnc, projSD); // 返回加密后的投影
    }

    public static Ciphertext colinear(TokenNode a, TokenNode b, TokenNode c) {
        Ciphertext ax = a.xEnc, ay = a.yEnc;
        Ciphertext bx = b.xEnc, by = b.yEnc;
        Ciphertext cx = c.xEnc, cy = c.yEnc;

        Ciphertext bx_ax = ckks.subtract(bx, ax);
        Ciphertext cx_ax = ckks.subtract(cx, ax);
        Ciphertext by_ay = ckks.subtract(by, ay);
        Ciphertext cy_ay = ckks.subtract(cy, ay);

        Ciphertext term1 = ckks.multiply(bx_ax, cy_ay);
        Ciphertext term2 = ckks.multiply(cx_ax, by_ay);
        return ckks.add(term1, term2);
    }
    
    public static Ciphertext cross(TokenNode a, TokenNode b, TokenNode c) {
        // 1. 取出加密坐标
        Ciphertext ax = a.xEnc, ay = a.yEnc;
        Ciphertext bx = b.xEnc, by = b.yEnc;
        Ciphertext cx = c.xEnc, cy = c.yEnc;

        // 2. 计算两个向量
        Ciphertext bx_ax = ckks.subtract(bx, ax);   // bx - ax
        Ciphertext cy_ay = ckks.subtract(cy, ay);   // cy - ay
        Ciphertext by_ay = ckks.subtract(by, ay);   // by - ay
        Ciphertext cx_ax = ckks.subtract(cx, ax);   // cx - ax

        // 3. 叉积公式： (bx-ax)*(cy-ay) - (by-ay)*(cx-ax)
        Ciphertext term1 = ckks.multiply(bx_ax, cy_ay);
        Ciphertext term2 = ckks.multiply(by_ay, cx_ax);
        return ckks.subtract(term1, term2);
    }



}
