package NSP.EncNavigationImpl;

import NSP.EncNavigation;
import NSP.EncNavigationTools;
import Omega.PK;
import Class.TokenNode;
import Proxy.CT;
import ckks.CKKSHelper;
import ckks.Context;
import ckks.PublicKeys;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static NSP.EncNavigationTools.SetNavigation;

public class AtNEncNavigation implements EncNavigation {
    private PublicKeys pk;
    private CT ct;
    private Context context;
    //private NewOmega omega;
    private CKKSHelper ckks;
    public AtNEncNavigation(PublicKeys pk,Context mcontext) throws IOException {
        this.pk = pk;
        this.context = mcontext;
        ct = new CT(pk,context);
//        omega = new NewOmega();
//        omega.SetByPk(pk);
        ckks = new CKKSHelper(2, 4, 10, 20);
        ckks.SetContext(context);
        ckks.SetPublicKeys(this.pk);
        SetNavigation(pk,ct,context);
    }
    @Override
    public void SecureNavigation(ArrayList<TokenNode> res, TokenNode Is, TokenNode Id,  TokenNode[] list) {

        ArrayList<TokenNode>tokenNodeArrayList=new ArrayList<>(List.of(list));
        TokenNode Ics=Is;
        while (!tokenNodeArrayList.isEmpty()){
            Ics= EncNavigationTools.getAlwaysToNearestPoint(Ics,Id,tokenNodeArrayList);
            res.add(Ics);
            tokenNodeArrayList.remove(Ics);
        }

    }
}
