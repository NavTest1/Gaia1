package NSP.EncNavigationImpl;//package com.Hermes.NSP.EncNavigationImpl;

import NSP.EncGraph;
import NSP.EncNavigation;
import NSP.StopSet;
import Omega.NewOmega;
import Omega.PK;
import Proxy.CT;
import User.QueryTokenGen;
import Class.TokenNode;
import util.JsonUtil;
import lombok.SneakyThrows;

import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

import static NSP.EncNavigationTools.*;

public class ParallelHermesEncNavigation implements EncNavigation {

    public int k;
    public AtomicInteger aim;
    public AtomicInteger index;
    public int last;
    public TokenNode[] originPoints;
    public ExecutorService executorService = Executors.newFixedThreadPool(18);
    public SearchElement searchElement = new SearchElement();

    @SneakyThrows
    @Override
    public void SecureNavigation(ArrayList<TokenNode> res, TokenNode Is, TokenNode Id,  TokenNode[] list) {
        StopSet[] grouping = SecureGrouping(Is, Id, new ArrayList<>(List.of(list)));
        StopSet PLow = grouping[0];
        StopSet PMid = grouping[1];
        StopSet PHigh = grouping[2];

        TokenNode[] bridging = SecureBridging(Is, Id, PMid, PHigh);
        TokenNode Ib1 = bridging[0];
        TokenNode Ib2 = bridging[1];
        if (PLow.list.isEmpty() && PMid.list.isEmpty() && PHigh.list.isEmpty()) {
            System.out.println("To the end straightly");
            res.add(Id);
            System.out.println("res.size() = " + res.size());
            return;
        }
        TokenNode ICs = Is;
        if (PLow.list.isEmpty()) {
            if (!PMid.list.isEmpty()) {
                TokenNode svnh = SecureVerticallyNearestHop(ICs, Ib2, PMid);
                if (!svnh.equals(Ib2)) {
                    if (PMid.list.size() > 1) {
                        res.add(svnh);
                        System.out.println("res.size() = " + res.size());
                        ICs = svnh;
                        PMid.list.remove(svnh);
                        System.out.println("PMid.list.size() = " + PMid.list.size());
                        TokenNode[] next = new TokenNode[PMid.list.size()];
                        for (int i = 0; i < PMid.list.size(); i++) {
                            next[i] = PMid.list.get(i);
                        }
                        System.out.println("list.size() = " + PMid.list.size());
                        try {
                            SecureNavigation(res, ICs, Ib2,  next);
                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        }
                    } else {
                        res.add(svnh);
                        System.out.println("res.size() = " + res.size());
                        ICs = svnh;
                        PMid.list.remove(svnh);
                        System.out.println("PMid.list.size() = " + PMid.list.size());
                    }
                }
            }
            if (!PHigh.list.isEmpty()) {
                TokenNode pull = null;
                StopSet PRightSemi = new StopSet();
                StopSet PLeftSemi = new StopSet();
                StopSet PLeft = new StopSet(), PRight = new StopSet();
                for (TokenNode node : PHigh.list) {
                    if (SecureOrienting(ICs, Id, node) == LEFT) {
                        PLeft.list.add(node);
                    } else {
                        PRight.list.add(node);
                    }
                }
                if (SecureOrienting(Is, Id, ICs) == LEFT) {
                    if (PLeft.list.size() == 1) {
                        pull = PLeft.list.get(0);
                    } else if (PLeft.list.size() > 1) {
                        StopSet[] sets = SecureSplitting(ICs, Ib2, PLeft);
                        PLeftSemi = sets[0];
                        PRightSemi = sets[1];
                        pull = SecurePulling(Is, ICs, Ib1, Ib2, PLeftSemi, PRightSemi, LEFT);
                    } else {
                        StopSet[] sets = SecureSplitting(ICs, Ib2, PRight);
                        PLeftSemi = sets[0];
                        PRightSemi = sets[1];
                        pull = SecurePulling(Is, ICs, Ib1, Ib2, PLeftSemi, PRightSemi, LEFT);
                    }
                } else {
                    if (PRight.list.size() == 1) {
                        pull = PRight.list.get(0);
                    } else if (PRight.list.size() > 1) {
                        StopSet[] sets = SecureSplitting(ICs, Ib2, PRight);
                        PLeftSemi = sets[0];
                        PRightSemi = sets[1];
                        pull = SecurePulling(Is, ICs, Ib1, Ib2, PLeftSemi, PRightSemi, RIGHT);
                    } else {
                        StopSet[] sets = SecureSplitting(ICs, Ib2, PLeft);
                        PLeftSemi = sets[0];
                        PRightSemi = sets[1];
                        pull = SecurePulling(Is, ICs, Ib1, Ib2, PLeftSemi, PRightSemi, RIGHT);
                    }
                }
                if (PHigh.list.size() > 1) {
                    res.add(pull);
                    System.out.println("res.size() = " + res.size());
                    PHigh.list.remove(pull);
                    int io = aim.decrementAndGet();
                    System.out.println("io = " + io);
                    System.out.println("PHigh.list.size() = " + PHigh.list.size());
                    ICs = pull;
                    TokenNode[] next = new TokenNode[PHigh.list.size()];
                    for (int i = 0; i < PHigh.list.size(); i++) {
                        next[i] = PHigh.list.get(i);
                    }
                    try {
                        SecureNavigation(res, ICs, Ib2,  next);
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                } else {
                    res.add(pull);
                    System.out.println("res.size() = " + res.size());
                    PHigh.list.remove(pull);
                    int io = aim.decrementAndGet();
                    System.out.println("io = " + io);
                    System.out.println("PHigh.list.size() = " + PHigh.list.size());
                }
            }

        }
        if (PMid.list.isEmpty() && PHigh.list.isEmpty()) {
            if (!PLow.list.isEmpty()) {
                TokenNode scan = null;
                StopSet PRightSemi = new StopSet();
                StopSet PLeftSemi = new StopSet();
                StopSet PLeft = new StopSet(), PRight = new StopSet();
                for (TokenNode node : PLow.list) {
                    if (SecureOrienting(Is, Id, node) == LEFT) {
                        PLeft.list.add(node);
                    } else {
                        PRight.list.add(node);
                    }
                }
                if (SecureOrienting(Is, Id, Ib1) == LEFT) {
                    if (PRight.list.size() == 1) {
                        scan = PRight.list.get(0);
                    } else if (PRight.list.size() > 1) {
                        StopSet[] sets = SecureSplitting(ICs, Ib1, PRight);
                        PLeftSemi = sets[0];
                        PRightSemi = sets[1];
                        scan = SecureScanning(ICs, Id, Ib1, PLeftSemi, PRightSemi, LEFT);
                    } else {
                        StopSet[] sets = SecureSplitting(ICs, Ib1, PLeft);
                        PLeftSemi = sets[0];
                        PRightSemi = sets[1];
                        scan = SecureScanning(ICs, Id, Ib1, PLeftSemi, PRightSemi, LEFT);
                    }
                } else {
                    if (PLeft.list.size() == 1) {
                        scan = PLeft.list.get(0);
                    } else if (PLeft.list.size() > 1) {
                        StopSet[] sets = SecureSplitting(ICs, Ib1, PLeft);
                        PLeftSemi = sets[0];
                        PRightSemi = sets[1];
                        scan = SecureScanning(ICs, Id, Ib1, PLeftSemi, PRightSemi, RIGHT);

                    } else {
                        StopSet[] sets = SecureSplitting(ICs, Ib1, PRight);
                        PLeftSemi = sets[0];
                        PRightSemi = sets[1];
                        scan = SecureScanning(ICs, Id, Ib1, PLeftSemi, PRightSemi, RIGHT);
                    }
                }


                if (PLow.list.size() > 1) {
                    res.add(scan);
                    System.out.println("res.size() = " + res.size());
                    ICs = scan;
                    PLow.list.remove(scan);
                    System.out.println("PLow.list.size() = " + PLow.list.size());
                    TokenNode[] next = new TokenNode[PLow.list.size()];
                    for (int i = 0; i < PLow.list.size(); i++) {
                        next[i] = PLow.list.get(i);
                    }
                    SecureNavigation(res, ICs, Ib1,next);
                } else {
                    res.add(scan);
                    System.out.println("res.size() = " + res.size());
                    ICs = scan;
                    PLow.list.remove(scan);
                    System.out.println("PLow.list.size() = " + PLow.list.size());
                }
            }
        }
        if (!PLow.list.isEmpty() && (!PMid.list.isEmpty() || !PHigh.list.isEmpty())) {
            current(Is, Id, Ib1, res, PLow, PMid, PHigh);
            for (int i = 0; i < last; i++) {
                if (searchElement.list.contains(originPoints[i])) {
                    res.add(originPoints[i]);
                }
            }
            for (int i = 0; i < last; i++) {
                if (searchElement.res.contains(originPoints[i])) {
                    res.add(originPoints[i]);
                }
            }
            for (TokenNode node : searchElement.list) {
                if (!res.contains(node)) {
                    res.add(node);
                }
            }
            for (TokenNode node : searchElement.res) {
                if (!res.contains(node)) {
                    res.add(node);
                }
            }
        }
    }

    public void current(TokenNode Is, TokenNode Id, TokenNode Ib1,
                        List<TokenNode> res, StopSet PLow, StopSet PMid, StopSet PHigh) {
        boolean tag = true;
        boolean[] isfinished = new boolean[2];
        while (tag) {
            tag = true;
            executorService.execute(() -> {
                isfinished[0] = false;
                searchElement.Low(PLow, Is, Id, Ib1);
                isfinished[0] = true;
                isfinished[1] = true;
            });
            executorService.execute(() -> {
                isfinished[1] = false;
                searchElement.HighMid(PMid, PHigh, Ib1, Id);
                isfinished[1] = true;
                isfinished[0] = true;
            });
            while (searchElement.resultAim.get() != 0) ;
            tag = false;
        }
        boolean end_tag;
        while (!isfinished[0] || !isfinished[1]) {
            System.out.print("isfinished[0] = " + isfinished[0]);
            System.out.println("    isfinished[1] = " + isfinished[1]);
        }
    }

    class SearchElement {
        public boolean[] isFinished = new boolean[2];
        public AtomicInteger resultAim = new AtomicInteger(0);
        public CopyOnWriteArrayList<TokenNode> list = new CopyOnWriteArrayList<>();
        public CopyOnWriteArrayList<TokenNode> res = new CopyOnWriteArrayList<>();
        public TokenNode[] arr = new TokenNode[k];
        public TokenNode[] nextList = new TokenNode[2];

        public SearchElement() {
        }

        @SneakyThrows
        void Low(StopSet PLow, TokenNode Is, TokenNode Id, TokenNode Ib1) {
            TokenNode ICs = Is;
            TokenNode scan = null;
            StopSet PRightSemi = new StopSet();
            StopSet PLeftSemi = new StopSet();
            StopSet PLeft = new StopSet(), PRight = new StopSet();
            for (TokenNode node : PLow.list) {
                if (SecureOrienting(Is, Id, node) == LEFT) {
                    PLeft.list.add(node);
                } else {
                    PRight.list.add(node);
                }
            }
            if (SecureOrienting(Is, Id, Ib1) == LEFT) {
                if (PRight.list.size() == 1) {
                    scan = PRight.list.get(0);
                } else if (PRight.list.size() > 1) {
                    StopSet[] sets = SecureSplitting(ICs, Ib1, PRight);
                    PLeftSemi = sets[0];
                    PRightSemi = sets[1];
                    scan = SecureScanning(ICs, Id, Ib1, PLeftSemi, PRightSemi, LEFT);
                } else {
                    StopSet[] sets = SecureSplitting(ICs, Ib1, PLeft);
                    PLeftSemi = sets[0];
                    PRightSemi = sets[1];
                    scan = SecureScanning(ICs, Id, Ib1, PLeftSemi, PRightSemi, LEFT);
                }
            } else {
                if (PLeft.list.size() == 1) {
                    scan = PLeft.list.get(0);
                } else if (PLeft.list.size() > 1) {
                    StopSet[] sets = SecureSplitting(ICs, Ib1, PLeft);
                    PLeftSemi = sets[0];
                    PRightSemi = sets[1];
                    scan = SecureScanning(ICs, Id, Ib1, PLeftSemi, PRightSemi, RIGHT);

                } else {
                    StopSet[] sets = SecureSplitting(ICs, Ib1, PRight);
                    PLeftSemi = sets[0];
                    PRightSemi = sets[1];
                    scan = SecureScanning(ICs, Id, Ib1, PLeftSemi, PRightSemi, RIGHT);
                }
            }

            //TODO:需要考虑是否应该在服务器端求和最短路径

            if (PLow.list.size() > 1) {
                list.add(scan);
                int io = aim.decrementAndGet();
                System.out.println("io = " + io);
                System.out.println("res.size() = " + res.size());
                ICs = scan;
                PLow.list.remove(scan);
                System.out.println("PLow.list.size() = " + PLow.list.size());
                TokenNode[] next = new TokenNode[PLow.list.size()];
                for (int i = 0; i < PLow.list.size(); i++) {
                    next[i] = PLow.list.get(i);
                }
//                SecureNavigation(res, ICs, Ib1, pk, next);
                try {
                    ParallelSecureSplit(ICs, Ib1, next, list);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            } else {
                list.add(scan);
                if (aim != null) {
                    int io = aim.decrementAndGet();
                    System.out.println("io = " + io);
                }

                System.out.println("res.size() = " + list.size());
                ICs = scan;
                nextList[0] = ICs;
                PLow.list.remove(scan);
                System.out.println("PLow.list.size() = " + PLow.list.size());
            }
        }

        @SneakyThrows
        void HighMid(StopSet PMid, StopSet PHigh, TokenNode Is, TokenNode Id) {
            resultAim.set(1);
            TokenNode[] bridging = SecureBridging(Is, Id, PMid, PHigh);
            TokenNode Ib1 = bridging[0];
            TokenNode Ib2 = bridging[1];
            TokenNode ICs = Is;
            if (!PMid.list.isEmpty()) {
                System.out.println("In Mid");
                long SVNHS = System.currentTimeMillis();
                TokenNode svnh = SecureVerticallyNearestHop(ICs, Ib2, PMid);
                long SVNHE = System.currentTimeMillis();
                System.out.println("(SVNHE-SVNHS) = " + (SVNHE - SVNHS));
                if (!svnh.equals(Ib2)) {
                    if (PMid.list.size() > 1) {
                        res.add(svnh);
                        int io = aim.decrementAndGet();
                        System.out.println("io = " + io);
                        System.out.println("res.size() = " + res.size());
                        ICs = svnh;
                        PMid.list.remove(svnh);
                        nextList[1] = svnh;
                        System.out.println("PMid.list.size() = " + PMid.list.size());
                        TokenNode[] next = new TokenNode[PMid.list.size()];
                        for (int i = 0; i < PMid.list.size(); i++) {
                            next[i] = PMid.list.get(i);
                        }
                        System.out.println("list.size() = " + PMid.list.size());
//                        SecureNavigation(res, ICs, Ib2, pk, next);
                        ParallelSecureSplit(ICs, Id, next, res);
                    } else {
                        res.add(svnh);
                        if (aim != null) {
                            int io = aim.decrementAndGet();
                            System.out.println("io = " + io);
                        }
                        System.out.println("res.size() = " + res.size());
                        ICs = svnh;
                        PMid.list.remove(svnh);
                        System.out.println("PMid.list.size() = " + PMid.list.size());
                    }
                }
            }
            if (!PHigh.list.isEmpty()) {
                System.out.println("In High");
                TokenNode pull = null;
                StopSet PRightSemi = new StopSet();
                StopSet PLeftSemi = new StopSet();
                StopSet PLeft = new StopSet(), PRight = new StopSet();
                for (TokenNode node : PHigh.list) {
                    if (SecureOrienting(ICs, Id, node) == LEFT) {
                        PLeft.list.add(node);
                    } else {
                        PRight.list.add(node);
                    }
                }
                if (SecureOrienting(Is, Id, ICs) == LEFT) {
                    if (PLeft.list.size() == 1) {
                        pull = PLeft.list.get(0);
                    } else if (PLeft.list.size() > 1) {
                        StopSet[] sets = SecureSplitting(ICs, Ib2, PLeft);
                        PLeftSemi = sets[0];
                        PRightSemi = sets[1];
                        pull = SecurePulling(Is, ICs, Ib1, Ib2, PLeftSemi, PRightSemi, LEFT);
                    } else {
                        StopSet[] sets = SecureSplitting(ICs, Ib2, PRight);
                        PLeftSemi = sets[0];
                        PRightSemi = sets[1];
                        pull = SecurePulling(Is, ICs, Ib1, Ib2, PLeftSemi, PRightSemi, LEFT);
                    }
                } else {
                    if (PRight.list.size() == 1) {
                        pull = PRight.list.get(0);
                    } else if (PRight.list.size() > 1) {
                        StopSet[] sets = SecureSplitting(ICs, Ib2, PRight);
                        PLeftSemi = sets[0];
                        PRightSemi = sets[1];
                        pull = SecurePulling(Is, ICs, Ib1, Ib2, PLeftSemi, PRightSemi, RIGHT);
                    } else {
                        StopSet[] sets = SecureSplitting(ICs, Ib2, PLeft);
                        PLeftSemi = sets[0];
                        PRightSemi = sets[1];
                        pull = SecurePulling(Is, ICs, Ib1, Ib2, PLeftSemi, PRightSemi, RIGHT);
                    }
                }
                if (PHigh.list.size() > 1) {
                    res.add(pull);
                    int io = aim.decrementAndGet();
                    System.out.println("io = " + io);
                    System.out.println("res.size() = " + res.size());
                    PHigh.list.remove(pull);
                    System.out.println("PHigh.list.size() = " + PHigh.list.size());
                    ICs = pull;
                    nextList[1] = pull;
                    TokenNode[] next = new TokenNode[PHigh.list.size()];
                    for (int i = 0; i < PHigh.list.size(); i++) {
                        next[i] = PHigh.list.get(i);
                    }
//                    SecureNavigation(res, ICs, Ib2, pk, next);
                    ParallelSecureSplit(ICs, Id, next, res);
                } else {
                    res.add(pull);
                    if (aim != null) {
                        int io = aim.decrementAndGet();
                        System.out.println("io = " + io);
                    }
                    System.out.println("res.size() = " + res.size());
                    PHigh.list.remove(pull);
                    System.out.println("PHigh.list.size() = " + PHigh.list.size());
                }
            }
        }

        @SneakyThrows
        void ParallelSecureSplit(TokenNode Is, TokenNode Id, TokenNode[] points, List<TokenNode> res) {
            System.out.println("It`s SN");
//        res.add(Is);
            System.out.println("res.size() = " + res.size());
            long SGS = System.currentTimeMillis();
            StopSet[] grouping = SecureGrouping(Is, Id, new ArrayList<>(List.of(points)));
            long SGE = System.currentTimeMillis();
            System.out.println("(SGE-SGS) = " + (SGE - SGS));
            //2.
            StopSet PLow = grouping[0];
            StopSet PMid = grouping[1];
            StopSet PHigh = grouping[2];
            long SBS = System.currentTimeMillis();
            TokenNode[] bridging = SecureBridging(Is, Id, PMid, PHigh);
            long SBE = System.currentTimeMillis();
            System.out.println("(SBE-SBS) = " + (SBE - SBS));
            TokenNode Ib1 = bridging[0];
            TokenNode Ib2 = bridging[1];

            if (PLow.list.isEmpty() && PMid.list.isEmpty() && PHigh.list.isEmpty()) {
                System.out.println("To the end straightly");
                res.add(Id);
                System.out.println("res.size() = " + res.size());
                return;
            }
            TokenNode ICs = Is;
            if (PLow.list.isEmpty() && PMid.list.isEmpty() && PHigh.list.isEmpty()) {
                System.out.println("To the end straightly");
                res.add(Id);
                System.out.println("res.size() = " + res.size());
                return;
            }
            if (PLow.list.isEmpty()) {
                if (!PMid.list.isEmpty()) {
                    TokenNode svnh = SecureVerticallyNearestHop(ICs, Ib2, PMid);
                    if (!svnh.equals(Ib2)) {
                        if (PMid.list.size() > 1) {
                            res.add(svnh);
                            System.out.println("res.size() = " + res.size());
                            int io = aim.decrementAndGet();
                            System.out.println("io = " + io);
                            ICs = svnh;
                            PMid.list.remove(svnh);
                            System.out.println("PMid.list.size() = " + PMid.list.size());
                            TokenNode[] next = new TokenNode[PMid.list.size()];
                            for (int i = 0; i < PMid.list.size(); i++) {
                                next[i] = PMid.list.get(i);
                            }
                            System.out.println("list.size() = " + PMid.list.size());
                            try {
                                ParallelSecureSplit(ICs, Id, next, res);
                            } catch (Exception e) {
                                throw new RuntimeException(e);
                            }
                        } else {
                            res.add(svnh);
                            int io = aim.decrementAndGet();
                            System.out.println("io = " + io);
                            System.out.println("res.size() = " + res.size());
                            ICs = svnh;
                            PMid.list.remove(svnh);
                            System.out.println("PMid.list.size() = " + PMid.list.size());
                        }
                    }
                }
                if (!PHigh.list.isEmpty()) {
                    TokenNode pull = null;
                    StopSet PRightSemi = new StopSet();
                    StopSet PLeftSemi = new StopSet();
                    StopSet PLeft = new StopSet(), PRight = new StopSet();
                    for (TokenNode node : PHigh.list) {
                        if (SecureOrienting(ICs, Id, node) == LEFT) {
                            PLeft.list.add(node);
                        } else {
                            PRight.list.add(node);
                        }
                    }
                    if (SecureOrienting(Is, Id, ICs) == LEFT) {
                        if (PLeft.list.size() == 1) {
                            pull = PLeft.list.get(0);
                        } else if (PLeft.list.size() > 1) {
                            StopSet[] sets = SecureSplitting(ICs, Ib2, PLeft);
                            PLeftSemi = sets[0];
                            PRightSemi = sets[1];
                            pull = SecurePulling(Is, ICs, Ib1, Ib2, PLeftSemi, PRightSemi, LEFT);
                        } else {
                            StopSet[] sets = SecureSplitting(ICs, Ib2, PRight);
                            PLeftSemi = sets[0];
                            PRightSemi = sets[1];
                            pull = SecurePulling(Is, ICs, Ib1, Ib2, PLeftSemi, PRightSemi, LEFT);
                        }
                    } else {
                        if (PRight.list.size() == 1) {
                            pull = PRight.list.get(0);
                        } else if (PRight.list.size() > 1) {
                            StopSet[] sets = SecureSplitting(ICs, Ib2, PRight);
                            PLeftSemi = sets[0];
                            PRightSemi = sets[1];
                            pull = SecurePulling(Is, ICs, Ib1, Ib2, PLeftSemi, PRightSemi, RIGHT);
                        } else {
                            StopSet[] sets = SecureSplitting(ICs, Ib2, PLeft);
                            PLeftSemi = sets[0];
                            PRightSemi = sets[1];
                            pull = SecurePulling(Is, ICs, Ib1, Ib2, PLeftSemi, PRightSemi, RIGHT);
                        }
                    }
                    if (PHigh.list.size() > 1) {
                        res.add(pull);
                        System.out.println("res.size() = " + res.size());
                        PHigh.list.remove(pull);
                        int io = aim.decrementAndGet();
                        System.out.println("io = " + io);
                        System.out.println("PHigh.list.size() = " + PHigh.list.size());
                        ICs = pull;
                        TokenNode[] next = new TokenNode[PHigh.list.size()];
                        for (int i = 0; i < PHigh.list.size(); i++) {
                            next[i] = PHigh.list.get(i);
                        }
                        try {
                            ParallelSecureSplit(ICs, Id, next, res);

                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        }
                    } else {
                        res.add(pull);
                        System.out.println("res.size() = " + res.size());
                        PHigh.list.remove(pull);
                        int io = aim.decrementAndGet();
                        System.out.println("io = " + io);
                        System.out.println("PHigh.list.size() = " + PHigh.list.size());
                    }
                }

            }
            if (PMid.list.isEmpty() && PHigh.list.isEmpty()) {
                if (!PLow.list.isEmpty()) {
                    TokenNode scan = null;
                    StopSet PRightSemi = new StopSet();
                    StopSet PLeftSemi = new StopSet();
                    StopSet PLeft = new StopSet(), PRight = new StopSet();
                    for (TokenNode node : PLow.list) {
                        if (SecureOrienting(Is, Id, node) == LEFT) {
                            PLeft.list.add(node);
                        } else {
                            PRight.list.add(node);
                        }
                    }
                    if (SecureOrienting(Is, Id, Ib1) == LEFT) {
                        if (PRight.list.size() == 1) {
                            scan = PRight.list.get(0);
                        } else if (PRight.list.size() > 1) {
                            StopSet[] sets = SecureSplitting(ICs, Ib1, PRight);
                            PLeftSemi = sets[0];
                            PRightSemi = sets[1];
                            scan = SecureScanning(ICs, Id, Ib1, PLeftSemi, PRightSemi, LEFT);
                        } else {
                            StopSet[] sets = SecureSplitting(ICs, Ib1, PLeft);
                            PLeftSemi = sets[0];
                            PRightSemi = sets[1];
                            scan = SecureScanning(ICs, Id, Ib1, PLeftSemi, PRightSemi, LEFT);
                        }
                    } else {
                        if (PLeft.list.size() == 1) {
                            scan = PLeft.list.get(0);
                        } else if (PLeft.list.size() > 1) {
                            StopSet[] sets = SecureSplitting(ICs, Ib1, PLeft);
                            PLeftSemi = sets[0];
                            PRightSemi = sets[1];
                            scan = SecureScanning(ICs, Id, Ib1, PLeftSemi, PRightSemi, RIGHT);

                        } else {
                            StopSet[] sets = SecureSplitting(ICs, Ib1, PRight);
                            PLeftSemi = sets[0];
                            PRightSemi = sets[1];
                            scan = SecureScanning(ICs, Id, Ib1, PLeftSemi, PRightSemi, RIGHT);
                        }
                    }


                    if (PLow.list.size() > 1) {
                        res.add(scan);
                        System.out.println("res.size() = " + res.size());
                        System.out.println("aim.decrementAndGet() = " + aim.decrementAndGet());
                        ICs = scan;
                        PLow.list.remove(scan);
                        System.out.println("PLow.list.size() = " + PLow.list.size());
                        TokenNode[] next = new TokenNode[PLow.list.size()];
                        for (int i = 0; i < PLow.list.size(); i++) {
                            next[i] = PLow.list.get(i);
                        }
                        ParallelSecureSplit(ICs, Id, next, res);
                    } else {
                        res.add(scan);
                        System.out.println("res.size() = " + res.size());
                        System.out.println("aim.decrementAndGet() = " + aim.decrementAndGet());
                        ICs = scan;
                        PLow.list.remove(scan);
                        System.out.println("PLow.list.size() = " + PLow.list.size());
                    }
                }
            }
            if (!PLow.list.isEmpty() && (!PMid.list.isEmpty() || !PHigh.list.isEmpty())) {
                current(Is, Id, Ib1, res, PLow, PMid, PHigh);
            }
        }

    }

    public static void main(String[] args) throws NoSuchAlgorithmException {
/*        NewOmega omega = new NewOmega();
        PK pk = omega.getPK("C:\\Users\\zhb25\\Desktop\\信安作品赛\\newHermes\\src\\main\\resources\\PK.json");
        omega.SetByPk(pk);
        EncGraph.nodeSet = EncGraph.getNodeSetFromJson("C:\\Users\\zhb25\\Desktop\\信安作品赛\\newHermes\\src\\main\\resources\\EncGraph.json", pk);
        CT ct1 = new CT();

        SetNavigation(pk,ct1);
        ParallelHermesEncNavigation navigation = new ParallelHermesEncNavigation();
        ArrayList<TokenNode> tokenNodeArrayList = JsonUtil.getTokens("C:\\Users\\zhb25\\Desktop\\信安作品赛\\newHermes\\src\\main\\resources\\token.json");

        StopSet stopSet = new StopSet();

        stopSet.list.addAll(tokenNodeArrayList);
        stopSet.list.remove(tokenNodeArrayList.get(0));
        stopSet.list.remove(tokenNodeArrayList.get(1));

        ArrayList<TokenNode> res = new ArrayList<>();
        res.add(tokenNodeArrayList.get(0));
        TokenNode[] list = new TokenNode[stopSet.list.size()];
        for (int i = 0; i < list.length; i++) {
            list[i] = stopSet.list.get(i);
        }
        navigation.aim = new AtomicInteger(list.length);
        navigation.originPoints = list.clone();
        navigation.k = list.length;
        navigation.index = new AtomicInteger(0);
        navigation.last = SecureGrouping(tokenNodeArrayList.get(0), tokenNodeArrayList.get(1), stopSet.list)[2].list.size();
        ArrayList<TokenNode> zzz = new ArrayList<>(tokenNodeArrayList);
        long sns = System.currentTimeMillis();
        navigation.SecureNavigation(res, tokenNodeArrayList.get(0), tokenNodeArrayList.get(1), pk, list);
        long sne = System.currentTimeMillis();
        System.out.println("(sne-sns) = " + (sne - sns));
        res.add(tokenNodeArrayList.get(1));
        QueryTokenGen.writeJsonToken("C:\\Users\\zhb25\\Desktop\\信安作品赛\\newHermes\\src\\main\\resources\\result.json",res);*/

    }

}
