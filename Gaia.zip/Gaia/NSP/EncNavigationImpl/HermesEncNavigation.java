package NSP.EncNavigationImpl;

import NSP.EncGraph;
import NSP.EncNavigation;
import NSP.StopSet;
import NSP.Times;
import Omega.NewOmega;
import Omega.PK;
import Proxy.CT;
import User.QueryTokenGen;
import Class.TokenNode;
import ckks.CKKSHelper;
import ckks.Ciphertext;
import ckks.Context;
import ckks.PublicKeys;
import util.JsonUtil;
import it.unisa.dia.gas.jpbc.Element;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;

import java.io.IOException;
import java.math.BigInteger;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CompletableFuture;

import static NSP.EncNavigationTools.*;

/**
 * The type Hermas enc navigation.
 */
@AllArgsConstructor
public class HermesEncNavigation implements EncNavigation {
    /**
     * The Ram.
     */
    Random ram = new Random();
    private PublicKeys pk;
    private CT ct;
    private Context context;
    //private NewOmega omega;
    private CKKSHelper ckks;
    public HermesEncNavigation(PublicKeys pk,Context mcontext) throws IOException {
        this.pk = pk;
        this.context = mcontext;
        ct = new CT(pk,context);
//        omega = new NewOmega();
//        omega.SetByPk(pk);
        ckks = new CKKSHelper(2, 4, 10, 20);
        ckks.SetContext(context);
        ckks.SetPublicKeys(this.pk);
        SetNavigation(pk,ct,context);
    }

    //Some Enumerate
    @SneakyThrows
    public static void main(String[] args) {
    /*    NewOmega omega = new NewOmega();
        PK pk = omega.getPK("D:\\Gaia\\src\\main\\resources\\PK.json");
        omega.SetByPk(pk);
        EncGraph.nodeSet = EncGraph.getNodeSetFromJson("D:\\Gaia\\src\\main\\resources\\EncGraph.json", pk);
        CT ct1 = new CT();

        SetNavigation(pk,ct1);
        EncNavigation navigation = new HermesEncNavigation(pk);
        ArrayList<TokenNode> tokenNodeArrayList = JsonUtil.getTokens("D:\\Gaia\\src\\main\\resources\\token.json");

        StopSet stopSet = new StopSet();

        stopSet.list.addAll(tokenNodeArrayList);
        stopSet.list.remove(tokenNodeArrayList.get(0));
        stopSet.list.remove(tokenNodeArrayList.get(1));

        ArrayList<TokenNode> res = new ArrayList<>();
        res.add(tokenNodeArrayList.get(0));
        TokenNode[] list = new TokenNode[stopSet.list.size()];
        for (int i = 0; i < list.length; i++) {
            list[i] = stopSet.list.get(i);
        }
        ArrayList<TokenNode> zzz = new ArrayList<>(tokenNodeArrayList);
        long sns = System.currentTimeMillis();
        navigation.SecureNavigation(res, tokenNodeArrayList.get(0), tokenNodeArrayList.get(1), pk, list);
        long sne = System.currentTimeMillis();
        System.out.println("(sne-sns) = " + (sne - sns));
        res.add(tokenNodeArrayList.get(1));
        QueryTokenGen.writeJsonToken("D:\\Gaia\\src\\main\\resources\\result.json",res);
//        ArrayList<TokenNode> res = navigation.SecureNavigation(pk, tokenNodeArrayList);
        System.out.println("res.size() = " + res.size());
        System.out.println("Times.alltimes = " + Times.alltimes);
        System.out.println("Times.time234 = " + Times.time234/36);
        System.out.println("Times.timePPT = " + Times.timePPT/16);
        System.out.println("Times.timeEnc(5) = " + Times.timeEnc/23);
        System.out.println("Times.timeMulR(6) = " + Times.timeMulR/50);
        System.out.println("Times.timeEnum(8) = " + Times.timeEnum/23);*/

    }




    @Override
    @SneakyThrows
    public void SecureNavigation(ArrayList<TokenNode> res, TokenNode Is, TokenNode Id, TokenNode[] list) throws NoSuchAlgorithmException, IOException {
        TokenNode Idnew = Id;
        
        // 处理起点终点重合的情况
        if (Is.id == Id.id) {
            System.out.println("处理起点终点重合...");
            ArrayList<TokenNode> temp = new ArrayList<TokenNode>();
            for (TokenNode t : list) {
                temp.add(t);
            }
            Idnew = getAlwaysToNearestPoint(Is, Id, temp);
        }
        
        long daohangstart = System.currentTimeMillis();

        // 创建独立的结果列表
        ArrayList<TokenNode> resLow = new ArrayList<>();
        ArrayList<TokenNode> resMid = new ArrayList<>();
        ArrayList<TokenNode> resHigh = new ArrayList<>();

        // 分组和桥接点计算
        StopSet[] grouping = SecureGrouping(Is, Idnew, new ArrayList<>(List.of(list)));
        StopSet PLow = grouping[0];
        // System.out.println("Plow size: " + PLow.list.size());
        
        StopSet PMid = grouping[1];
        // System.out.println("PMid size: " + PMid.list.size());
        
        StopSet PHigh = grouping[2];
        // System.out.println("PHigh size: " + PHigh.list.size());

        TokenNode[] bridging = SecureBridging(Is, Idnew, PMid, PHigh);
        TokenNode Ib1 = bridging[0];
        TokenNode Ib2 = bridging[1];
        
        System.out.println("Ib1: " + Ib1.id + ", Ib2: " + Ib2.id);
        System.out.println("开始执行分层导航...");

        // =============================================================
        // 修改点 1: 为了修复 VerifyError，暂时将 CompletableFuture 改为同步执行
        // 如果必须并行，请确保 lambda 内部不引用复杂的外部变量
        // 这里为了保证实验能跑通，改为了顺序执行，这对单次查询的逻辑正确性没有影响
        // =============================================================
        
        TokenNode finalIdnew = Idnew;

        // 1. 执行下部分导航 (Low Path)
        if (!PLow.list.isEmpty()) {
            try {
                // System.out.println("执行下导航...");
                processLowPath(resLow, Is, Ib1, PLow, Is, finalIdnew);
            } catch (Exception e) {
                throw new RuntimeException("LowPath 异常", e);
            }
        }

        // 2. 执行中部分导航 (Mid Path)
        if (!PMid.list.isEmpty()) {
            try {
                // System.out.println("执行中导航...");
                processMidPath(resMid, Ib1, Ib2, PMid);
            } catch (Exception e) {
                throw new RuntimeException("MidPath 异常", e);
            }
        }

        // =============================================================
        // 修改点 2: 修复 VerifyError 的核心位置
        // 将三元运算符改为明确的 if-else，并强制类型转换
        // =============================================================
        TokenNode highStartPoint;
        if (resMid.isEmpty()) {
            highStartPoint = Ib2;
        } else {
            // 显式转换，告诉编译器这里取出来的一定是 TokenNode
            highStartPoint = (TokenNode) resMid.get(resMid.size() - 1);
        }

        // 3. 执行上部分导航 (High Path)
        if (!PHigh.list.isEmpty()) {
            try {
                // System.out.println("执行上导航...");
                processHighPath(resHigh, highStartPoint, Idnew, PHigh, Ib1);
            } catch (Exception e) {
                throw new RuntimeException("HighPath 异常", e);
            }
        }

        System.out.println("分段路径生成完毕: Low=" + resLow.size() + ", Mid=" + resMid.size() + ", High=" + resHigh.size());

        // 合并结果
        res.addAll(resLow);
        res.addAll(resMid);
        res.addAll(resHigh);

        long daohangend = System.currentTimeMillis();
        long daohangtime = daohangend - daohangstart;
        System.out.println("导航花费时间为：" + daohangtime + " ms");
    }

    // 处理上部分路径的方法
    private void processLowPath(ArrayList<TokenNode> resLow, TokenNode ICs, TokenNode Ib1,
                                StopSet PLow, TokenNode Is, TokenNode Id) throws NoSuchAlgorithmException, IOException {
        System.out.println("It`s SN");
        System.out.println("res.size() = " + resLow.size());
        System.out.println("res：    :" + resLow);
//        Element esp = omega.Enc(new BigInteger("0"));


//        StopSet[] grouping = SecureGrouping(Is, Id, new ArrayList<>(List.of(new TokenNode[]{Ib1})));
        StopSet PRightSemi ;
        StopSet PLeftSemi;
        StopSet PLeft = new StopSet(), PRight = new StopSet();

        //将low节点分到左右边
        System.out.println("开始分节点左右");
        System.out.println("Is:   "+Is.id);
        System.out.println("Id:   "+Id.id);
        for (TokenNode node : PLow.list) {
            if (SecureOrienting(Is, Id, node) == LEFT) {
                PLeft.list.add(node);
                System.out.println("这个节点在左边"+node);
            } else {
                PRight.list.add(node);
                System.out.println("这个节点在右边"+node);
            }
        }

        if (SecureOrienting(Is, Id, Ib1) == LEFT) {
            if (PRight.list.size() == 1) {
                resLow.add(PRight.list.get(0));
            } else if (PRight.list.size() > 1) {
                StopSet[] sets = SecureSplitting(ICs, Ib1, PRight);
                PLeftSemi = sets[0];
                PRightSemi = sets[1];
                resLow.add(SecureScanning(ICs, Id, Ib1, PLeftSemi, PRightSemi, LEFT));
            } else {
                StopSet[] sets = SecureSplitting(ICs, Ib1, PLeft);
                PLeftSemi = sets[0];
                PRightSemi = sets[1];
                resLow.add(SecureScanning(ICs, Id, Ib1, PLeftSemi, PRightSemi, LEFT));
            }
        } else {
            if (PLeft.list.size() == 1) {
                resLow.add(PLeft.list.get(0));
            } else if (PLeft.list.size() > 1) {
                StopSet[] sets = SecureSplitting(ICs, Ib1, PLeft);
                PLeftSemi = sets[0];
                PRightSemi = sets[1];
                resLow.add(SecureScanning(ICs, Id, Ib1, PLeftSemi, PRightSemi, RIGHT));
            } else {
                StopSet[] sets = SecureSplitting(ICs, Ib1, PRight);
                PLeftSemi = sets[0];
                PRightSemi = sets[1];
                resLow.add(SecureScanning(ICs, Id, Ib1, PLeftSemi, PRightSemi, RIGHT));
            }
        }

        if (PLow.list.size() > 1) {
            //resLow.add(resLow.get(resLow.size() - 1));
            ICs = resLow.get(resLow.size() - 1);
            System.out.println("ICs:  "+ICs.id);
            System.out.println("Ib1:  "+Ib1.id);
            System.out.println("Is:  "+Is.id);
            System.out.println("Id:  "+Id.id);
            PLow.list.remove(resLow.get(resLow.size() - 1));
            System.out.println("PLow.list.size() = " + PLow.list.size());
            for(TokenNode t : PLow.list){
                System.out.println(t);
            }
            //processLowPath(resLow, ICs, Ib1, PLow, ICs, Id);
            //HermesEncNavigation navigation = new HermesEncNavigation(ckks.getPublicKeys(),ckks.getContext());
            TokenNode[] more= new TokenNode[PLow.list.size()];
            for(int i =0;i<PLow.list.size();i++){
                more[i] = PLow.list.get(i);
            }
            SecureNavigation(resLow, ICs, Id, more);
        }
}
    // 处理上部分路径的方法
    private void processHighPath(ArrayList<TokenNode> resHigh, TokenNode ICs, TokenNode Id,
                                 StopSet PHigh, TokenNode Ib1)
            throws NoSuchAlgorithmException, IOException {
        System.out.println("In High");
        TokenNode pull = null;
        StopSet PRightSemi = new StopSet();
        StopSet PLeftSemi = new StopSet();
        StopSet PLeft = new StopSet(), PRight = new StopSet();

        // 修改：使用实际起点 ICs（中部分最后一个点）来进行方向判断
        for (TokenNode node : PHigh.list) {
            if (SecureOrienting(ICs, Id, node) == LEFT) {
                PLeft.list.add(node);
                System.out.println("这个节点在左边"+node);
            } else {
                PRight.list.add(node);
                System.out.println("这个节点在右边"+node);
            }
        }

        // 修改：使用实际起点 ICs 进行导航判断
        if (SecureOrienting(ICs, Id, ICs) == LEFT) {
            if (PLeft.list.size() == 1) {
                pull = PLeft.list.get(0);
            } else if (PLeft.list.size() > 1) {
                StopSet[] sets = SecureSplitting(ICs, Id, PLeft);
                PLeftSemi = sets[0];
                PRightSemi = sets[1];
                pull = SecurePulling(ICs, ICs, Ib1, Id, PLeftSemi, PRightSemi, LEFT);
            } else {
                StopSet[] sets = SecureSplitting(ICs, Id, PRight);
                PLeftSemi = sets[0];
                PRightSemi = sets[1];
                pull = SecurePulling(ICs, ICs, Ib1, Id, PLeftSemi, PRightSemi, LEFT);
            }
        } else {
            if (PRight.list.size() == 1) {
                pull = PRight.list.get(0);
            } else if (PRight.list.size() > 1) {
                StopSet[] sets = SecureSplitting(ICs, Id, PRight);
                PLeftSemi = sets[0];
                PRightSemi = sets[1];
                pull = SecurePulling(ICs, ICs, Ib1, Id, PLeftSemi, PRightSemi, RIGHT);
            } else {
                StopSet[] sets = SecureSplitting(ICs, Id, PLeft);
                PLeftSemi = sets[0];
                PRightSemi = sets[1];
                pull = SecurePulling(ICs, ICs, Ib1, Id, PLeftSemi, PRightSemi, RIGHT);
            }
        }

        if (PHigh.list.size() > 1) {
            resHigh.add(pull);
            PHigh.list.remove(pull);
            System.out.println("PHigh.list.size() = " + PHigh.list.size());
            ICs = pull;  // 更新当前点
            TokenNode[] next = new TokenNode[PHigh.list.size()];
            for (int i = 0; i < PHigh.list.size(); i++) {
                next[i] = PHigh.list.get(i);
            }
            //processHighPath(resHigh, ICs, Id, PHigh, Ib1);
            //HermesEncNavigation navigation = new HermesEncNavigation(ckks.getPublicKeys(),ckks.getContext());
            TokenNode[] more= new TokenNode[PHigh.list.size()];
            for(int i =0;i<PHigh.list.size();i++){
                more[i] = PHigh.list.get(i);
            }
            SecureNavigation(resHigh, ICs, Id, more);
        } else {
            resHigh.add(pull);
            PHigh.list.remove(pull);
            System.out.println("PHigh.list.size() = " + PHigh.list.size());
        }
    }

    // 处理中间部分路径的方法
    // 处理中间部分路径的方法
    private void processMidPath(ArrayList<TokenNode> resMid, TokenNode ICs, TokenNode Ib2,
                                StopSet PMid) throws NoSuchAlgorithmException, IOException {
        System.out.println("In Mid");
        long SVNHS = System.currentTimeMillis();
        TokenNode svnh = SecureVerticallyNearestHop(ICs, Ib2, PMid);
        long SVNHE = System.currentTimeMillis();
        System.out.println("(SVNHE-SVNHS) = " + (SVNHE - SVNHS));
        if (!svnh.equals(Ib2)) {
            if (PMid.list.size() > 1) {
                resMid.add(svnh);
                PMid.list.remove(svnh);
                System.out.println("PMid.list.size() = " + PMid.list.size());
                TokenNode[] next = new TokenNode[PMid.list.size()];
                for (int i = 0; i < PMid.list.size(); i++) {
                    next[i] = PMid.list.get(i);
                }
                System.out.println("list.size() = " + PMid.list.size());
                processMidPath(resMid, svnh, Ib2, PMid);
            } else {
                resMid.add(svnh);
                PMid.list.remove(svnh);
                System.out.println("PMid.list.size() = " + PMid.list.size());
            }
        }
    }
}
