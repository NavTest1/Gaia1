package NSP.EncNavigationImpl;

import NSP.EncNavigation;
import NSP.EncNavigationTools;
import NSP.StopSet;
import Omega.PK;
import Class.TokenNode;
import Proxy.CT;
import ckks.CKKSHelper;
import ckks.Context;
import ckks.PublicKeys;
import lombok.SneakyThrows;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static NSP.EncNavigationTools.*;
import static NSP.EncNavigationTools.RIGHT;

public class GB_OSCH_A_A_Navigation implements EncNavigation {
    private PublicKeys pk;
    private CT ct;
    private Context context;
    //private NewOmega omega;
    private CKKSHelper ckks;
    public GB_OSCH_A_A_Navigation(PublicKeys pk,Context mcontext) throws IOException {
        this.pk = pk;
        this.context = mcontext;
        ct = new CT(pk,context);
//        omega = new NewOmega();
//        omega.SetByPk(pk);
        ckks = new CKKSHelper(2, 4, 10, 20);
        ckks.SetContext(context);
        ckks.SetPublicKeys(this.pk);
        SetNavigation(pk,ct,context);
    }
    @SneakyThrows
    @Override
    public void SecureNavigation(ArrayList<TokenNode> res, TokenNode Is, TokenNode Id, TokenNode[] list) {
        StopSet[] grouping = SecureGrouping(Is, Id, new ArrayList<>(List.of(list)));
        StopSet PLow = grouping[0];
        StopSet PMid = grouping[1];
        StopSet PHigh = grouping[2];
        TokenNode[] bridging = SecureBridging(Is, Id, PMid, PHigh);
        TokenNode Ib1 = bridging[0];
        TokenNode Ib2 = bridging[1];
        TokenNode Ics = Is;
        if (!PLow.list.isEmpty()) {
            TokenNode scan = null;
            StopSet PRightSemi = new StopSet();
            StopSet PLeftSemi = new StopSet();
            StopSet PLeft = new StopSet(), PRight = new StopSet();
            for (TokenNode node : PLow.list) {
                if (SecureOrienting(Is, Id, node) == LEFT) {
                    PLeft.list.add(node);
                } else {
                    PRight.list.add(node);
                }
            }
            if (SecureOrienting(Is, Id, Ib1) == LEFT) {
                if (PRight.list.size() == 1) {
                    scan = PRight.list.get(0);
                } else if (PRight.list.size() > 1) {
                    StopSet[] sets = SecureSplitting(Ics, Ib1, PRight);
                    PLeftSemi = sets[0];
                    PRightSemi = sets[1];
                    scan = SecureScanning(Ics, Id, Ib1, PLeftSemi, PRightSemi, LEFT);
                } else {
                    StopSet[] sets = SecureSplitting(Ics, Ib1, PLeft);
                    PLeftSemi = sets[0];
                    PRightSemi = sets[1];
                    scan = SecureScanning(Ics, Id, Ib1, PLeftSemi, PRightSemi, LEFT);
                }
            } else {
                if (PLeft.list.size() == 1) {
                    scan = PLeft.list.get(0);
                } else if (PLeft.list.size() > 1) {
                    StopSet[] sets = SecureSplitting(Ics, Ib1, PLeft);
                    PLeftSemi = sets[0];
                    PRightSemi = sets[1];
                    scan = SecureScanning(Ics, Id, Ib1, PLeftSemi, PRightSemi, RIGHT);

                } else {
                    StopSet[] sets = SecureSplitting(Ics, Ib1, PRight);
                    PLeftSemi = sets[0];
                    PRightSemi = sets[1];
                    scan = SecureScanning(Ics, Id, Ib1, PLeftSemi, PRightSemi, RIGHT);
                }
            }

            //TODO:需要考虑是否应该在服务器端求和最短路径
//            esp= omega.add(esp,);
            if (PLow.list.size() > 1) {
                res.add(scan);
                System.out.println("res.size() = " + res.size());
                Ics = scan;
                PLow.list.remove(scan);
                System.out.println("PLow.list.size() = " + PLow.list.size());
                TokenNode[] next = new TokenNode[PLow.list.size()];
                for (int i = 0; i < PLow.list.size(); i++) {
                    next[i] = PLow.list.get(i);
                }
                SecureNavigation(res, Ics, Ib1,  next);
            } else {
                res.add(scan);
                System.out.println("res.size() = " + res.size());
                Ics = scan;
                PLow.list.remove(scan);
                System.out.println("PLow.list.size() = " + PLow.list.size());
            }
        }
        if (!PMid.list.isEmpty()) {
            Ics = EncNavigationTools.getAlwaysToNearestPoint(Ib1, Id, PMid.list);
            res.add(Ics);
            PMid.list.remove(Ics);
            if (!PMid.list.isEmpty()) {
                TokenNode[] next = new TokenNode[PMid.list.size()];
                for (int i = 0; i < PMid.list.size(); i++) {
                    next[i] = PMid.list.get(i);
                }
                SecureNavigation(res, Ics, Id,  next);
            }
        }
        if (!PHigh.list.isEmpty()) {
            Ics = EncNavigationTools.getAlwaysToNearestPoint(Ics, Id, PHigh.list);
            res.add(Ics);
            PHigh.list.remove(Ics);
            if (!PHigh.list.isEmpty()) {
                TokenNode[] next = new TokenNode[PHigh.list.size()];
                for (int i = 0; i < PHigh.list.size(); i++) {
                    next[i] = PHigh.list.get(i);
                }
                SecureNavigation(res, Ics, Id,  next);
            }
        }
    }
}
