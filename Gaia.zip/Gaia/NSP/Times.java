package NSP;

public class Times {
    public static double alltimes=0.0d;
    public static double time234 =0.0d;
    public static double timePPT =0.0d;
    public static double timeEnc =0.0d;
    public static double timeEnum =0.0d;
    public static double timeMulR =0.0d;
}
