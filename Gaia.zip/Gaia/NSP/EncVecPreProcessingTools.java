package NSP;

import Omega.NewOmega;
import Omega.PK;
import ckks.CKKSHelper;
import ckks.Ciphertext;
import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.ElementPowPreProcessing;
import it.unisa.dia.gas.jpbc.PairingPreProcessing;

import java.io.IOException;

public class EncVecPreProcessingTools {
    //private final PairingPreProcessing ppp0;
   // private final PairingPreProcessing ppp1;

    //private final ElementPowPreProcessing h1;
    //private final PK pk;
    //private final NewOmega omega;
    private  CKKSHelper ckks ;
    public EncVecPreProcessingTools(EncVec esd) throws IOException {
        long ppts = System.currentTimeMillis();
        //Element ex = esd.getEvec()[0].getImmutable();
        Ciphertext ex = esd.getEvec()[0];
        //ex = dx-sx
        //Element ey = esd.getEvec()[1].getImmutable();
        Ciphertext ey = esd.getEvec()[1];
        //ey = dy-sy
        //pk = _pk;


        //ppp0 = _pk.getE().getPairingPreProcessingFromElement(ex);

        //ppp1 = _pk.getE().getPairingPreProcessingFromElement(ey);
        //h1 = _pk.getH1();
        //omega = new NewOmega();
        //omega.SetByPk(pk);
        //ckks = new CKKSHelper(2, 4, 10, 20);
        String savePath = "D:\\Gaia\\src\\main\\resources";
        ckks.loadContext(savePath);
        ckks.loadPublicKeys(savePath);
        long ppte = System.currentTimeMillis();
        Times.alltimes += (ppte - ppts);
        Times.timePPT += (ppte - ppts);
    }

//    private

    public Ciphertext ENCS_SD_SP(EncVec esp) {
        long ENCs = System.currentTimeMillis();
        //Element first = ppp0.pairing(esp.getEvec()[0]).getImmutable();//初始化为类的全局变量
        Ciphertext first = esp.getEvec()[0];
        //first = (px-sx)
        //Element second = ppp1.pairing(esp.getEvec()[1]).getImmutable();
        Ciphertext second = esp.getEvec()[1];
        //second = py-sy
        //Element res = omega.add_G1(first, second);
        Ciphertext res = ckks.add(first,second);
        //res= (px-sx)*(py-sy)*(h1Pre)的r次方       r为随机数
        //res = (px-sx)+(py-sy)
        long ENCe = System.currentTimeMillis();
        Times.alltimes += (ENCe - ENCs);
        Times.timeEnc += (ENCe - ENCs);
        return res;

    }


//    public Element Enum_P1P2_SD(EncNode p1, EncNode p2) {
//        long Enums = System.currentTimeMillis();
//        EncVec ep2p1 = new EncVec(p2, p1);
//        Element first = ppp0.pairing(ep2p1.getEvec()[0]).getImmutable();
//        Element second = ppp1.pairing(ep2p1.getEvec()[1]).getImmutable();
//
//        Element res = omega.add_G1(first, second);
//        long Enume = System.currentTimeMillis();
//        Times.alltimes += (Enume - Enums);
//        Times.timeEnum += (Enume - Enums);
//        return res.getImmutable();
//    }
}
