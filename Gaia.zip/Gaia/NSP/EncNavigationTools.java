package NSP;

import Omega.NewOmega;
import Omega.PK;
import Proxy.CT;
import Class.TokenNode;
import ckks.CKKSHelper;
import ckks.Ciphertext;
import ckks.Context;
import ckks.PublicKeys;
import it.unisa.dia.gas.jpbc.Element;
import lombok.SneakyThrows;
import org.apache.ibatis.jdbc.Null;

import java.io.IOException;
import java.math.BigInteger;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Random;



public class EncNavigationTools {

    public static final int LEFT = 1;
    public static final int RIGHT = 0;
    public static final int ON = -1;
    public static final boolean DEBUG_MODE = false;
    public static PublicKeys pk;

    //private static NewOmega omega;
    private static CKKSHelper ckks;
    private static CT ct;
    private static Random ram;
    private static Context context;
    static EncVecTools encVecTools;

    // 添加初始化方法
    public static void init(CKKSHelper ckksHelper, CT ctInstance, PublicKeys publicKeys) {
        ckks = ckksHelper;
        ct = ctInstance;
        pk = publicKeys;
        ram = new Random();
        System.out.println("EncNavigationTools 初始化完成");
    }
    public static void SetNavigation(PublicKeys pk1, CT ct1,Context mcontext) throws IOException {
        ram = new Random();
        pk = pk1;
        //omega = new NewOmega();
        //omega.SetByPk(pk);
        ckks = new CKKSHelper(2, 4, 10, 20);
        context = mcontext;
        ckks.SetContext(context);
        ckks.SetPublicKeys(pk);
        ckks.loadSecretKey("D:\\Gaia\\src\\main\\resources");
        ct = ct1;
        encVecTools = new EncVecTools(context,pk);

    }

    public static Ciphertext getRe(int ri) {
        //return omega.Enc1(BigInteger.valueOf(ri)).getImmutable();
        return ckks.encrypt(ri);
    }

    //    private final int

    private static int ri() {
        return ram.nextInt(1000) + 5000;
    }


    public static int SecureOrienting(TokenNode Is, TokenNode Id, TokenNode Ip) throws NoSuchAlgorithmException {
//        Omega omega=new Omega();omega.SetByPk(pk);
        System.out.println("It`s SO");
        if (Id.equals(Ip)) {
            return ON;
        }
        int cb3 = 0;
        EncNode ens = EncGraph.nodeSet.get(Is),
                end = EncGraph.nodeSet.get(Id),
                enp = EncGraph.nodeSet.get(Ip);

//        BigInteger r=new BigInteger(String.valueOf(ri));
        int ri = ri();
        Ciphertext re = getRe(ri);
        EncVec EOV = EncVecTools.getOV(ens, end);
        //EOV为向量SD 顺时针旋转90°
        EncVec ESP = new EncVec(ens, enp);
        //ESP 为向量SP
        Ciphertext encs = EncVecTools.ENCS_SD_SP(ESP, EOV);
        //Element encsr = omega.add_G1r(encs, re);
        Ciphertext encsr = ckks.add(encs,re);
        cb3 = ct.CT_CMP1(ri, encsr);
        if (cb3 == 1) return LEFT;
        return (cb3 == 1) ? LEFT : RIGHT;
    }


    /**
     * Secure splitting stop set [ ].
     *
     * @param Is    the is
     * @param Ib    the ib
     * @param Psemi the psemi
     * @return the stop set [ ]
     * @throws NoSuchAlgorithmException the no such algorithm exception
     */

    public static StopSet[] SecureSplitting(TokenNode Is, TokenNode Ib, StopSet Psemi) throws NoSuchAlgorithmException {
        System.out.println("It`s SS");
        StopSet[] res = new StopSet[2];
        StopSet PsemiL = new StopSet(), PsemiR = new StopSet();
        int side = ON;
        for (TokenNode node : Psemi.list) {
            side = SecureOrienting(Is, Ib, node);
            if (side == LEFT) {
                PsemiL.list.add(node);
            } else {
                PsemiR.list.add(node);
            }
        }
        res[0] = PsemiL;
        res[1] = PsemiR;
        return res;
    }

    /**
     * 安全分组，整个地图的点将分成三块
     *
     * @param tokens the tokens
     * @return StopSet[] ;[0]=Plow,[1]=Pmid,[2]=Phigh
     * @throws NoSuchAlgorithmException the no such algorithm exception
     */

    public static StopSet[] SecureGrouping(TokenNode Is, TokenNode Id, ArrayList<TokenNode> tokens) throws NoSuchAlgorithmException {
        System.out.println("It`s SG - 修正版本");
        
        // 修复：始终初始化三个StopSet
        StopSet low = new StopSet();
        StopSet mid = new StopSet();
        StopSet high = new StopSet();
        StopSet[] res = new StopSet[]{low, mid, high};

        int cb1 = 0, cb2 = 0;
        long t4s = System.currentTimeMillis();
        
        
        EncNode s = EncGraph.nodeSet.get(Is);
        EncNode d = EncGraph.nodeSet.get(Id);
        
        System.out.println("SG 输入: Is=" + Is.getId() + ", Id=" + Id.getId());
        System.out.println("SG 查找 EncGraph: Is=" + Is + " -> " + s);
        System.out.println("SG 查找 EncGraph: Id=" + Id + " -> " + d);
        System.out.println("SG 处理节点数量: " + tokens.size());
        
        if (s == null) {
            System.out.println("s为空");
        }
        if (d == null) {
            System.out.println("d为空");
        }
        
        // 修复：如果s或d为null，返回初始化的空StopSet数组
        if (d == null || s == null) {
            System.out.println("s或d为空，返回空分组结果");
            return res;
        }

        EncVec esd = new EncVec(s, d);
        EncVec eds = new EncVec(d, s);

        if (pk == null) {
            throw new NullPointerException("PK object is null in EncNavigationTools.SecureGrouping()");
        }

        for (TokenNode tokenNode : tokens) {
            EncNode p = EncGraph.nodeSet.get(tokenNode);
            
            // 修复：如果p为null，跳过该节点
            if (p == null) {
                System.out.println("途经节点 " + tokenNode.getId() + " 在EncGraph中不存在，跳过");
                continue;
            }

            EncVec esp = new EncVec(s, p);
            Ciphertext e1 = EncVecTools.ENCS_SD_SP(esp, esd);

            int ri = ri();
            Ciphertext r = getRe(ri);
            Ciphertext e1r = ckks.add(e1, r);

            cb1 = ct.CT_CMP1(ri, e1r);
            

            ri = ri();
            Ciphertext r1 = getRe(ri);

            EncVec edp = new EncVec(d, p);
            Ciphertext e2 = EncVecTools.ENCS_SD_SP(edp, eds);
            Ciphertext e2r = ckks.add(e2, r1);

            // 修复：移除测试代码或将其放在调试条件下
            if (DEBUG_MODE) {  // 你可以定义一个DEBUG_MODE常量
                Ciphertext test1 = ckks.encrypt(-142);
                Ciphertext test2 = ckks.encrypt(302);
                Ciphertext test3 = ckks.add(test1, test2);
                System.out.println(ckks.decrypt(test3));
            }

            cb2 = ct.CT_CMP1(ri, e2r);

            System.out.println("节点 " + tokenNode.getId() + ": cb1=" + cb1 + ", cb2=" + cb2);

            if (cb1 == 1 && cb2 == 0) {
                low.list.add(tokenNode);
                System.out.println("  分配到 Low 区");
            } else if (cb1 == 0 && cb2 == 0) {
                mid.list.add(tokenNode);
                System.out.println("  分配到 Mid 区");
            } else if (cb1 == 0 && cb2 == 1) {
                high.list.add(tokenNode);
                System.out.println("  分配到 High 区");
            } else {
                // (1,1) 或其他组合，按需要可收进 Mid 或单独集合
                mid.list.add(tokenNode);
                System.out.println("  特殊组合，分配到 Mid 区");
            }
        }
        
        // 修复：添加分组结果调试信息
        System.out.println("=== SecureGrouping 分组结果 ===");
        System.out.println("Low 区节点数量: " + low.list.size());
        for (TokenNode node : low.list) {
            System.out.println("  Low: " + node.getId());
        }
        System.out.println("Mid 区节点数量: " + mid.list.size());
        for (TokenNode node : mid.list) {
            System.out.println("  Mid: " + node.getId());
        }
        System.out.println("High 区节点数量: " + high.list.size());
        for (TokenNode node : high.list) {
            System.out.println("  High: " + node.getId());
        }
        System.out.println("==============================");
        
        return res;
    }
    /**
     * Secure scanning token node.
     *
     * @param Is     the is
     * @param Id     the id
     * @param Ib1    the ib 1
     * @param PsemiL the psemi l
     * @param PsemiR the psemi r
     * @param Side   the side
     * @return the token node
     * @throws NoSuchAlgorithmException the no such algorithm exception
     */

    public static TokenNode SecureScanning(TokenNode Is, TokenNode Id, TokenNode Ib1,
                                           StopSet PsemiL, StopSet PsemiR, int Side) throws NoSuchAlgorithmException {

        System.out.println("It`s SC");
        int cb4;
        TokenNode t1 = new TokenNode(), res = new TokenNode();

        EncNode s = EncGraph.nodeSet.get(Is);
        EncNode d = EncGraph.nodeSet.get(Id);
        EncNode b1 = EncGraph.nodeSet.get(Ib1);
        EncVec eds = new EncVec(d, s);
        EncVec ebs = new EncVec(b1, s);

        //需要重新写
        EncVec eovSB = EncVecTools.getOV(s, b1);
        EncVec eov = EncVecTools.getOV(s, d);
        //需要重新写
        EncVec evoSB = EncVecTools.getVO(s, b1);
        EncVec evo = EncVecTools.getVO(s, d);

//        EncVecPreProcessingTools toolsDS = new EncVecPreProcessingTools(eds, pk);
//        EncVecPreProcessingTools toolsOV = new EncVecPreProcessingTools(eov, pk);
//        EncVecPreProcessingTools toolsOVSB = new EncVecPreProcessingTools(eovSB, pk);
//        EncVecPreProcessingTools toolsVO = new EncVecPreProcessingTools(evo, pk);
//        EncVecPreProcessingTools toolsVOSB = new EncVecPreProcessingTools(evoSB, pk);
//        EncVecPreProcessingTools toolsBS = new EncVecPreProcessingTools(ebs, pk);


        StopSet P_On_L1 = new StopSet();
        StopSet P_On_B1S = new StopSet();
        if (Side == LEFT) {
            if (!PsemiR.list.isEmpty()) {//如果右半边点集非空，
                t1 = PsemiR.list.get(0);
                for (TokenNode node : PsemiR.list) {//顺时针情况：遍历右半边所有的点集
                    EncNode p = EncGraph.nodeSet.get(node);
                    EncVec esp = new EncVec(s, p);
                    //Element encs = toolsDS.ENCS_SD_SP(esp).getImmutable();
                    Ciphertext encs = EncVecTools.ENCS_SD_SP(eds,esp);
                    int ri = ri();
                    Ciphertext re = getRe(ri);
                    //Element encsr = omega.add_G1r(encs, re).getImmutable();
                    Ciphertext encsr = ckks.add(encs,re);
                    cb4 = ct.CT_CMP1(ri, encsr);//比较该点的
                    if (cb4 == 1) P_On_L1.list.add(node);//判断左右，如果在sd，则添加到"在L1线上或者更右边"的集合上
                }
                if (!P_On_L1.list.isEmpty()) {

                    t1 = P_On_L1.list.get(0);
                    //从"在L1线上或者更右边"集合中不断迭代点
                    ArrayList<TokenNode> list = P_On_L1.list;
                    System.out.println("这是P_On_L1上的点"+t1);
                    System.out.println("此时is为"+Is);
                    System.out.println("此时id为"+Id);
                    for (int i = 1, listSize = list.size(); i < listSize; i++) {
                        TokenNode t2 = list.get(i);
                        System.out.println("这是P_On_L1上的点"+t2);
                        EncNode p1 = EncGraph.nodeSet.get(t1);
                        EncNode p2 = EncGraph.nodeSet.get(t2);
                        EncVec ep1p2 = new EncVec(p2,p1);
                        //Element enum1 = toolsOV.Enum_P1P2_SD(p1, p2);//从投影距离继续寻找
                        Ciphertext enum1 = EncVecTools.ENCS_SD_SP(eov,ep1p2);
                        int ri = ri();
                        Ciphertext re = getRe(ri);
                        //Element enum1r = omega.add_G1r(enum1, re).getImmutable();
                        Ciphertext enum1r = ckks.add(enum1,re);
                        cb4 = ct.CT_CMP1(ri, enum1r);
                        if (cb4 == 0) t1 = t2;//继续找最右边的点
                    }
                    //return t1;
                } else {
                    ArrayList<TokenNode> list = PsemiR.list;//调用SO分侧，
                    for (int i = 1; i < list.size(); i++) {
                        TokenNode t2 = list.get(i);
                        if (SecureOrienting(t1, Ib1, t2) == RIGHT) {//如果在右侧就继续向右找
                            t1 = t2;
                        }
                    }
                }
                res = t1;
            } else if (!PsemiL.list.isEmpty()) {//如果左半边集合非空（右半集实在没有结点）
                t1 = PsemiL.list.get(0);
                for (TokenNode node : PsemiL.list) {
                    EncNode p = EncGraph.nodeSet.get(node);
                    EncVec esp = new EncVec(s, p);
                    //Element encs = toolsOVSB.ENCS_SD_SP(esp).getImmutable();//注意：左半边的集合应该和在SB1的垂直线进行比较
                    Ciphertext encs = EncVecTools.ENCS_SD_SP(eovSB,esp);
                    //为什么找垂线上的点（SB1OV）
                    int ri = ri();
                    Ciphertext re = getRe(ri);
                    //Element encsr = omega.add_G1r(encs, (re)).getImmutable();
                    Ciphertext encsr = ckks.add(encs,re);
                    cb4 = ct.CT_CMP1(ri, encsr);
                    if (cb4 == 1) P_On_B1S.list.add(node);
                }
                if (!P_On_B1S.list.isEmpty()) {//在B1S这条线上的所有点

                    t1 = P_On_B1S.list.get(0);
                    for (int i = 1; i < P_On_B1S.list.size(); i++) {
                        TokenNode t2 = P_On_B1S.list.get(i);
                        EncNode p1 = EncGraph.nodeSet.get(t1);
                        EncNode p2 = EncGraph.nodeSet.get(t2);
                        EncVec ep1p2 = new EncVec(p2,p1);
                        //Element enum1 = toolsBS.Enum_P1P2_SD(p1, p2);//求的是在B1S上的投影，左半边集上
                        Ciphertext enum1 = EncVecTools.ENCS_SD_SP(ebs,ep1p2);
                        //右半边是SB1上的投影最小
                        int ri = ri();
                        Ciphertext re = getRe(ri);
                        //Element enum1r = omega.add_G1r(enum1, (re)).getImmutable();
                        Ciphertext enum1r = ckks.add(enum1,re);
                        cb4 = ct.CT_CMP1(ri, enum1r);
                        if (cb4 == 0) t1 = t2;//继续迭代
                    }
                    //继续找投影量最小的点
                } else {
                    for (int i = 1; i < PsemiL.list.size(); i++) {
                        TokenNode t2 = PsemiL.list.get(i);
                        if (SecureOrienting(t1, Ib1, t2) == RIGHT) {
                            t1 = t2;
                        }
                    }
                }
                res = t1;
            }
        } else if (Side == RIGHT) {
            if (!PsemiL.list.isEmpty()) {
                t1 = PsemiL.list.get(0);
                for (TokenNode node : PsemiL.list) {//应该在左集中寻找
                    EncNode p = EncGraph.nodeSet.get(node);

                    EncVec esp = new EncVec(s, p);
                    //Element encs = toolsVOSB.ENCS_SD_SP(esp).getImmutable();
                    Ciphertext encs = EncVecTools.ENCS_SD_SP(evoSB,esp);
                    //还是沿着DS的方向上去找，反正已经确定了半边了，现在只要保证在Low区就行
                    int ri = ri();
                    Ciphertext re = getRe(ri);
                    //Element encsr = omega.add_G1r(encs, (re)).getImmutable();
                    Ciphertext encsr = ckks.add(encs,re);
                    cb4 = ct.CT_CMP1(ri, encsr);
                    if (cb4 == 1) P_On_B1S.list.add(node);
                }
                if (!P_On_B1S.list.isEmpty()) {
                    t1 = P_On_B1S.list.get(0);
                    for (int i = 1; i < P_On_B1S.list.size(); i++) {
                        TokenNode t2 = P_On_B1S.list.get(i);
                        EncNode p1 = EncGraph.nodeSet.get(t1);
                        EncNode p2 = EncGraph.nodeSet.get(t2);
                        EncVec ep1p2 = new EncVec(p2,p1);
                        //Element enum1 = toolsDS.Enum_P1P2_SD(p1, p2);//应该统计反方向的投影大小
                        Ciphertext enum1 = EncVecTools.ENCS_SD_SP(eds,ep1p2);
                        int ri = ri();
                        Ciphertext re = getRe(ri);
                        //Element enum1r = omega.add_G1r(enum1, (re)).getImmutable();
                        Ciphertext enum1r = ckks.add(enum1,re);
                        cb4 = ct.CT_CMP1(ri, enum1r);
                        if (cb4 == 0) t1 = t2;
                    }
                } else {
                    for (TokenNode t2 : PsemiL.list) {
//                        EncNode p1 = EncGraph.nodeSet.get(t1);
                        EncNode p2 = EncGraph.nodeSet.get(t2);
                        EncVec esp = new EncVec(s, p2);
                        int ri = ri();
                        Ciphertext re = getRe(ri);
                        //Element encsr = omega.add_G1r(toolsDS.ENCS_SD_SP(new EncVec(b2, p2)), re);
                        Ciphertext encsr = ckks.add(EncVecTools.ENCS_SD_SP(eds,esp),re);
                        cb4 = ct.CT_CMP1(ri, encsr);
                        if (cb4 == 1) {
                            P_On_L1.list.add(t2);
                        }
                    }

                    if (!P_On_L1.list.isEmpty()) {
                        t1 = P_On_L1.list.get(0);
                        for (int i = 1; i < P_On_L1.list.size(); i++) {
                            TokenNode t2 = P_On_L1.list.get(i);
                            EncNode p1 = EncGraph.nodeSet.get(t1);
                            EncNode p2 = EncGraph.nodeSet.get(t2);
                            EncVec ep1p2 = new EncVec(p2,p1);
                            int ri = ri();
                            Ciphertext re = getRe(ri);
                            //Element enumr = omega.add_G1r(toolsVO.Enum_P1P2_SD(p1, p2), re).getImmutable();
                            Ciphertext enumr = ckks.add(EncVecTools.ENCS_SD_SP(evo,ep1p2),re);
                            cb4 = ct.CT_CMP1(ri, enumr);
                            if (cb4 == 0) {
                                t1 = t2;
                            }
                        }
                    } else {
                        for (int i = 1; i < PsemiL.list.size(); i++) {
                            TokenNode t2 = PsemiL.list.get(i);
                            if (SecureOrienting(t2, Ib1, t1) == LEFT) {
                                t1 = t2;
                            }
                        }
                    }
                }
                res = t1;
            } else if (!PsemiR.list.isEmpty()) {
                StopSet P_On_DS = new StopSet();
                t1 = PsemiR.list.get(0);
                for (TokenNode node : PsemiR.list) {
                    EncNode p = EncGraph.nodeSet.get(node);
                    EncVec esp = new EncVec(s, p);
                    //Element encs = toolsVO.ENCS_SD_SP(esp).getImmutable();//应该是OVSB的相反向量
                    Ciphertext encs = EncVecTools.ENCS_SD_SP(evo,esp);
                    int ri = ri();
                    Ciphertext re = getRe(ri);
                    //Element encsr = omega.add_G1r(encs, (re)).getImmutable();
                    Ciphertext encsr = ckks.add(encs,re);
                    cb4 = ct.CT_CMP1(ri, encsr);
                    if (cb4 == 1) P_On_DS.list.add(node);
                }
                if (!P_On_DS.list.isEmpty()) {
                    t1 = P_On_DS.list.get(0);
                    for (int i = 0; i < P_On_DS.list.size(); i++) {
                        TokenNode t2 = P_On_DS.list.get(i);
                        EncNode p1 = EncGraph.nodeSet.get(t1);
                        EncNode p2 = EncGraph.nodeSet.get(t2);
                        EncVec ep1p2 = new EncVec(p2,p1);
                        //Element enum1 = toolsDS.Enum_P1P2_SD(p1, p2);
                        Ciphertext enum1 = EncVecTools.ENCS_SD_SP(eds,ep1p2);
                        int ri = ri();
                        Ciphertext re = getRe(ri);
                        //Element enum1r = omega.add_G1r(enum1, (re)).getImmutable();
                        Ciphertext enum1r = ckks.add(enum1,re);
                        cb4 = ct.CT_CMP1(ri, enum1r);
                        if (cb4 == 0) t1 = t2;
                    }
                } else {
                    for (int i = 1; i < PsemiR.list.size(); i++) {
                        TokenNode t2 = PsemiR.list.get(i);
                        if (SecureOrienting(t1, Ib1, t2) == LEFT) {
                            t1 = t2;
                        }
                    }

                }
                res = t1;
            }
        } else {
            if (!PsemiR.list.isEmpty()) {
                t1 = PsemiR.list.get(0);
                for (TokenNode node : PsemiR.list) {
                    EncNode p = EncGraph.nodeSet.get(node);
                    EncVec esp = new EncVec(s, p);
                    //Element encs = toolsDS.ENCS_SD_SP(esp).getImmutable();
                    Ciphertext encs = EncVecTools.ENCS_SD_SP(eds,esp);
                    int ri = ri();
                    Ciphertext re = getRe(ri);
                    //Element encsr = omega.add_G1r(encs, (re)).getImmutable();
                    Ciphertext encsr = ckks.add(encs,re);
                    cb4 = ct.CT_CMP1(ri, encsr);
                    if (cb4 == 1) P_On_L1.list.add(node);
                }
                if (!P_On_L1.list.isEmpty()) {
                    t1 = P_On_L1.list.get(0);
                    for (int i = 1; i < P_On_L1.list.size(); i++) {
                        TokenNode t2 = P_On_L1.list.get(i);
                        EncNode p1 = EncGraph.nodeSet.get(t1);
                        EncNode p2 = EncGraph.nodeSet.get(t2);
                        EncVec ep1p2 = new EncVec(p2,p1);
                        //Element enum1 = toolsOV.Enum_P1P2_SD(p1, p2);
                        Ciphertext enum1 = EncVecTools.ENCS_SD_SP(eov,ep1p2);
                        int ri = ri();
                        Ciphertext re = getRe(ri);
                        //Element enum1r = omega.add_G1r(enum1, (re)).getImmutable();
                        Ciphertext enum1r = ckks.add(enum1,re);
                        cb4 = ct.CT_CMP1(ri, enum1r);
                        if (cb4 == 0) t1 = t2;
                    }
                } else {
                    for (int i = 1; i < PsemiR.list.size(); i++) {
                        TokenNode t2 = PsemiR.list.get(i);
                        if (SecureOrienting(t1, Ib1, t2) == RIGHT) {
                            t1 = t2;
                        }
                    }


                }
            } else if (!PsemiL.list.isEmpty()) {
                t1 = PsemiL.list.get(0);
                for (TokenNode t : PsemiL.list) {
                    EncNode p = EncGraph.nodeSet.get(t);
                    EncVec esp = new EncVec(s, p);
                    int ri = ri();
                    Ciphertext re = getRe(ri);
                    //Element enumr = omega.add_G1r(toolsVOSB.ENCS_SD_SP(esp), re);
                    Ciphertext enumr = ckks.add(EncVecTools.ENCS_SD_SP(esp,evoSB),re);
                    cb4 = ct.CT_CMP1(ri, enumr);
                    if (cb4 == 1) P_On_B1S.list.add(t);
                }
                if (!P_On_B1S.list.isEmpty()) {
                    t1 = P_On_B1S.list.get(0);
                    for (int i = 1; i < P_On_B1S.list.size(); i++) {
                        TokenNode t2 = P_On_B1S.list.get(i);
                        EncNode p1 = EncGraph.nodeSet.get(t1);
                        EncNode p2 = EncGraph.nodeSet.get(t2);
                        EncVec ep1p2 = new EncVec(p2,p1);
                        int ri = ri();
                        Ciphertext re = getRe(ri);
                        //Element enum1r = omega.add_G1r(toolsDS.Enum_P1P2_SD(p1, p2), re).getImmutable();
                        Ciphertext enum1r = ckks.add(EncVecTools.ENCS_SD_SP(eds,ep1p2),re);
                        cb4 = ct.CT_CMP1(ri, enum1r);
                        if (cb4 == 0) {
                            t1 = t2;
                        }
                    }
                } else {
                    for (int i = 1; i < PsemiL.list.size(); i++) {
                        TokenNode t2 = PsemiL.list.get(i);
                        if (SecureOrienting(t1, Ib1, t2) == RIGHT) {
                            t1 = t2;
                        }
                    }
                }
                res = t1;
            }
        }
        return res;
    }


    /**
     * Secure pulling token node.
     *
     * @param Is     the is
     * @param Iss    the iss
     * @param Ib1    the ib 1
     * @param Ib2    the ib 2
     * @param PsemiL the psemi l
     * @param PsemiR the psemi r
     * @param Side   the side
     * @return the token node
     */

    @SneakyThrows
    public static TokenNode SecurePulling(TokenNode Is, TokenNode Iss, TokenNode Ib1, TokenNode Ib2,
                                          StopSet PsemiL, StopSet PsemiR, int Side) {
        System.out.println("It`s SP");
        int cb4;
        TokenNode t1, res = null;

        EncNode s = EncGraph.nodeSet.get(Is);
        EncNode ss = EncGraph.nodeSet.get(Iss);
        EncNode b2 = EncGraph.nodeSet.get(Ib2);

        StopSet P_On_L2 = new StopSet();
        StopSet P_On_SD = new StopSet();
        StopSet P_On_B2CS = new StopSet();

        EncVec esd = new EncVec(s, b2);//d点和b2点重合
        EncVec eds = new EncVec(b2, s);
        EncVec eov = EncVecTools.getOV(s, b2);
        EncVec evo = EncVecTools.getVO(s, b2);
        EncVec evoSSB2 = EncVecTools.getVO(ss, b2);


//        EncVecPreProcessingTools toolsDS = new EncVecPreProcessingTools(eds, pk);
//        EncVecPreProcessingTools toolsSD = new EncVecPreProcessingTools(esd, pk);
//        EncVecPreProcessingTools toolsVO = new EncVecPreProcessingTools(evo, pk);
//        EncVecPreProcessingTools toolsSSB2VO = new EncVecPreProcessingTools(evoSSB2, pk);
//        EncVecPreProcessingTools toolsOV = new EncVecPreProcessingTools(eov, pk);
        if (Side == ON) {
            if (!PsemiR.list.isEmpty()) {
                t1 = PsemiR.list.get(0);
                for (TokenNode t2 : PsemiR.list) {
                    EncNode p2 = EncGraph.nodeSet.get(t2);
                    EncVec dj = new EncVec(s, p2);
                    int ri = ri();
                    Ciphertext re = getRe(ri);
                    //Element encsr = omega.add_G1r(toolsSD.ENCS_SD_SP(new EncVec(s, p2)), re);
                    Ciphertext encsr = ckks.add(EncVecTools.ENCS_SD_SP(dj,esd),re);
                    cb4 = ct.CT_CMP1(ri, encsr);
                    if (cb4 == 1) {
                        P_On_L2.list.add(t2);
                    }
                }
                if (!P_On_L2.list.isEmpty()) {
                    t1 = P_On_L2.list.get(0);
                    for (int i = 1; i < P_On_L2.list.size(); i++) {
                        TokenNode t2 = P_On_L2.list.get(i);
                        EncNode p1 = EncGraph.nodeSet.get(t1);
                        EncNode p2 = EncGraph.nodeSet.get(t2);
                        EncVec ep1p2 = new EncVec(p2,p1);
                        int ri = ri();
                        Ciphertext re = getRe(ri);
                        //Element enumr = omega.add_G1r(toolsOV.Enum_P1P2_SD(p1, p2), re);
                        Ciphertext enumr = ckks.add(EncVecTools.ENCS_SD_SP(eov,ep1p2),re);
                        cb4 = ct.CT_CMP1(ri, enumr);
                        if (cb4 == 1) {
                            t1 = t2;
                        }
                    }
                } else {
                    for (int i = 1; i < PsemiR.list.size(); i++) {
                        TokenNode t2 = PsemiR.list.get(i);
                        if (SecureOrienting(t1, Ib1, t2) == 1) {
                            t1 = t2;
                        }
                    }
                }
                res = t1;
            } else if (!PsemiL.list.isEmpty()) {
                t1 = PsemiL.list.get(0);
                for (TokenNode t2 : PsemiL.list) {
                    EncNode p2 = EncGraph.nodeSet.get(t2);
                    int ri = ri();
                    Ciphertext re = getRe(ri);
                    //Element encsr = omega.add_G1r(toolsSSB2VO.ENCS_SD_SP(new EncVec(b2, p2)), re);
                    Ciphertext encsr = ckks.add(EncVecTools.ENCS_SD_SP(evoSSB2,new EncVec(b2, p2)),re);
                    cb4 = ct.CT_CMP1(ri, encsr);
                    if (cb4 == 1) {
                        P_On_B2CS.list.add(t2);
                    }
                }
                if (!P_On_B2CS.list.isEmpty()) {
                    t1 = P_On_B2CS.list.get(0);
                    for (int i = 1; i < P_On_B2CS.list.size(); i++) {
                        TokenNode t2 = P_On_B2CS.list.get(i);
                        EncNode p1 = EncGraph.nodeSet.get(t1);
                        EncNode p2 = EncGraph.nodeSet.get(t2);
                        EncVec ep1p2 = new EncVec(p2,p1);
                        int ri = ri();
                        Ciphertext re = getRe(ri);
                        //Element enumr = omega.add_G1r(toolsDS.Enum_P1P2_SD(p1, p2), re);
                        Ciphertext enumr = ckks.add(EncVecTools.ENCS_SD_SP(eds,ep1p2),re);
                        cb4 = ct.CT_CMP1(ri, enumr);
                        if (cb4 == 1) {
                            t1 = t2;
                        }
                    }
                } else {
                    for (int i = 1; i < PsemiL.list.size(); i++) {
                        TokenNode t2 = PsemiL.list.get(i);
                        if (SecureOrienting(t1, Ib1, t2) == RIGHT) {
                            t1 = t2;

                        }
                    }
                }
                res = t1;
            }
            return res;
        }
        if (Ib1.equals(Ib2)) {
            if (Side == LEFT) {
                if (!PsemiR.list.isEmpty()) {
                    t1 = PsemiR.list.get(0);
                    for (TokenNode t2 : PsemiR.list) {
                        EncNode p2 = EncGraph.nodeSet.get(t2);
                        int ri = ri();
                        Ciphertext re = getRe(ri);
                        //Element encsr = omega.add_G1r(toolsSD.ENCS_SD_SP(new EncVec(s, p2)), re);
                        Ciphertext encsr = ckks.add(EncVecTools.ENCS_SD_SP(esd,new EncVec(s, p2)),re);
                        cb4 = ct.CT_CMP1(ri, encsr);
                        if (cb4 == 1) {
                            P_On_L2.list.add(t2);
                        }
                    }
                    if (!P_On_L2.list.isEmpty()) {
                        t1 = P_On_L2.list.get(0);
                        for (int i = 1; i < P_On_L2.list.size(); i++) {
                            TokenNode t2 = P_On_L2.list.get(i);
                            EncNode p1 = EncGraph.nodeSet.get(t1);
                            EncNode p2 = EncGraph.nodeSet.get(t2);
                            EncVec ep1p2 = new EncVec(p2,p1);
                            int ri = ri();
                            Ciphertext re = getRe(ri);
                            //Element enumr = omega.add_G1r(toolsOV.Enum_P1P2_SD(p1, p2), re);
                            Ciphertext enumr = ckks.add(EncVecTools.ENCS_SD_SP(eov,ep1p2),re);
                            cb4 = ct.CT_CMP1(ri, enumr);
                            if (cb4 == 1) {
                                t1 = t2;
                            }
                        }
                    } else {
                        for (int i = 1; i < PsemiR.list.size(); i++) {
                            TokenNode t2 = PsemiR.list.get(i);
                            if (SecureOrienting(t1, Ib1, t2) == 1) {
                                t1 = t2;
                            }
                        }
                    }
                    res = t1;
                } else if (!PsemiL.list.isEmpty()) {
                    t1 = PsemiL.list.get(0);
                    for (TokenNode t2 : PsemiL.list) {
                        EncNode p2 = EncGraph.nodeSet.get(t2);
                        int ri = ri();
                        Ciphertext re = getRe(ri);
                        //Element encsr = omega.add_G1r(toolsSSB2VO.ENCS_SD_SP(new EncVec(b2, p2)), re);
                        Ciphertext encsr = ckks.add(EncVecTools.ENCS_SD_SP(evoSSB2,new EncVec(b2, p2)),re);
                        cb4 = ct.CT_CMP1(ri, encsr);
                        if (cb4 == 1) {
                            P_On_B2CS.list.add(t2);
                        }
                    }
                    if (!P_On_B2CS.list.isEmpty()) {
                        t1 = P_On_B2CS.list.get(0);
                        for (int i = 1; i < P_On_B2CS.list.size(); i++) {
                            TokenNode t2 = P_On_B2CS.list.get(i);
                            EncNode p1 = EncGraph.nodeSet.get(t1);
                            EncNode p2 = EncGraph.nodeSet.get(t2);
                            EncVec ep1p2 = new EncVec(p2,p1);
                            int ri = ri();
                            Ciphertext re = getRe(ri);
                            //Element enumr = omega.add_G1r(toolsDS.Enum_P1P2_SD(p1, p2), re);
                            Ciphertext enumr = ckks.add(EncVecTools.ENCS_SD_SP(eds,ep1p2),re);
                            cb4 = ct.CT_CMP1(ri, enumr);
                            if (cb4 == 1) {
                                t1 = t2;
                            }
                        }
                    } else {
                        for (int i = 1; i < PsemiL.list.size(); i++) {
                            TokenNode t2 = PsemiL.list.get(i);
                            if (SecureOrienting(t1, Ib1, t2) == RIGHT) {
                                t1 = t2;

                            }
                        }
                    }
                    res = t1;
                }

            } else {
                if (!PsemiL.list.isEmpty()) {
                    t1 = PsemiL.list.get(0);
                    for (TokenNode t2 : PsemiL.list) {
                        EncNode p2 = EncGraph.nodeSet.get(t2);
                        int ri = ri();
                        Ciphertext re = getRe(ri);
                        //Element encsr = omega.add_G1r(toolsSSB2VO.ENCS_SD_SP(new EncVec(b2, p2)), re);
                        Ciphertext encsr = ckks.add(EncVecTools.ENCS_SD_SP(evoSSB2,new EncVec(b2, p2)),re);
                        cb4 = ct.CT_CMP1(ri, encsr);
                        if (cb4 == 1) {
                            P_On_B2CS.list.add(t2);
                        }
                    }
                    if (!P_On_B2CS.list.isEmpty()) {
                        t1 = P_On_B2CS.list.get(0);
                        for (int i = 1; i < P_On_B2CS.list.size(); i++) {
                            TokenNode t2 = P_On_B2CS.list.get(i);
                            EncNode p1 = EncGraph.nodeSet.get(t1);
                            EncNode p2 = EncGraph.nodeSet.get(t2);
                            EncVec ep1p2 = new EncVec(p2,p1);
                            int ri = ri();
                            Ciphertext re = getRe(ri);
                            //Element enumr = omega.add_G1r(toolsDS.Enum_P1P2_SD(p1, p2), re);
                            Ciphertext enumr = ckks.add(EncVecTools.ENCS_SD_SP(eds,ep1p2),re);
                            cb4 = ct.CT_CMP1(ri, enumr);
                            if (cb4 == 1) {
                                t1 = t2;
                            }
                        }
                    } else {
                        for (int i = 1; i < PsemiL.list.size(); i++) {
                            TokenNode t2 = PsemiL.list.get(i);
                            if (SecureOrienting(t1, Ib1, t2) == RIGHT) {
                                t1 = t2;

                            }
                        }
                    }
                    res = t1;
                } else if (!PsemiR.list.isEmpty()) {
                    t1 = PsemiR.list.get(0);
                    for (TokenNode t2 : PsemiR.list) {
                        EncNode p2 = EncGraph.nodeSet.get(t2);
                        int ri = ri();
                        Ciphertext re = getRe(ri);
                        //Element encsr = omega.add_G1r(toolsVO.ENCS_SD_SP(new EncVec(b2, p2)), re);
                        Ciphertext encsr = ckks.add(EncVecTools.ENCS_SD_SP(evo,new EncVec(b2, p2)),re);
                        cb4 = ct.CT_CMP1(ri, encsr);
                        if (cb4 == 1) {
                            P_On_SD.list.add(t2);
                        }
                    }
                    if (!P_On_SD.list.isEmpty()) {
                        t1 = P_On_SD.list.get(0);
                        for (int i = 1; i < P_On_SD.list.size(); i++) {
                            TokenNode t2 = P_On_SD.list.get(i);
                            EncNode p1 = EncGraph.nodeSet.get(t1);
                            EncNode p2 = EncGraph.nodeSet.get(t2);
                            EncVec ep1p2 = new EncVec(p2,p1);
                            int ri = ri();
                            Ciphertext re = getRe(ri);
                            //Element enumr = omega.add_G1r(toolsVO.Enum_P1P2_SD(p1, p2), re);
                            Ciphertext enumr = ckks.add(EncVecTools.ENCS_SD_SP(evo,ep1p2),re);
                            cb4 = ct.CT_CMP1(ri, enumr);
                            if (cb4 == 1) {
                                t1 = t2;
                            }
                        }
                    } else {
                        for (int i = 1; i < PsemiR.list.size(); i++) {
                            TokenNode t2 = PsemiR.list.get(i);
                            if (SecureOrienting(t1, Ib1, t2) == LEFT) {
                                t1 = t2;
                            }
                        }
                    }
                    res = t1;
                }
            }
        } else {
            if (Side == LEFT) {

                if (!PsemiR.list.isEmpty()) {
                    t1 = PsemiR.list.get(0);
                    for (TokenNode t2 : PsemiR.list) {
                        EncNode p = EncGraph.nodeSet.get(t2);
                        int ri = ri();
                        Ciphertext re = getRe(ri);
                        //Element encsr = omega.add_G1r(toolsSD.ENCS_SD_SP(new EncVec(s, p)), re);
                        Ciphertext encsr = ckks.add(EncVecTools.ENCS_SD_SP(esd,new EncVec(s, p)),re);
                        cb4 = ct.CT_CMP1(ri, encsr);
                        if (cb4 == 1) {
                            P_On_L2.list.add(t2);
                        }
                    }
                    if (!P_On_L2.list.isEmpty()) {
                        t1 = P_On_L2.list.get(0);
                        for (int i = 1; i < P_On_L2.list.size(); i++) {
                            TokenNode t2 = P_On_L2.list.get(i);
                            EncNode p1 = EncGraph.nodeSet.get(t1);
                            EncNode p2 = EncGraph.nodeSet.get(t2);
                            EncVec ep1p2 = new EncVec(p2,p1);
                            int ri = ri();
                            Ciphertext re = getRe(ri);
                            //Element enumr = omega.add_G1r(toolsOV.Enum_P1P2_SD(p1, p2), re);
                            Ciphertext enumr = ckks.add(EncVecTools.ENCS_SD_SP(eov,ep1p2),re);
                            cb4 = ct.CT_CMP1(ri, enumr);
                            if (cb4 == 1) {
                                t1 = t2;
                            }
                        }
                    } else {
                        for (int i = 1; i < PsemiR.list.size(); i++) {
                            TokenNode t2 = PsemiR.list.get(i);
                            if (SecureOrienting(t1, Ib1, t2) == LEFT) {
                                t1 = t2;
                            }
                        }
                    }
                    res = t1;
                } else if (!PsemiL.list.isEmpty()) {
                    t1 = PsemiL.list.get(0);
                    for (TokenNode t2 : PsemiL.list) {
                        EncNode p2 = EncGraph.nodeSet.get(t2);
                        int ri = ri();
                        Ciphertext re = getRe(ri);
                        //Element encsr = omega.add_G1r(toolsSSB2VO.ENCS_SD_SP(new EncVec(b2, p2)), re);
                        Ciphertext encsr = ckks.add(EncVecTools.ENCS_SD_SP(evoSSB2,new EncVec(b2, p2)),re);
                        cb4 = ct.CT_CMP1(ri, encsr);
                        if (cb4 == 1) {
                            P_On_B2CS.list.add(t2);
                        }
                    }
                    if (!P_On_B2CS.list.isEmpty()) {
                        t1 = P_On_B2CS.list.get(0);
                        for (int i = 1; i < P_On_B2CS.list.size(); i++) {
                            TokenNode t2 = P_On_B2CS.list.get(i);
                            EncNode p1 = EncGraph.nodeSet.get(t1);
                            EncNode p2 = EncGraph.nodeSet.get(t2);
                            EncVec ep1p2 = new EncVec(p2,p1);
                            int ri = ri();
                            Ciphertext re = getRe(ri);
                            //Element enumr = omega.add_G1r(toolsDS.Enum_P1P2_SD(p1, p2), re);
                            Ciphertext enumr = ckks.add(EncVecTools.ENCS_SD_SP(eds,ep1p2),re);
                            cb4 = ct.CT_CMP1(ri, enumr);
                            if (cb4 == 1) {
                                t1 = t2;
                            }
                        }
                    } else {
                        for (int i = 1; i < PsemiL.list.size(); i++) {
                            TokenNode t2 = PsemiL.list.get(i);
                            if (SecureOrienting(t1, Ib1, t2) == RIGHT) {
                                t1 = t2;
                            }
                        }
                    }
                    res = t1;
                }

            } else if (Side == RIGHT) {
                if (!PsemiL.list.isEmpty()) {
                    t1 = PsemiL.list.get(0);
                    for (TokenNode t2 : PsemiL.list) {
                        EncNode p2 = EncGraph.nodeSet.get(t2);
                        int ri = ri();
                        Ciphertext re = getRe(ri);
                        //Element encsr = omega.add_G1r(toolsSSB2VO.ENCS_SD_SP(new EncVec(b2, p2)), re);
                        Ciphertext encsr = ckks.add(EncVecTools.ENCS_SD_SP(evoSSB2,new EncVec(b2, p2)),re);
                        cb4 = ct.CT_CMP1(ri, encsr);
                        if (cb4 == 1) {
                            P_On_B2CS.list.add(t2);
                        }
                    }
                    if (!P_On_B2CS.list.isEmpty()) {
                        t1 = P_On_B2CS.list.get(0);
                        for (int i = 1; i < P_On_B2CS.list.size(); i++) {
                            TokenNode t2 = P_On_B2CS.list.get(i);
                            EncNode p1 = EncGraph.nodeSet.get(t1);
                            EncNode p2 = EncGraph.nodeSet.get(t2);
                            EncVec ep1p2 = new EncVec(p2,p1);
                            int ri = ri();
                            Ciphertext re = getRe(ri);
                            //Element enumr = omega.add_G1r(toolsDS.Enum_P1P2_SD(p1, p2), re);
                            Ciphertext enumr = ckks.add(EncVecTools.ENCS_SD_SP(eds,ep1p2),re);
                            cb4 = ct.CT_CMP1(ri, enumr);
                            if (cb4 == 1) {
                                t1 = t2;
                            }
                        }
                    } else {
                        for (TokenNode t2 : PsemiR.list) {
                            EncNode p = EncGraph.nodeSet.get(t2);
                            int ri = ri();
                            Ciphertext re = getRe(ri);
                            //Element encsr = omega.add_G1r(toolsDS.ENCS_SD_SP(new EncVec(b2, p)), re);
                            Ciphertext encsr = ckks.add(EncVecTools.ENCS_SD_SP(eds,new EncVec(b2, p)),re);
                            cb4 = ct.CT_CMP1(ri, encsr);
                            if (cb4 == 1) {
                                P_On_L2.list.add(t2);
                            }
                        }
                        if (!P_On_L2.list.isEmpty()) {
                            t1 = P_On_L2.list.get(0);
                            for (int i = 1; i < P_On_L2.list.size(); i++) {
                                TokenNode t2 = P_On_L2.list.get(i);
                                EncNode p1 = EncGraph.nodeSet.get(t1);
                                EncNode p2 = EncGraph.nodeSet.get(t2);
                                EncVec ep1p2 = new EncVec(p2,p1);
                                int ri = ri();
                                Ciphertext re = getRe(ri);
                                //Element enumr = omega.add_G1r(toolsOV.Enum_P1P2_SD(p1, p2), re);
                                Ciphertext enumr = ckks.add(EncVecTools.ENCS_SD_SP(eov,ep1p2),re);
                                cb4 = ct.CT_CMP1(ri, enumr);
                                if (cb4 == 0) {
                                    t1 = t2;
                                }
                            }
                        } else {
                            for (int i = 1; i < PsemiL.list.size(); i++) {
                                TokenNode t2 = PsemiL.list.get(i);
                                if (SecureOrienting(t1, Ib1, t2) == LEFT) {
                                    t1 = t2;
                                }
                            }
                        }
                    }
                    res = t1;
                } else if (!PsemiR.list.isEmpty()) {
                    t1 = PsemiR.list.get(0);
                    for (TokenNode t2 : PsemiR.list) {
                        EncNode p2 = EncGraph.nodeSet.get(t2);
                        int ri = ri();
                        Ciphertext re = getRe(ri);
                        //Element encsr = omega.add_G1r(toolsVO.ENCS_SD_SP(new EncVec(b2, p2)), re);
                        Ciphertext encsr = ckks.add(EncVecTools.ENCS_SD_SP(evo,new EncVec(b2, p2)),re);
                        cb4 = ct.CT_CMP1(ri, encsr);
                        if (cb4 == 1) {
                            P_On_SD.list.add(t2);
                        }
                    }
                    if (!P_On_SD.list.isEmpty()) {
                        t1 = P_On_SD.list.get(0);
                        for (int i = 1; i < P_On_SD.list.size(); i++) {
                            TokenNode t2 = P_On_SD.list.get(i);
                            EncNode p1 = EncGraph.nodeSet.get(t1);
                            EncNode p2 = EncGraph.nodeSet.get(t2);
                            EncVec ep1p2 = new EncVec(p2,p1);
                            int ri = ri();
                            Ciphertext re = getRe(ri);
                            //Element enumr = omega.add_G1r(toolsVO.Enum_P1P2_SD(p1, p2), re);
                            Ciphertext enumr = ckks.add(EncVecTools.ENCS_SD_SP(evo,ep1p2),re);
                            cb4 = ct.CT_CMP1(ri, enumr);
                            if (cb4 == 1) {
                                t1 = t2;
                            }
                        }
                    } else {
                        for (int i = 1; i < PsemiR.list.size(); i++) {
                            TokenNode t2 = PsemiR.list.get(i);
                            if (SecureOrienting(t1, Ib1, t2) == LEFT) {
                                t1 = t2;
                            }
                        }
                    }
                    res = t1;
                }
            } else {
                if (!PsemiR.list.isEmpty()) {
                    t1 = PsemiR.list.get(0);
                    for (TokenNode t2 : PsemiR.list) {
                        EncNode p = EncGraph.nodeSet.get(t2);
                        int ri = ri();
                        Ciphertext re = getRe(ri);
                        //Element encsr = omega.add_G1r(toolsSD.ENCS_SD_SP(new EncVec(s, p)), re);
                        Ciphertext encsr = ckks.add(EncVecTools.ENCS_SD_SP(esd,new EncVec(s, p)),re);
                        cb4 = ct.CT_CMP1(ri, encsr);
                        if (cb4 == 1) {
                            P_On_L2.list.add(t2);
                        }
                    }
                    if (!P_On_L2.list.isEmpty()) {
                        t1 = P_On_L2.list.get(0);
                        for (int i = 1; i < P_On_L2.list.size(); i++) {
                            TokenNode t2 = P_On_L2.list.get(i);
                            EncNode p1 = EncGraph.nodeSet.get(t1);
                            EncNode p2 = EncGraph.nodeSet.get(t2);
                            EncVec ep1p2 = new EncVec(p2,p1);
                            int ri = ri();
                            Ciphertext re = getRe(ri);
                            //Element enumr = omega.add_G1r(toolsOV.Enum_P1P2_SD(p1, p2), re);
                            Ciphertext enumr = ckks.add(EncVecTools.ENCS_SD_SP(eov,ep1p2),re);
                            cb4 = ct.CT_CMP1(ri, enumr);
                            if (cb4 == 1) {
                                t1 = t2;
                            }
                        }
                    } else {
                        for (int i = 1; i < PsemiR.list.size(); i++) {
                            TokenNode t2 = PsemiR.list.get(i);
                            if (SecureOrienting(t1, Ib1, t2) == LEFT) {
                                t1 = t2;
                            }
                        }
                    }
                    res = t1;
                } else if (!PsemiL.list.isEmpty()) {
                    t1 = PsemiL.list.get(0);
                    for (TokenNode t2 : PsemiL.list) {
                        EncNode p2 = EncGraph.nodeSet.get(t2);
                        int ri = ri();
                        Ciphertext re = getRe(ri);
                        //Element encsr = omega.add_G1r(toolsSSB2VO.ENCS_SD_SP(new EncVec(b2, p2)), re);
                        Ciphertext encsr = ckks.add(EncVecTools.ENCS_SD_SP(evoSSB2,new EncVec(b2, p2)),re);
                        cb4 = ct.CT_CMP1(ri, encsr);
                        if (cb4 == 1) {
                            P_On_B2CS.list.add(t2);
                        }
                    }
                    if (!P_On_B2CS.list.isEmpty()) {
                        t1 = P_On_B2CS.list.get(0);
                        for (int i = 1; i < P_On_B2CS.list.size(); i++) {
                            TokenNode t2 = P_On_B2CS.list.get(i);
                            EncNode p1 = EncGraph.nodeSet.get(t1);
                            EncNode p2 = EncGraph.nodeSet.get(t2);
                            EncVec ep1p2 = new EncVec(p2,p1);
                            int ri = ri();
                            Ciphertext re = getRe(ri);
                            //Element enumr = omega.add_G1r(toolsDS.Enum_P1P2_SD(p1, p2), re);
                            Ciphertext enumr = ckks.add(EncVecTools.ENCS_SD_SP(eds,ep1p2),re);
                            cb4 = ct.CT_CMP1(ri, enumr);
                            if (cb4 == 1) {
                                t1 = t2;
                            }
                        }
                    } else {
                        for (int i = 1; i < PsemiL.list.size(); i++) {
                            TokenNode t2 = PsemiL.list.get(i);
                            if (SecureOrienting(t1, Ib1, t2) == LEFT) {
                                t1 = t2;
                            }
                        }
                    }
                    res = t1;
                }
            }
        }
        return res == null ? Ib2 : res;
    }

    /**
     * Secure vertically nearest hop token node.
     *
     * @param Is the is
     * @param Id the id
     * @param P  the p
     * @return the token node
     * @throws NoSuchAlgorithmException the no such algorithm exception
     */

    public static TokenNode SecureVerticallyNearestHop(TokenNode Is, TokenNode Id, StopSet P) throws
            NoSuchAlgorithmException {

        System.out.println("It`s SVNH");
        if (P.list.isEmpty()) return Id;//直接返回终点
        if (P.list.size() == 1) return P.list.iterator().next();


        EncNode es = EncGraph.nodeSet.get(Is);
//        System.out.println("omega.Dec(es.getEx(),pk,ct.getSk()) = " + omega.Dec(es.getEx(), pk, ct.getSk()));
//        System.out.println("omega.Dec(es.getEy(),pk,ct.getSk()) = " + omega.Dec(es.getEy(), pk, ct.getSk()));
        EncNode ed = EncGraph.nodeSet.get(Id);
        EncVec esd = new EncVec(es, ed);
        EncVec eov = EncVecTools.getOV(es, ed);
        EncVec evo = EncVecTools.getVO(es, ed);
//        EncVecPreProcessingTools tools = new EncVecPreProcessingTools(esd, pk);
//        EncVecPreProcessingTools toolsOV = new EncVecPreProcessingTools(eov, pk);
//        EncVecPreProcessingTools toolsVO = new EncVecPreProcessingTools(evo, pk);

        TokenNode p1 = P.list.get(0);
        EncNode ep1 = EncGraph.nodeSet.get(p1);
        for (int i = 1; i < P.list.size(); i++) {
            int ri = ri();
            Ciphertext re = getRe(ri);
            TokenNode p2 = P.list.get(i);

            EncNode ep2 = EncGraph.nodeSet.get(p2);
            EncVec ep2p1 = new EncVec(ep2,ep1);
            //Element Enumr = omega.add_G1r(tools.Enum_P1P2_SD(ep1, ep2), re);
            Ciphertext Enumr = ckks.add(EncVecTools.ENCS_SD_SP(esd,ep2p1),re);
            int cb5 = ct.CT_CMP1(ri, Enumr);
            if (cb5 == 0) {
                p1 = p2;
                ep1 = EncGraph.nodeSet.get(p1);
            }
        }
        ArrayList<TokenNode> LL = new ArrayList<>(), LR = new ArrayList<>(), Temp = new ArrayList<>();
        if (SecureOrienting(Is, Id, p1) == LEFT) {
            LL.add(p1);
        } else {
            LR.add(p1);
        }
        Temp.addAll(P.list);
        Temp.remove(p1);
        for (int i = 0; i < Temp.size(); i++) {
            int ri = ri();
            Ciphertext re = getRe(ri);
            TokenNode p2 = Temp.get(i);
            EncNode ep2 = EncGraph.nodeSet.get(p2);
            EncVec ep1pi = new EncVec(ep1, ep2);
            //Element NCSr = omega.add_G1r(tools.ENCS_SD_SP(ep1pi), re);
            Ciphertext NCSr = ckks.add(EncVecTools.ENCS_SD_SP(esd,ep1pi),re);
            int cb1 = ct.CT_CMP1(ri, NCSr);
            if (cb1 == 1) {
                if (SecureOrienting(Is, Id, p2) == LEFT) {
                    LL.add(p2);
                } else {
                    LR.add(p2);
                }
            }
        }
        if (!LR.isEmpty()) {
            p1 = LR.get(0);
            for (int i = 1; i < LR.size(); i++) {
                int ri = ri();
                Ciphertext re = getRe(ri);
                TokenNode p2 = LR.get(i);
                EncNode ep2 = EncGraph.nodeSet.get(p2);
                EncVec ep1pi = new EncVec(ep2, ep1);
                //Element Enumr = omega.add_G1r(toolsOV.Enum_P1P2_SD(ep1, ep2), re);
                Ciphertext Enumr = ckks.add(EncVecTools.ENCS_SD_SP(eov,ep1pi),re);
                int cb4 = ct.CT_CMP1(ri, Enumr);
                if (cb4 == 0) {
                    p1 = p2;
                    ep1 = EncGraph.nodeSet.get(p1);
                }
            }
        } else {
            p1 = LL.get(0);
            for (int i = 1; i < LL.size(); i++) {
                int ri = ri();
                Ciphertext re = getRe(ri);
                TokenNode p2 = LL.get(i);
                EncNode ep2 = EncGraph.nodeSet.get(p2);
                EncVec ep1pi = new EncVec(ep2, ep1);
                //Element Enumr = omega.add_G1r(toolsVO.Enum_P1P2_SD(ep1, ep2), re);
                Ciphertext Enumr =ckks.add(EncVecTools.ENCS_SD_SP(evo,ep1pi),re);
                int cb4 = ct.CT_CMP1(ri, Enumr);
                if (cb4 == 0) {
                    p1 = p2;
                    ep1 = EncGraph.nodeSet.get(p1);
                }
            }
        }
        return p1;
    }

    /**
     * Secure bridging token node [ ].
     *
     * @param Is    the is
     * @param Id    the id
     * @param Pmid  the pmid
     * @param Phigh the phigh
     * @return the token node [ ]
     */
//A算法：贪心最近法
    //Orient-Split-sCan-Hop (OSCH)
    //Orient-Split-Pull-Hop (OSPH)
    //
    @SneakyThrows

    public static TokenNode[] SecureBridging(TokenNode Is, TokenNode Id, StopSet Pmid, StopSet Phigh) {
        System.out.println("It`s SB");
        TokenNode Ib1;
        int L = 0, R = 0;
        for (TokenNode node : Phigh.list) {
            if (SecureOrienting(Is, Id, node) == RIGHT) {
                R++;
                //System.out.println(node+"该节点在    right");
            }
            else {//System.out.println(node+"该节点在    left");
                L++;}
        }
        if (Pmid.list.isEmpty()) {
            if (Phigh.list.isEmpty()) {
                Ib1 = Id;
            } else if (L != 0 && R != 0) {
                Ib1 = Id;
            } else {
                Ib1 = Phigh.list.get(0);
            }
        } else {

            Ib1 = SecureVerticallyNearestHop(Is, Id, Pmid);
        }
        return new TokenNode[]{Ib1, Id};
    }

    @SneakyThrows
    public static TokenNode getAlwaysToNearestPoint(TokenNode Is, TokenNode Id, ArrayList<TokenNode> list) {
        if (list.isEmpty()) return Id;
        if (list.size() == 1) return list.get(0);
        TokenNode t1 = list.get(0);
        int cb5;

        EncNode Ps = EncGraph.nodeSet.get(Is);
        EncNode P1 = EncGraph.nodeSet.get(t1);
        EncVec esp1 = new EncVec(Ps, P1);
        //
        Ciphertext ex = esp1.getEvec()[0];
        Ciphertext ey = esp1.getEvec()[1];
//        Element ex2 = pk.EncMul(ex, ex).getImmutable();
//        Element ey2 = pk.EncMul(ey, ey).getImmutable();
        Ciphertext ex2 = ckks.multiply(ex,ex);
        Ciphertext ey2 = ckks.multiply(ey,ey);
        for (int i = 1; i < list.size(); i++) {
            TokenNode t2 = list.get(i);
            EncNode P2 = EncGraph.nodeSet.get(t2);
            EncVec esp2 = new EncVec(Ps, P2);
            Ciphertext exx = esp2.getEvec()[0];
            Ciphertext eyy = esp2.getEvec()[1];
//            Element exx2 = pk.EncMul(exx, exx).duplicate();
//            Element eyy2 = pk.EncMul(eyy, eyy).duplicate();
            Ciphertext exx2 = ckks.multiply(exx,exx);
            Ciphertext eyy2 = ckks.multiply(eyy,eyy);
            int ri = ri();
            Ciphertext re = getRe(ri);
            //Element Delta = omega.sub_G1(omega.add_G1r(ex2, ey2), omega.add_G1r(exx2, eyy2));
            Ciphertext Delta = ckks.subtract(ckks.add(ex2,ey2),ckks.add(exx2,eyy2));
            //Element Deltar = omega.add_G1r(Delta, re).getImmutable();
            Ciphertext Deltar = ckks.add(Delta,re);
            cb5 = ct.CT_CMP1(ri, Deltar);
            if (cb5 == 0) {
                t1 = t2;
                ex2 = exx2;
                ey2 = eyy2;
            }
        }
        return t1;
    }
}
