package Algorithm;

import Class.TokenNode;
import Class.node;
import Class.PartialOrder;
import util.JsonUtil;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static util.JsonUtil.WriteMapInJson;

/**
 * 改进版 Floyd-Warshall（专注阻塞边处理，移除偏序预处理）
 * 新增：保存原始距离矩阵用于最短路径基准计算
 * 专注：Floyd_Warshall_2的三层阻塞边处理策略
 */
public class Floyd_Warshall_1 {
    private final double[][] graph1; // 处理后距离矩阵（含阻塞）
    private final double[][] originalGraph1; // 原始距离矩阵（无阻塞）
    private final int LEN;
    private final ConcurrentHashMap<Integer, node> apl;
    private final ConcurrentHashMap<Long, Integer> Id2Index;
    private final ArrayList<ArrayList<String>> pathlist;
    private final ArrayList<ArrayList<String>> originalPathlist; // 原始路径列表
    private final int[][] graph;
    private final Set<String> blockedEdgeSet;
    private int[][] deviation;
    private final int min;
    private List<PartialOrder> partialOrders; // 保留结构，但不在预处理中使用
    private final ConcurrentHashMap<Long, PlainNode> idToPlainNode;
    private final ConcurrentMap<String, String> pathCache;
    private final List<List<Integer>> adjacencyList;
    private static final double DIST_THRESHOLD = 5000.0;
    private double blockageRatio =0.05; // 默认5%

    // 策略类型枚举
    public enum StrategyType {
        WAIT_INSPIRED("基于1W理念"),
        DELAY_INSPIRED("基于2D理念"),
        REORDER("重新排序"),
        AVOIDANCE("避开策略");

        private final String description;

        StrategyType(String description) {
            this.description = description;
        }

        public String getDescription() {
            return description;
        }
    }

    // 方向枚举
    public enum Direction {
        CLOCKWISE,
        ANTICLOCKWISE
    }

    // 路径候选类（来自Floyd_Warshall_2）
    private static class PathCandidate {
        private final int firstHop;
        private final double distance;
        private final String fullPath;

        public PathCandidate(int firstHop, double distance, String fullPath) {
            this.firstHop = firstHop;
            this.distance = distance;
            this.fullPath = fullPath;
        }

        public int getFirstHop() {
            return firstHop;
        }

        public double getDistance() {
            return distance;
        }

        public String getPath() {
            return fullPath;
        }

        public boolean isValid() {
            return distance < 20000000.0;
        }
    }

    // 偏序违反信息容器（保留结构供导航阶段使用）
    public static class PartialOrderViolation {
        private final PartialOrder partialOrder;
        private final String path;
        private final int start;
        private final int end;
        private final List<Integer> pathNodes;

        public PartialOrderViolation(PartialOrder po, String path, int start, int end, List<Integer> pathNodes) {
            this.partialOrder = po;
            this.path = path;
            this.start = start;
            this.end = end;
            this.pathNodes = pathNodes;
        }

        public PartialOrder getPartialOrder() {
            return partialOrder;
        }

        public String getPath() {
            return path;
        }

        public int getStart() {
            return start;
        }

        public int getEnd() {
            return end;
        }

        public List<Integer> getPathNodes() {
            return pathNodes;
        }

        public TokenNode getPSt() {
            return partialOrder.getPSt();
        }

        public TokenNode getSSt() {
            return partialOrder.getSSt();
        }
    }

    // 明文节点类
    public static class PlainNode {
        public long id;
        public double x;
        public double y;

        public PlainNode(long id, double x, double y) {
            this.id = id;
            this.x = x;
            this.y = y;
        }

        public static PlainNode fromNode(node nd) {
            return new PlainNode(nd.id, nd.x, nd.y);
        }
    }

    // 路径信息容器类
    public static class PathInfo {
        private final String path;
        private final double distance;
        private final boolean isAvailable;
        private final boolean violatesPartialOrder;
        private final boolean isBlocked;

        public PathInfo(String path, double distance, boolean isAvailable, boolean violatesPartialOrder,
                boolean isBlocked) {
            this.path = path;
            this.distance = distance;
            this.isAvailable = isAvailable;
            this.violatesPartialOrder = violatesPartialOrder;
            this.isBlocked = isBlocked;
        }

        // Getters
        public String getPath() {
            return path;
        }

        public double getDistance() {
            return distance;
        }

        public boolean isAvailable() {
            return isAvailable;
        }

        public boolean violatesPartialOrder() {
            return violatesPartialOrder;
        }

        public boolean isBlocked() {
            return isBlocked;
        }

        @Override
        public String toString() {
            return String.format("PathInfo{path='%s', distance=%.2f, available=%s, violatesPO=%s, blocked=%s}",
                    path, distance, isAvailable, violatesPartialOrder, isBlocked);
        }
    }

    /* 构造方法 */
    public Floyd_Warshall_1(ConcurrentHashMap<Integer, node> apl,
            ConcurrentHashMap<Long, Integer> i2i, double blockageRatio) {
        this.apl = apl;
        this.LEN = apl.size();
        this.graph1 = new double[LEN][LEN];
        this.originalGraph1 = new double[LEN][LEN]; // 初始化原始矩阵
        this.pathlist = new ArrayList<>();
        this.originalPathlist = new ArrayList<>(); // 初始化原始路径列表
        this.Id2Index = i2i;
        this.min = getMinimumIndex(apl);
        this.partialOrders = new ArrayList<>(); // 保留空列表供导航阶段使用
        this.idToPlainNode = new ConcurrentHashMap<>();
        this.blockedEdgeSet = ConcurrentHashMap.newKeySet();
        this.pathCache = new ConcurrentHashMap<>();
        this.adjacencyList = new ArrayList<>(LEN);
        this.graph = new int[LEN][LEN];
        this.blockageRatio = blockageRatio; // 🔥 设置阻塞比例

        for (int i = 0; i < LEN; i++) {
            adjacencyList.add(new ArrayList<>());
        }
        initializePlainNodeMapping();
        prebuildAdjacencyList();
    }

    public Floyd_Warshall_1(ConcurrentHashMap<Integer, node> apl,
            ConcurrentHashMap<Long, Integer> i2i) {
        this(apl, i2i, 0.05); // 调用新构造方法，使用默认5%阻塞
    }

    /* 初始化方法 */
    private void initializePlainNodeMapping() {
        for (Map.Entry<Integer, node> entry : apl.entrySet()) {
            node nd = entry.getValue();
            PlainNode plainNode = PlainNode.fromNode(nd);
            idToPlainNode.put(nd.id, plainNode);
        }
        System.out.println("初始化了 " + idToPlainNode.size() + " 个节点的PlainNode映射");
    }

    private void prebuildAdjacencyList() {
        for (Map.Entry<Integer, node> entry : apl.entrySet()) {
            node nd = entry.getValue();
            int from = nd.index;
            if (from < 0 || from >= LEN)
                continue;
            for (int to : nd.Neb) {
                if (to >= 0 && to < LEN) {
                    adjacencyList.get(from).add(to);
                }
            }
        }
        System.out.println("邻接表预构建完成");
    }

    private int getMinimumIndex(ConcurrentHashMap<Integer, node> apl) {
        int minIndex = Integer.MAX_VALUE;
        for (Integer idx : apl.keySet()) {
            if (idx < minIndex)
                minIndex = idx;
        }
        return minIndex == Integer.MAX_VALUE ? -1 : minIndex;
    }

    /* 阻塞边相关方法 */
    public boolean isBlocked(int i, int j) {
        if (i == j)
            return false;
        String key1 = i + "," + j;
        String key2 = j + "," + i;
        return blockedEdgeSet.contains(key1) || blockedEdgeSet.contains(key2);
    }

    public boolean isDirectlyConnected(int from, int to) {
        if (from == to)
            return true;
        return adjacencyList.get(from).contains(to) && !isBlocked(from, to);
    }

    /* ====================== Floyd_Warshall_2的阻塞边处理策略 ====================== */

    /**
     * 增强版DSt搜索：三层策略（来自Floyd_Warshall_2）
     */
    private int findEnhancedDSt(int i, int j, Set<Integer> usedNodes, List<Integer> pathHistory) {
        System.out.println("增强DSt搜索: " + i + "->" + j);

        // 第一层：直接DSt搜索
        System.out.println("  第一层: 直接DSt搜索");
        int directDSt = findDStBySK(i, j, usedNodes);
        if (directDSt != -1) {
            System.out.println("  ✅ 第一层成功: 直接DSt " + directDSt);
            return directDSt;
        }

        // 第二层：邻居最短路径查询（快速成功）
        System.out.println("  第二层: 邻居路径查询");
        List<PathCandidate> neighborCandidates = findPathViaNeighborsEnhanced(i, j, usedNodes);

        // 第二层采用快速成功策略，只要找到一个就立即返回
        if (!neighborCandidates.isEmpty()) {
            PathCandidate candidate = neighborCandidates.get(0); // 取第一个成功的
            System.out.println("  ✅ 第二层成功: 通过邻居 " + candidate.getFirstHop() +
                    " 找到路径，距离: " + candidate.getDistance());
            return candidate.getFirstHop();
        }

        // 第三层：真正回溯到路径历史中的前一个节点
        if (pathHistory != null && pathHistory.size() >= 2) {
            int previousNode = pathHistory.get(pathHistory.size() - 2); // 获取前一个节点
            System.out.println("  第三层: 回溯到前驱节点: " + previousNode);

            Set<Integer> newUsed = new HashSet<>(usedNodes);
            newUsed.add(i);

            // 从前一个节点重新找路径到j，但要排除当前路径上的节点
            return findDStFromAlternativeStart(previousNode, j, newUsed, pathHistory);
        }

        System.out.println("  ❌ 所有策略均失败");
        return -1;
    }

    /**
     * 增强版第二层：邻居路径查询（快速成功策略）
     */
    private List<PathCandidate> findPathViaNeighborsEnhanced(int i, int j, Set<Integer> usedNodes) {
        List<PathCandidate> candidates = new ArrayList<>();

        // 深度1：直接邻居 - 找到第一个可用的就返回
        System.out.println("  第二层深度1: 检查直接邻居");
        List<Integer> depth1Neighbors = adjacencyList.get(i).stream()
                .filter(neighbor -> !usedNodes.contains(neighbor) && !isBlocked(i, neighbor))
                .collect(Collectors.toList());

        for (int neighbor : depth1Neighbors) {
            // 检查 neighbor → j 的路径
            if (graph1[neighbor][j] < 20000000.0) {
                String pathToJ = pathlist.get(neighbor).get(j);
                if (!pathToJ.isEmpty() && !pathToJ.equals("原地踏步") && !containsBlockedEdge(neighbor, j, pathToJ)) {
                    PathCandidate candidate = new PathCandidate(
                            neighbor,
                            graph1[i][neighbor] + graph1[neighbor][j],
                            buildFullPath(i, neighbor, pathToJ, j));
                    candidates.add(candidate);
                    System.out.println("    ✅ 深度1成功: " + neighbor + "->" + j);
                    // 找到第一个可用的就返回，不继续搜索
                    return candidates;
                }
            }
        }

        // 深度1全部失败，才尝试深度2：邻居的邻居
        System.out.println("  第二层深度2: 检查邻居的邻居");
        for (int neighbor : depth1Neighbors) {
            Set<Integer> newUsed = new HashSet<>(usedNodes);
            newUsed.add(neighbor);

            // 获取邻居的邻居（深度2）
            List<Integer> depth2Neighbors = adjacencyList.get(neighbor).stream()
                    .filter(nn -> !newUsed.contains(nn) && !isBlocked(neighbor, nn))
                    .collect(Collectors.toList());

            for (int depth2Neighbor : depth2Neighbors) {
                if (graph1[depth2Neighbor][j] < 20000000.0) {
                    String pathToJ = pathlist.get(depth2Neighbor).get(j);
                    if (!pathToJ.isEmpty() && !pathToJ.equals("原地踏步")
                            && !containsBlockedEdge(depth2Neighbor, j, pathToJ)) {
                        // 构建 i → neighbor → depth2Neighbor → j 的路径
                        double totalDistance = graph1[i][neighbor] +
                                graph1[neighbor][depth2Neighbor] +
                                graph1[depth2Neighbor][j];

                        String fullPath = i + "->" + neighbor + "->" + depth2Neighbor;
                        if (!pathToJ.isEmpty()) {
                            fullPath += "->" + pathToJ;
                        }

                        PathCandidate candidate = new PathCandidate(
                                neighbor, totalDistance, fullPath);
                        candidates.add(candidate);
                        System.out.println("    ✅ 深度2成功: " + neighbor + "->" + depth2Neighbor + "->" + j);
                        // 找到第一个可用的深度2路径就返回
                        return candidates;
                    }
                }
            }
        }

        System.out.println("  第二层: 深度1和深度2均无可用路径");
        return candidates; // 返回空列表
    }

    /**
     * 构建完整路径：i -> neighbor -> ... -> j
     */
    private String buildFullPath(int i, int neighbor, String pathToJ, int j) {
        if (pathToJ.isEmpty() || pathToJ.equals("原地踏步")) {
            return i + "->" + neighbor + "->" + j;
        } else {
            return i + "->" + neighbor + "->" + pathToJ;
        }
    }

    /**
     * 从替代起点查找路径（真正意义上的回溯）
     */
    private int findDStFromAlternativeStart(int alternativeStart, int j, Set<Integer> usedNodes,
            List<Integer> pathHistory) {
        System.out.println("  从替代起点 " + alternativeStart + " 寻找到 " + j + " 的路径");

        // 获取alternativeStart的所有邻居（排除历史路径中的节点）
        List<Integer> alternativeNeighbors = adjacencyList.get(alternativeStart).stream()
                .filter(neighbor -> !pathHistory.contains(neighbor) && !usedNodes.contains(neighbor))
                .collect(Collectors.toList());

        // 查找通过邻居的路径
        List<PathCandidate> candidates = new ArrayList<>();
        for (int neighbor : alternativeNeighbors) {
            if (graph1[neighbor][j] < 20000000.0) {
                String pathToJ = pathlist.get(neighbor).get(j);
                if (!pathToJ.isEmpty() && !pathToJ.equals("原地踏步") && !containsBlockedEdge(neighbor, j, pathToJ)) {
                    PathCandidate candidate = new PathCandidate(
                            neighbor,
                            graph1[alternativeStart][neighbor] + graph1[neighbor][j],
                            buildFullPath(alternativeStart, neighbor, pathToJ, j));
                    candidates.add(candidate);
                }
            }
        }

        // 返回最优候选
        if (!candidates.isEmpty()) {
            candidates.sort(Comparator.comparingDouble(PathCandidate::getDistance));
            System.out.println("  回溯成功: 通过 " + alternativeStart + "->" + candidates.get(0).getFirstHop());
            return candidates.get(0).getFirstHop();
        }

        return -1;
    }

    /**
     * 为阻塞边处理构建有意义的路径历史
     */
    private List<Integer> buildMeaningfulPathHistory(int i, int j) {
        List<Integer> pathHistory = new ArrayList<>();

        // 方案1：使用i到j的原始最短路径作为历史
        String originalPath = originalPathlist.get(i).get(j);
        if (!originalPath.isEmpty() && !originalPath.equals("原地踏步")) {
            // 解析原始路径
            String[] nodes = originalPath.split("->");
            for (String nodeStr : nodes) {
                try {
                    pathHistory.add(Integer.parseInt(nodeStr.trim()));
                } catch (NumberFormatException e) {
                    // 忽略解析错误
                }
            }
        }

        // 方案2：如果原始路径不可用，使用i的前驱节点
        if (pathHistory.size() < 2) {
            // 寻找i的前驱节点（通过反向BFS）
            int predecessor = findPredecessor(i, j);
            if (predecessor != -1) {
                pathHistory.add(predecessor);
                pathHistory.add(i);
            } else {
                // 最后备选：只包含当前节点
                pathHistory.add(i);
            }
        }

        System.out.println("  构建路径历史: " + pathHistory);
        return pathHistory;
    }

    /**
     * 寻找节点i在到j路径上的前驱节点
     */
    private int findPredecessor(int i, int j) {
        // 简单实现：通过BFS寻找i的前驱
        boolean[] visited = new boolean[LEN];
        int[] prev = new int[LEN];
        Arrays.fill(prev, -1);

        Queue<Integer> queue = new LinkedList<>();
        queue.offer(j);
        visited[j] = true;

        while (!queue.isEmpty()) {
            int current = queue.poll();

            for (int neighbor : adjacencyList.get(current)) {
                if (!visited[neighbor] && !isBlocked(current, neighbor)) {
                    visited[neighbor] = true;
                    prev[neighbor] = current;
                    queue.offer(neighbor);

                    if (neighbor == i) {
                        // 找到i，返回它的前驱
                        return prev[i];
                    }
                }
            }
        }

        return -1;
    }

    /**
     * 处理阻塞边（增强版）- 替换原来的空方法
     */
    private void processBlockedEdgeEnhanced(int i, int j, List<Integer> pathHistory) {
        System.out.println("处理阻塞边 " + i + "->" + j + " (增强版)");

        // 确保有意义的路径历史
        if (pathHistory == null || pathHistory.size() < 2) {
            pathHistory = buildMeaningfulPathHistory(i, j);
        }

        Set<Integer> usedNodes = Collections.synchronizedSet(new HashSet<>());
        int dSt = findEnhancedDSt(i, j, usedNodes, pathHistory);

        if (dSt != -1) {
            // 构建绕行路径
            buildDetourPath(i, j, dSt);
            deviation[i][j] = dSt;
            System.out.println("  ✅ 成功找到绕行路径 via " + dSt);
        } else {
            System.out.println("  ❌ 所有策略均失败，标记为完全阻塞");
            deviation[i][j] = -2; // 特殊标记：完全阻塞
        }
    }

    /**
     * 构建绕行路径
     */
    private void buildDetourPath(int i, int j, int dSt) {
        synchronized (graph1) {
            graph1[i][j] = graph1[i][dSt] + graph1[dSt][j];
            graph1[j][i] = graph1[i][j];

            String pathItoDSt = pathlist.get(i).get(dSt);
            String pathDStToJ = pathlist.get(dSt).get(j);
            StringBuilder detourPath = new StringBuilder();

            if (!pathItoDSt.isEmpty() && !pathItoDSt.equals("原地踏步")) {
                detourPath.append(pathItoDSt).append("->");
            }
            detourPath.append(dSt);
            if (!pathDStToJ.isEmpty() && !pathDStToJ.equals("原地踏步")) {
                detourPath.append("->").append(pathDStToJ);
            }

            pathlist.get(i).set(j, detourPath.toString());
            pathlist.get(j).set(i, reversePath(detourPath.toString()));
        }
    }

    /**
     * 通过SecureSkimming找DSt
     */
    private int findDStBySK(int i, int j, Set<Integer> usedNodes) {
        System.out.println("为阻塞边 " + i + "->" + j + " 寻找DSt");

        if (usedNodes.contains(i) || usedNodes.contains(j)) {
            return -1;
        }

        // 直接调用无加密版本的SecureSkimming
        int dSt = findDStBySecureSkimming(i, j, usedNodes);

        if (dSt != -1) {
            System.out.println("  SecureSkimming选择的最优DSt: " + dSt);

            // 验证连通性
            if (isDirectlyConnected(i, dSt) && isDirectlyConnected(dSt, j)) {
                System.out.println("  DSt " + dSt + " 连通性验证通过");
                return dSt;
            } else {
                System.out.println("  DSt " + dSt + " 连通性验证失败");
            }
        }

        System.out.println("无法找到有效DSt");
        return -1;
    }

    /**
     * SecureSkimming 算法（来自Floyd_Warshall_2）
     */
    private int findDStBySecureSkimming(int startIdx, int endIdx, Set<Integer> usedNodes) {
        System.out.println("为阻塞边 " + startIdx + "->" + endIdx + " 寻找DSt（无加密SecureSkimming）");

        node startNode = apl.get(startIdx);
        node endNode = apl.get(endIdx);
        if (startNode == null || endNode == null) {
            return -1;
        }

        // 1. 收集候选节点（基于邻接表和距离阈值）
        List<Integer> candidates = new ArrayList<>();
        for (int candidateIdx : adjacencyList.get(startIdx)) {
            if (candidateIdx == startIdx || candidateIdx == endIdx ||
                    usedNodes.contains(candidateIdx) || isBlocked(startIdx, candidateIdx)) {
                continue;
            }

            // 距离阈值筛选
            if (graph1[startIdx][candidateIdx] < DIST_THRESHOLD &&
                    isDirectlyConnected(candidateIdx, endIdx) &&
                    graph1[candidateIdx][endIdx] < DIST_THRESHOLD) {
                candidates.add(candidateIdx);
            }
        }

        if (candidates.isEmpty()) {
            return -1;
        }

        System.out.println("  候选DSt数量: " + candidates.size());

        // 2. 调用无加密SecureSkimming核心算法
        return secureSkimmingNoEncryption(startIdx, endIdx, candidates, usedNodes);
    }

    /**
     * SecureSkimming核心实现（来自Floyd_Warshall_2）
     */
    private int secureSkimmingNoEncryption(int startIdx, int endIdx, List<Integer> candidates, Set<Integer> usedNodes) {
        if (candidates.size() == 1) {
            int result = candidates.get(0);
            System.out.println("  只有一个候选节点，直接返回: " + result);
            return result;
        }

        node startNode = apl.get(startIdx);
        node endNode = apl.get(endIdx);

        // 步骤1: 寻找在垂直线上的节点
        List<Integer> onPerpendicularLine = findStopsOnPerpendicularLine(startNode, endNode, candidates);

        int selectedNode;
        if (!onPerpendicularLine.isEmpty()) {
            // 线上有节点，选择最近的
            System.out.println("  找到 " + onPerpendicularLine.size() + " 个在线上的候选节点");
            selectedNode = findNearestOnLine(startNode, onPerpendicularLine);
        } else {
            // 线上无节点，按方向选择极端节点
            System.out.println("  无在线上的候选节点，按方向选择");
            selectedNode = findExtremeStopByDirection(startNode, candidates, Direction.CLOCKWISE);
        }

        // 检查多重空间约束（简化版，不涉及偏序）
        return checkMultipleSpatialRestrictions(startIdx, selectedNode, candidates, usedNodes);
    }

    /**
     * 找到在垂直于起点-终点连线的直线上的节点
     */
    private List<Integer> findStopsOnPerpendicularLine(node start, node end, List<Integer> candidates) {
        List<Integer> onLine = new ArrayList<>();

        if (candidates.isEmpty())
            return onLine;

        // 计算起点-终点向量
        double dx = end.x - start.x;
        double dy = end.y - start.y;

        // 如果起点终点重合，返回空
        if (dx == 0 && dy == 0)
            return onLine;

        // 计算垂直向量
        double perpX = -dy;
        double perpY = dx;

        // 归一化垂直向量
        double length = Math.sqrt(perpX * perpX + perpY * perpY);
        if (length == 0)
            return onLine;

        double unitPerpX = perpX / length;
        double unitPerpY = perpY / length;

        // 检查每个候选节点是否在垂直线上（在一定容差范围内）
        for (int candidateIdx : candidates) {
            node candidate = apl.get(candidateIdx);
            if (candidate == null)
                continue;

            // 计算候选节点到起点的向量
            double vecX = candidate.x - start.x;
            double vecY = candidate.y - start.y;

            // 计算到垂直线的距离（使用向量叉积的绝对值）
            double distanceToLine = Math.abs(vecX * unitPerpY - vecY * unitPerpX);

            // 计算在垂直线方向上的投影（判断在哪一侧）
            double projection = vecX * unitPerpX + vecY * unitPerpY;

            // 如果在垂直线上（容差10.0米）且在正确的一侧（投影为正）
            if (distanceToLine < 10.0 && projection > 0) {
                onLine.add(candidateIdx);
                System.out.println("    节点 " + candidateIdx + " 在垂直线上，距离: " + distanceToLine + ", 投影: " + projection);
            }
        }

        return onLine;
    }

    /**
     * 找到线上最近的节点
     */
    private int findNearestOnLine(node start, List<Integer> onLineCandidates) {
        if (onLineCandidates.isEmpty())
            return -1;

        int nearest = onLineCandidates.get(0);
        double minDistance = calculateDistance(start, apl.get(nearest));

        for (int i = 1; i < onLineCandidates.size(); i++) {
            int candidateIdx = onLineCandidates.get(i);
            node candidate = apl.get(candidateIdx);
            double distance = calculateDistance(start, candidate);

            if (distance < minDistance) {
                minDistance = distance;
                nearest = candidateIdx;
            }
        }

        System.out.println("  选择线上最近节点: " + nearest + ", 距离: " + minDistance + "m");
        return nearest;
    }

    /**
     * 按方向选择极端节点
     */
    private int findExtremeStopByDirection(node start, List<Integer> candidates, Direction direction) {
        if (candidates.isEmpty())
            return -1;

        int extremeNode = candidates.get(0);
        node extreme = apl.get(extremeNode);
        double extremeAngle = calculateAngle(start, extreme);

        for (int i = 1; i < candidates.size(); i++) {
            int candidateIdx = candidates.get(i);
            node candidate = apl.get(candidateIdx);
            double candidateAngle = calculateAngle(start, candidate);

            if (direction == Direction.CLOCKWISE) {
                // 顺时针方向，选择角度最小的节点（最右侧）
                if (candidateAngle < extremeAngle) {
                    extremeNode = candidateIdx;
                    extreme = candidate;
                    extremeAngle = candidateAngle;
                }
            } else {
                // 逆时针方向，选择角度最大的节点（最左侧）
                if (candidateAngle > extremeAngle) {
                    extremeNode = candidateIdx;
                    extreme = candidate;
                    extremeAngle = candidateAngle;
                }
            }
        }

        System.out.println("  按方向选择极端节点: " + extremeNode + ", 角度: " + extremeAngle);
        return extremeNode;
    }

    /**
     * 检查多重空间约束（简化版，不涉及偏序）
     */
    private int checkMultipleSpatialRestrictions(int startIdx, int candidateIdx, List<Integer> allCandidates,
            Set<Integer> usedNodes) {
        // 简化版：直接返回候选节点，不进行偏序检查
        System.out.println("  空间约束检查（简化版）：直接返回候选节点 " + candidateIdx);
        return candidateIdx;
    }

    /**
     * 计算两点间角度（相对于正东方向）
     */
    private double calculateAngle(node from, node to) {
        double dx = to.x - from.x;
        double dy = to.y - from.y;
        return Math.atan2(dy, dx); // 返回弧度值
    }

    /**
     * 计算两点间距离
     */
    private double calculateDistance(node node1, node node2) {
        double dx = node1.x - node2.x;
        double dy = node1.y - node2.y;
        return Math.sqrt(dx * dx + dy * dy);
    }

    /**
     * 检查节点是否已访问
     */
    private boolean isNodeVisited(int nodeIdx, Set<Integer> usedNodes) {
        return usedNodes.contains(nodeIdx);
    }

    /**
     * 检查路径是否包含阻塞边
     */
    private boolean containsBlockedEdge(int start, int end, String path) {
        if (path.isEmpty() || path.equals("原地踏步")) {
            return false;
        }

        List<Integer> nodeList = new ArrayList<>();
        nodeList.add(start);
        String[] nodes = path.split("->");
        for (String nodeStr : nodes) {
            try {
                nodeList.add(Integer.parseInt(nodeStr));
            } catch (NumberFormatException e) {
                return true;
            }
        }
        nodeList.add(end);

        for (int idx = 0; idx < nodeList.size() - 1; idx++) {
            int from = nodeList.get(idx);
            int to = nodeList.get(idx + 1);
            if (from < 0 || from >= LEN || to < 0 || to >= LEN) {
                return true;
            }
            if (isBlocked(from, to)) {
                return true;
            }
        }
        return false;
    }

    /* ====================== 偏序关系管理（简化版，供导航阶段使用） ====================== */

    public void addPartialOrder(long precedingNodeId, long succeedingNodeId) {
        PlainNode PSt = idToPlainNode.get(precedingNodeId);
        PlainNode SSt = idToPlainNode.get(succeedingNodeId);

        if (PSt != null && SSt != null) {
            // 创建TokenNode用于偏序关系
            TokenNode pStToken = new TokenNode("", "", "", PSt.id);
            TokenNode sStToken = new TokenNode("", "", "", SSt.id);

            // 检查是否已存在相同的偏序关系
            for (PartialOrder existingPO : partialOrders) {
                if (existingPO.getPSt().getId() == precedingNodeId &&
                        existingPO.getSSt().getId() == succeedingNodeId) {
                    System.out.println("偏序关系已存在: " + precedingNodeId + " → " + succeedingNodeId);
                    return;
                }
            }

            PartialOrder po = new PartialOrder(pStToken, sStToken);
            partialOrders.add(po);
            System.out.println("成功添加偏序关系: " + precedingNodeId + " → " + succeedingNodeId);
        } else {
            System.err.println("错误: 无法添加偏序关系，节点不存在");
        }
    }

    public void addPartialOrders(List<PartialOrder> pos) {
        if (pos != null && !pos.isEmpty()) {
            int addedCount = 0;
            for (PartialOrder po : pos) {
                if (po.getPSt() != null && po.getSSt() != null) {
                    partialOrders.add(po);
                    addedCount++;
                }
            }
            System.out.println("成功添加了 " + addedCount + " 个偏序关系");
        }
    }

    public List<PartialOrder> getPartialOrders() {
        return Collections.unmodifiableList(partialOrders);
    }

    public int getPartialOrderCount() {
        return partialOrders.size();
    }

    public void printPartialOrders() {
        System.out.println("\n=== 当前偏序关系列表 ===");
        if (partialOrders.isEmpty()) {
            System.out.println("无偏序关系");
        } else {
            for (int i = 0; i < partialOrders.size(); i++) {
                PartialOrder po = partialOrders.get(i);
                System.out.printf("%2d. %d → %d\n", i + 1,
                        po.getPSt().getId(), po.getSSt().getId());
            }
        }
        System.out.println("总计: " + partialOrders.size() + " 个偏序关系");
    }

    /* ====================== Floyd-Warshall 核心算法（专注阻塞边） ====================== */

    public void setup() {
        Random rand = new Random();

        /* 1. 初始化距离矩阵 */
        for (int i = 0; i < LEN; i++) {
            ArrayList<String> tmplist = new ArrayList<>();
            ArrayList<String> originalTmplist = new ArrayList<>(); // 原始路径列表
            for (int j = 0; j < LEN; j++) {
                graph1[i][j] = 20000000.0;
                originalGraph1[i][j] = 20000000.0; // 初始化原始矩阵
                tmplist.add("");
                originalTmplist.add(""); // 初始化原始路径
            }
            graph1[i][i] = 0.0;
            originalGraph1[i][i] = 0.0; // 原始矩阵对角线
            pathlist.add(tmplist);
            originalPathlist.add(originalTmplist); // 添加原始路径列表
        }

        /* 2. 基于邻接表填初始边 */
        boolean hasValidEdge = false;
        int totalEdgesFound = 0;
        int invalidEdges = 0;

        System.out.println("开始构建初始边，节点总数: " + LEN);

        for (int from = 0; from < LEN; from++) {
            node nd = apl.get(from);
            if (nd == null) {
                continue;
            }

            if (nd.Neb == null || nd.Dis == null) {
                continue;
            }

            for (int neighborIndex = 0; neighborIndex < nd.Neb.size(); neighborIndex++) {
                int to = nd.Neb.get(neighborIndex);

                if (to < 0 || to >= LEN) {
                    invalidEdges++;
                    continue;
                }

                if (neighborIndex >= nd.Dis.size()) {
                    invalidEdges++;
                    continue;
                }

                double dis = nd.Dis.get(neighborIndex);
                if (dis <= 0 || dis >= 20000000.0) {
                    invalidEdges++;
                    continue;
                }

                // 设置双向边 - 同时设置原始矩阵和处理后矩阵
                graph1[from][to] = dis;
                graph1[to][from] = dis;
                originalGraph1[from][to] = dis; // 保存到原始矩阵
                originalGraph1[to][from] = dis; // 保存到原始矩阵

                pathlist.get(from).set(to, "");
                pathlist.get(to).set(from, "");
                originalPathlist.get(from).set(to, ""); // 保存原始路径
                originalPathlist.get(to).set(from, ""); // 保存原始路径

                hasValidEdge = true;
                totalEdgesFound++;
            }
        }

        System.out.printf("边构建统计: 有效边=%d, 无效边=%d\n", totalEdgesFound, invalidEdges);

        if (!hasValidEdge) {
            throw new RuntimeException("初始边构建失败：无有效邻居关系");
        }

        /* 3. 初始化阻塞表和阻塞边 */
        deviation = new int[LEN][LEN];
        for (int i = 0; i < LEN; i++) {
            Arrays.fill(deviation[i], -1);
        }

        /* 4. 随机阻塞5%的边 */
        List<int[]> edgeList = new ArrayList<>();
        for (int i = 0; i < LEN; i++) {
            for (int j : adjacencyList.get(i)) {
                if (j > i && graph1[i][j] < 20000000.0) {
                    edgeList.add(new int[] { i, j });
                }
            }
        }

        System.out.println("实际无向边数量 = " + edgeList.size());
        int blockCount = (int) (edgeList.size() * this.blockageRatio); // 阻塞5%的边
        //if (blockCount == 0 && edgeList.size() > 0)
            //blockCount = 1;
        Collections.shuffle(edgeList, rand);

        for (int k = 0; k < blockCount; k++) {
            int i = edgeList.get(k)[0];
            int j = edgeList.get(k)[1];
            blockedEdgeSet.add(i + "," + j);
            blockedEdgeSet.add(j + "," + i);

            // 在处理后矩阵中标记为阻塞（极大值）
            graph1[i][j] = 20000000.0;
            graph1[j][i] = 20000000.0;

            System.out.println("阻塞边 " + i + "->" + j);
        }

        // 拓扑统计
        int totalNodes = LEN;
        int totalEdges = edgeList.size();
        double avgDegree = (double) (totalEdges * 2) / totalNodes;
        System.out.println("\n=== 拓扑统计 ===");
        System.out.println("节点总数：" + totalNodes);
        System.out.println("无向边总数：" + totalEdges);
        System.out.println("平均节点度数：" + String.format("%.2f", avgDegree));
        System.out.println("已阻塞边数：" + blockCount);
        System.out.println("偏序关系数量: " + partialOrders.size());
    }

    /**
     * 暴力全排列寻找满足约束的最优途径点顺序
     */
    private static List<TokenNode> findOptimalSequence(TokenNode s, TokenNode d, List<TokenNode> stops, 
                                                     List<PartialOrder> constraints, Floyd_Warshall_1 fw, 
                                                     ConcurrentHashMap<Long, Integer> i2i) {
        if (stops == null || stops.isEmpty()) return new ArrayList<>();
        
        List<Integer> indices = new ArrayList<>();
        for (int i = 0; i < stops.size(); i++) indices.add(i);
        
        List<List<Integer>> perms = new ArrayList<>();
        generatePermutations(indices, 0, perms);
        
        double minDst = Double.MAX_VALUE;
        List<TokenNode> bestOrder = null;
        
        for (List<Integer> p : perms) {
            List<TokenNode> currentOrder = new ArrayList<>();
            for (int idx : p) currentOrder.add(stops.get(idx));
            
            // 检查是否满足偏序约束
            if (isOrderValid(currentOrder, constraints)) {
                // 计算总距离
                double dst = calculateTotalDistance(s, d, currentOrder, fw, i2i);
                if (dst < minDst) {
                    minDst = dst;
                    bestOrder = new ArrayList<>(currentOrder);
                }
            }
        }
        // 如果找不到满足约束的，就返回原始顺序或者null
        return bestOrder != null ? bestOrder : stops;
    }

    private static void generatePermutations(List<Integer> arr, int k, List<List<Integer>> res) {
        for (int i = k; i < arr.size(); i++) {
            Collections.swap(arr, i, k);
            generatePermutations(arr, k + 1, res);
            Collections.swap(arr, i, k);
        }
        if (k == arr.size() - 1) res.add(new ArrayList<>(arr));
    }

    private static boolean isOrderValid(List<TokenNode> order, List<PartialOrder> constraints) {
        if (constraints == null) return true;
        Map<Long, Integer> idxMap = new HashMap<>();
        for(int i=0; i<order.size(); i++) idxMap.put(order.get(i).getId(), i);
        for(PartialOrder po : constraints) {
            long p = po.getPSt().getId();
            long s = po.getSSt().getId();
            if(idxMap.containsKey(p) && idxMap.containsKey(s)) {
                if(idxMap.get(p) > idxMap.get(s)) return false;
            }
        }
        return true;
    }

    private static double calculateTotalDistance(TokenNode s, TokenNode d, List<TokenNode> mids, 
                                               Floyd_Warshall_1 fw, ConcurrentHashMap<Long, Integer> i2i) {
        double total = 0;
        List<TokenNode> all = new ArrayList<>();
        all.add(s); all.addAll(mids); all.add(d);
        
        // 使用 fw.getGraph1() (处理后矩阵) 计算距离
        double[][] matrix = fw.getGraph1();
        
        for(int i=0; i<all.size()-1; i++) {
            Integer u = i2i.get(all.get(i).getId());
            Integer v = i2i.get(all.get(i+1).getId());
            if(u!=null && v!=null) {
                double dist = matrix[u][v];
                if(dist >= 19000000.0) return 20000000.0;
                total += dist;
            }
        }
        return total;
    }



    /**
 * 只执行阻塞边处理并测量时间
 * @return 阻塞边处理耗时（毫秒）
 */
public long computeBlockageProcessingWithTiming() {
    System.out.println("开始阻塞边处理计时...");
    
    long startTime = System.currentTimeMillis();
    
    /* 为每条阻塞边找 DSt - 使用增强版阻塞边处理 */
    System.out.println("开始增强版阻塞边处理...");
    IntStream.range(0, LEN).parallel().forEach(i -> {
        for (int j = i + 1; j < LEN; j++) {  // 上三角遍历
            if (!isBlocked(i, j)) continue;

            // 使用增强版阻塞边处理逻辑
            List<Integer> pathHistory = buildMeaningfulPathHistory(i, j);
            processBlockedEdgeEnhanced(i, j, pathHistory);
            
            // 对称更新偏差信息
            if (deviation[i][j] != -1) {
                deviation[j][i] = deviation[i][j];
            }
        }
    });
    
    long endTime = System.currentTimeMillis();
    long processingTime = endTime - startTime;
    
    System.out.println("阻塞边处理完成，耗时: " + processingTime + " 毫秒");
    
    // 打印阻塞边处理统计信息
    printBlockageProcessingStats();
    
    return processingTime;
}

/**
 * 打印阻塞边处理统计信息
 */
private void printBlockageProcessingStats() {
    int totalBlockedEdges = 0;
    int successfullyProcessed = 0;
    int failedToProcess = 0;
    
    for (int i = 0; i < LEN; i++) {
        for (int j = i + 1; j < LEN; j++) {
            if (isBlocked(i, j)) {
                totalBlockedEdges++;
                if (deviation[i][j] != -1 && deviation[i][j] != -2) {
                    successfullyProcessed++;
                } else {
                    failedToProcess++;
                }
            }
        }
    }
    
    System.out.println("\n=== 阻塞边处理统计 ===");
    System.out.println("总阻塞边数: " + totalBlockedEdges);
    System.out.println("成功处理数: " + successfullyProcessed);
    System.out.println("处理失败数: " + failedToProcess);
    if (totalBlockedEdges > 0) {
        double successRate = (double) successfullyProcessed / totalBlockedEdges * 100;
        System.out.println("处理成功率: " + String.format("%.2f", successRate) + "%");
    }
}

    /* Floyd 核心算法 */
    public void compute() {
        // 初始化路径
        for (int i = 0; i < LEN; i++) {
            for (int j = 0; j < LEN; j++) {
                if (i == j) {
                    pathlist.get(i).set(j, "原地踏步");
                    originalPathlist.get(i).set(j, "原地踏步"); // 原始路径
                } else if (graph1[i][j] < 20000000.0 && !isBlocked(i, j)) {
                    pathlist.get(i).set(j, "");
                }
                if (originalGraph1[i][j] < 20000000.0) {
                    originalPathlist.get(i).set(j, ""); // 原始路径初始化
                }
            }
        }

        /* 1. 并行Floyd更新 - 原始矩阵 */
        System.out.println("开始原始Floyd算法计算...");
        IntStream.range(0, LEN).parallel().forEach(k -> {
            for (int i = 0; i < LEN; i++) {
                if (i == k || originalGraph1[i][k] >= 20000000 - 1)
                    continue;
                for (int j = i + 1; j < LEN; j++) { // ✅ 上三角遍历
                    if (j == k || originalGraph1[k][j] >= 20000000 - 1)
                        continue;

                    if (originalGraph1[i][j] > originalGraph1[i][k] + originalGraph1[k][j]) {
                        synchronized (originalGraph1) {
                            double newDist = originalGraph1[i][k] + originalGraph1[k][j];
                            originalGraph1[i][j] = newDist;
                            originalGraph1[j][i] = newDist; // ✅ 对称赋值

                            String newPath = buildOriginalPath(i, j, k);
                            originalPathlist.get(i).set(j, newPath);
                            originalPathlist.get(j).set(i, reversePath(newPath));
                        }
                    }
                }
            }
        });

        /* 2. 并行Floyd更新 - 处理后矩阵 */
        System.out.println("开始处理后Floyd算法计算...");
        IntStream.range(0, LEN).parallel().forEach(k -> {
            for (int i = 0; i < LEN; i++) {
                if (i == k || graph1[i][k] >= 20000000 - 1)
                    continue;
                for (int j = i + 1; j < LEN; j++) { // ✅ 改为上三角遍历
                    if (j == k || graph1[k][j] >= 20000000 - 1)
                        continue;

                    if (graph1[i][j] > graph1[i][k] + graph1[k][j]) {
                        synchronized (graph1) {
                            double newDist = graph1[i][k] + graph1[k][j];
                            graph1[i][j] = newDist;
                            graph1[j][i] = newDist; // ✅ 对称赋值

                            String newPath = buildPath(i, j, k);
                            pathlist.get(i).set(j, newPath);
                            pathlist.get(j).set(i, reversePath(newPath));
                        }
                    }
                }
            }
        });

        /* 3. double→int 距离矩阵 */
        IntStream.range(0, LEN).parallel().forEach(i -> {
            for (int j = 0; j < LEN; j++) {
                graph[i][j] = (int) Math.round(graph1[i][j]);
            }
        });

        /* 4. 为每条阻塞边找 DSt - 使用增强版阻塞边处理 */
        System.out.println("开始增强版阻塞边处理...");
        IntStream.range(0, LEN).parallel().forEach(i -> {
            for (int j = i + 1; j < LEN; j++) { // ✅ 改为上三角遍历
                if (!isBlocked(i, j))
                    continue;

                // 使用增强版阻塞边处理逻辑
                List<Integer> pathHistory = buildMeaningfulPathHistory(i, j);
                processBlockedEdgeEnhanced(i, j, pathHistory);

                // 注意：由于距离矩阵已对称，j->i 会自动处理
                // 阻塞边集合也需要对称更新（如果processBlockedEdgeEnhanced内部没有处理）
                if (deviation[i][j] != -1) {
                    deviation[j][i] = deviation[i][j]; // ✅ 对称更新偏差信息
                }
            }
        });

        System.out.println("Floyd算法计算完成，专注阻塞边处理，原始矩阵和处理后矩阵均已更新");
    }

    /* 路径构建辅助方法 */
    private String buildPath(int i, int j, int k) {
        String pathIK = pathlist.get(i).get(k);
        String pathKJ = pathlist.get(k).get(j);

        StringBuilder newPath = new StringBuilder();
        if (pathIK.isEmpty() || pathIK.equals("原地踏步")) {
            newPath.append(k);
        } else {
            newPath.append(pathIK).append("->").append(k);
        }
        if (!pathKJ.isEmpty() && !pathKJ.equals("原地踏步")) {
            if (newPath.length() > 0)
                newPath.append("->");
            newPath.append(pathKJ);
        }
        return newPath.toString();
    }

    /* 原始路径构建辅助方法 */
    private String buildOriginalPath(int i, int j, int k) {
        String pathIK = originalPathlist.get(i).get(k);
        String pathKJ = originalPathlist.get(k).get(j);

        StringBuilder newPath = new StringBuilder();
        if (pathIK.isEmpty() || pathIK.equals("原地踏步")) {
            newPath.append(k);
        } else {
            newPath.append(pathIK).append("->").append(k);
        }
        if (!pathKJ.isEmpty() && !pathKJ.equals("原地踏步")) {
            if (newPath.length() > 0)
                newPath.append("->");
            newPath.append(pathKJ);
        }
        return newPath.toString();
    }

    /* 反转路径字符串 */
    private String reversePath(String path) {
        if (path.isEmpty() || path.equals("原地踏步"))
            return path;
        String[] nodes = path.split("->");
        StringBuilder rev = new StringBuilder();
        for (int i = nodes.length - 1; i >= 0; i--) {
            rev.append(nodes[i]);
            if (i > 0)
                rev.append("->");
        }
        return rev.toString();
    }

    /* ====================== 新增方法：获取原始距离和路径 ====================== */

    /**
     * 获取两个节点间的原始最短路径距离（无阻塞、无偏序）
     */
    public double getOriginalDistanceBetweenNodes(long nodeId1, long nodeId2) {
        Integer idx1 = Id2Index.get(nodeId1);
        Integer idx2 = Id2Index.get(nodeId2);

        if (idx1 == null || idx2 == null) {
            return -1;
        }

        return originalGraph1[idx1][idx2];
    }

    /**
     * 获取两个节点间的原始最短路径（无阻塞、无偏序）
     */
    public String getOriginalPathBetweenNodes(long nodeId1, long nodeId2) {
        Integer idx1 = Id2Index.get(nodeId1);
        Integer idx2 = Id2Index.get(nodeId2);

        if (idx1 == null || idx2 == null) {
            return "节点不存在";
        }

        return originalPathlist.get(idx1).get(idx2);
    }

    /**
     * 获取两个节点间的路径
     */
    public String getPathBetweenNodes(long nodeId1, long nodeId2) {
        Integer idx1 = Id2Index.get(nodeId1);
        Integer idx2 = Id2Index.get(nodeId2);

        if (idx1 == null || idx2 == null) {
            return "节点不存在";
        }

        return pathlist.get(idx1).get(idx2);
    }

    /**
 * 只执行原始矩阵的Floyd计算
 */
public long computeOriginalFloydOnly() {
    System.out.println("开始原始矩阵Floyd计算...");
    
    long startTime = System.currentTimeMillis();
    
    // 初始化原始路径
    for (int i = 0; i < LEN; i++) {
        for (int j = 0; j < LEN; j++) {
            if (i == j) {
                originalPathlist.get(i).set(j, "原地踏步");
            } else if (originalGraph1[i][j] < 20000000.0) {
                originalPathlist.get(i).set(j, "");
            }
        }
    }

    /* 只执行原始矩阵的Floyd计算 */
    IntStream.range(0, LEN).parallel().forEach(k -> {
        for (int i = 0; i < LEN; i++) {
            if (i == k || originalGraph1[i][k] >= 20000000 - 1) continue;
            for (int j = i + 1; j < LEN; j++) {
                if (j == k || originalGraph1[k][j] >= 20000000 - 1) continue;

                if (originalGraph1[i][j] > originalGraph1[i][k] + originalGraph1[k][j]) {
                    synchronized (originalGraph1) {
                        originalGraph1[i][j] = originalGraph1[i][k] + originalGraph1[k][j];
                        originalGraph1[j][i] = originalGraph1[i][j];
                        String newPath = buildOriginalPath(i, j, k);
                        originalPathlist.get(i).set(j, newPath);
                        originalPathlist.get(j).set(i, reversePath(newPath));
                    }
                }
            }
        }
    });

    long endTime = System.currentTimeMillis();
    long elapsedTime = endTime - startTime;
    System.out.println("原始矩阵Floyd计算完成，耗时: " + elapsedTime + " 毫秒");
    return elapsedTime;
}

/**
 * 只执行处理后矩阵的Floyd计算（不含阻塞边处理）
 */
public long computeProcessedFloydOnly() {
    System.out.println("开始处理后矩阵Floyd计算...");
    
    long startTime = System.currentTimeMillis();
    
    // 只初始化处理后矩阵的路径
    for (int i = 0; i < LEN; i++) {
        for (int j = 0; j < LEN; j++) {
            if (i == j) {
                pathlist.get(i).set(j, "原地踏步");
            } else if (graph1[i][j] < 20000000.0 && !isBlocked(i, j)) {
                pathlist.get(i).set(j, "");
            }
        }
    }

    /* 只执行处理后矩阵的Floyd计算 */
    IntStream.range(0, LEN).parallel().forEach(k -> {
        for (int i = 0; i < LEN; i++) {
            if (i == k || graph1[i][k] >= 20000000 - 1) continue;
            for (int j = i + 1; j < LEN; j++) {
                if (j == k || graph1[k][j] >= 20000000 - 1) continue;

                if (graph1[i][j] > graph1[i][k] + graph1[k][j]) {
                    synchronized (graph1) {
                        graph1[i][j] = graph1[i][k] + graph1[k][j];
                        graph1[j][i] = graph1[i][j];
                        String newPath = buildPath(i, j, k);
                        pathlist.get(i).set(j, newPath);
                        pathlist.get(j).set(i, reversePath(newPath));
                    }
                }
            }
        }
    });

    /* double→int 距离矩阵 */
    IntStream.range(0, LEN).parallel().forEach(i -> {
        for (int j = 0; j < LEN; j++) {
            graph[i][j] = (int) Math.round(graph1[i][j]);
        }
    });

    long endTime = System.currentTimeMillis();
    long elapsedTime = endTime - startTime;
    System.out.println("处理后矩阵Floyd计算完成，耗时: " + elapsedTime + " 毫秒");
    return elapsedTime;
}

/**
 * 只执行阻塞边处理并测量时间
 * @return 阻塞边处理耗时（毫秒）
 */
public long computeBlockageProcessingOnly() {
    System.out.println("开始阻塞边处理...");
    
    long startTime = System.currentTimeMillis();
    
    /* 为每条阻塞边找 DSt - 使用增强版阻塞边处理 */
    IntStream.range(0, LEN).parallel().forEach(i -> {
        for (int j = i + 1; j < LEN; j++) {
            if (!isBlocked(i, j)) continue;

            // 使用增强版阻塞边处理逻辑
            List<Integer> pathHistory = buildMeaningfulPathHistory(i, j);
            processBlockedEdgeEnhanced(i, j, pathHistory);
            
            // 对称更新偏差信息
            if (deviation[i][j] != -1) {
                deviation[j][i] = deviation[i][j];
            }
        }
    });
    
    long endTime = System.currentTimeMillis();
    long processingTime = endTime - startTime;
    
    System.out.println("阻塞边处理完成，耗时: " + processingTime + " 毫秒");
    
    // 打印阻塞边处理统计信息
    printBlockageProcessingStats();
    
    return processingTime;
}

    /**
     * 获取两个节点间的距离
     */
    public double getDistanceBetweenNodes(long nodeId1, long nodeId2) {
        Integer idx1 = Id2Index.get(nodeId1);
        Integer idx2 = Id2Index.get(nodeId2);

        if (idx1 == null || idx2 == null) {
            return -1;
        }

        return graph1[idx1][idx2];
    }

    /* ====================== Getter 方法 ====================== */

    public double[][] getGraph1() {
        return graph1;
    }

    public double[][] getOriginalGraph1() {
        return originalGraph1;
    }

    public int[][] getGraph() {
        return graph;
    }

    public int[][] getDeviation() {
        return deviation;
    }

    public ArrayList<ArrayList<String>> getPathlist() {
        return pathlist;
    }

    public ArrayList<ArrayList<String>> getOriginalPathlist() {
        return originalPathlist;
    }

    /* ====================== 测试入口 ====================== */

    /* ====================== 测试入口 ====================== */

/* ====================== 测试入口 ====================== */

public static void main(String[] args) throws Exception {
    ConcurrentHashMap<Long, Integer> i2i = new ConcurrentHashMap<>();
    ConcurrentHashMap<Long, Long> ii2i = new ConcurrentHashMap<>();
    ConcurrentHashMap<Long, Long> oi2i = new ConcurrentHashMap<>();
    String json = "D:\\Gaia\\src\\main\\resources\\400-2200junctions(Manhattan) (2)\\600\\600junction.json";
    ConcurrentHashMap<Integer, node> apl = JsonUtil.getNodeList600(json, i2i, ii2i, oi2i);
    WriteMapInJson(i2i, ii2i, oi2i);

    // 创建Floyd算法实例
    Floyd_Warshall_1 fw = new Floyd_Warshall_1(apl, i2i);
    System.out.println("\n=== 分阶段时间测试 ===");

    // 步骤1: 初始化（包括设置阻塞边）
    long setupStart = System.currentTimeMillis();
    fw.setup(); // 初始化 & 随机阻塞
    long setupEnd = System.currentTimeMillis();
    long setupTime = setupEnd - setupStart;
    System.out.println("初始化耗时: " + setupTime + " 毫秒");

    // 步骤2: 原始矩阵Floyd计算
    long originalFloydTime = fw.computeOriginalFloydOnly();

    // 步骤3: 处理后矩阵Floyd计算
    long processedFloydTime = fw.computeProcessedFloydOnly();

    // 步骤4: 阻塞边处理
    long blockageTime = fw.computeBlockageProcessingOnly();

    // 计算总时间
    long totalTime = setupTime + originalFloydTime + processedFloydTime + blockageTime;

    System.out.println("\n=== 详细时间分析 ===");
    System.out.println("1. 初始化时间: " + setupTime + " 毫秒");
    System.out.println("2. 原始矩阵Floyd计算: " + originalFloydTime + " 毫秒");
    System.out.println("3. 处理后矩阵Floyd计算: " + processedFloydTime + " 毫秒");
    System.out.println("4. 阻塞边处理: " + blockageTime + " 毫秒");
    System.out.println("-----------------------------------");
    System.out.println("总时间: " + totalTime + " 毫秒");
    
    // 可选：验证结果一致性
    fw.verifyResultsConsistency();
}

/**
 * 验证结果一致性
 */
private void verifyResultsConsistency() {
    System.out.println("\n=== 结果一致性验证 ===");
    
    // 验证几个随机节点对的距离
    Random rand = new Random();
    int verificationCount = 0;
    int maxVerifications = 3;
    
    for (int i = 0; i < LEN && verificationCount < maxVerifications; i++) {
        for (int j = i + 1; j < LEN && verificationCount < maxVerifications; j++) {
            if (rand.nextDouble() < 0.05) { // 5%概率抽样验证
                verificationCount++;
                double originalDist = originalGraph1[i][j];
                double processedDist = graph1[i][j];
                boolean isBlocked = isBlocked(i, j);
                
                System.out.println("节点对 " + i + "->" + j + ":");
                System.out.println("  - 原始距离: " + originalDist);
                System.out.println("  - 处理后距离: " + processedDist);
                System.out.println("  - 是否阻塞: " + isBlocked);
                System.out.println("  - 距离差异: " + (processedDist - originalDist));
                
                if (isBlocked && processedDist < 20000000.0) {
                    System.out.println("  - 绕行节点: " + deviation[i][j]);
                }
                System.out.println();
            }
        }
    }
}
/**
 * 只执行基础Floyd计算，不处理阻塞边
 */
public void computeBasicFloydOnly() {
    System.out.println("开始基础Floyd计算（不含阻塞边处理）...");
    
    // 初始化路径
    for (int i = 0; i < LEN; i++) {
        for (int j = 0; j < LEN; j++) {
            if (i == j) {
                pathlist.get(i).set(j, "原地踏步");
                originalPathlist.get(i).set(j, "原地踏步");
            } else if (graph1[i][j] < 20000000.0 && !isBlocked(i, j)) {
                pathlist.get(i).set(j, "");
            }
            if (originalGraph1[i][j] < 20000000.0) {
                originalPathlist.get(i).set(j, "");
            }
        }
    }

    /* 并行Floyd更新 - 处理后矩阵 */
    IntStream.range(0, LEN).parallel().forEach(k -> {
        for (int i = 0; i < LEN; i++) {
            if (i == k || graph1[i][k] >= 20000000 - 1) continue;
            for (int j = i + 1; j < LEN; j++) {  // 上三角优化
                if (j == k || graph1[k][j] >= 20000000 - 1) continue;

                if (graph1[i][j] > graph1[i][k] + graph1[k][j]) {
                    synchronized (graph1) {
                        graph1[i][j] = graph1[i][k] + graph1[k][j];
                        graph1[j][i] = graph1[i][j];
                        String newPath = buildPath(i, j, k);
                        pathlist.get(i).set(j, newPath);
                        pathlist.get(j).set(i, reversePath(newPath));
                    }
                }
            }
        }
    });

    /* double→int 距离矩阵 */
    IntStream.range(0, LEN).parallel().forEach(i -> {
        for (int j = 0; j < LEN; j++) {
            graph[i][j] = (int) Math.round(graph1[i][j]);
        }
    });

    System.out.println("基础Floyd计算完成（跳过阻塞边处理）");
}

/**
 * 验证阻塞边处理结果
 */
private void verifyBlockageProcessingResults() {
    System.out.println("\n=== 阻塞边处理结果验证 ===");
    
    // 随机选择几条阻塞边验证处理结果
    Random rand = new Random();
    int verificationCount = 0;
    int maxVerifications = 5;
    
    for (int i = 0; i < LEN && verificationCount < maxVerifications; i++) {
        for (int j = i + 1; j < LEN && verificationCount < maxVerifications; j++) {
            if (isBlocked(i, j) && rand.nextDouble() < 0.1) { // 10%概率抽样验证
                verificationCount++;
                System.out.println("验证阻塞边 " + i + "->" + j + ":");
                System.out.println("  - 绕行节点(DSt): " + deviation[i][j]);
                System.out.println("  - 处理后距离: " + graph1[i][j]);
                System.out.println("  - 路径: " + pathlist.get(i).get(j));
            }
        }
    }
}

    // 打印路径方法
    public void printPaths() {
        System.out.println("路径打印功能 - 专注阻塞边处理");
        // 这里可以添加具体的路径打印逻辑
    }
}