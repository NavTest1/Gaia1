package Class;

import ckks.Ciphertext;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;


@EqualsAndHashCode
@Data
@NoArgsConstructor
public class TokenNode {

    @JsonProperty("T2str")
    public String T2str;

    @JsonProperty("F4str")
    public String F4str;

    @JsonProperty("H1str")
    public String H1str;

    @JsonProperty("id")
    public long id;

    // 加密坐标
    public Ciphertext xEnc;
    public Ciphertext yEnc;

    // 原始明文坐标（可选，调试方便）
    public int x;
    public int y;

    /* ---------- 旧构造保留，保证兼容 ---------- */
    public TokenNode(String t2, String f4, String h1) {
        this.T2str = t2;
        this.F4str = f4;
        this.H1str = h1;
    }

    public TokenNode(String t2, String f4, String h1, long id) {
        this.T2str = t2;
        this.F4str = f4;
        this.H1str = h1;
        this.id   = id;
    }

    /* ---------- 新构造：带加密坐标 ---------- */
    public TokenNode(String t2, String f4, String h1, long id,
                     Ciphertext xEnc, Ciphertext yEnc,
                     int x, int y) {
        this.T2str = t2;
        this.F4str = f4;
        this.H1str = h1;
        this.id    = id;
        this.xEnc  = xEnc;
        this.yEnc  = yEnc;
        this.x     = x;
        this.y     = y;
    }
}