package Class;



public class PD_Oracle_node {
    public String pd_pointlist = "";//id_list
    public int shortDistance = 0;

    public String show()
    {
        return "路径是：  "+pd_pointlist+"      最短距离是： "+shortDistance;
    }


}
