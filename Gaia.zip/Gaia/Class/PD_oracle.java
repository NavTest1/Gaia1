package Class;
import Algorithm.Floyd_Warshall_1;

public class PD_oracle {
    private final PD_Oracle_node[][] data;
    public int LEN;
    private final Floyd_Warshall_1 fw;

    public PD_oracle(int l, Floyd_Warshall_1 fw) {
        this.LEN = l;
        this.fw = fw;
        this.data = new PD_Oracle_node[LEN][LEN];
        initializeValidatedPaths();
    }

    /**
     * 初始化已验证的路径（考虑偏序关系约束）
     */
    private void initializeValidatedPaths() {
        System.out.println("PD_oracle: 初始化已验证路径（包含偏序关系约束）...");
        
        int validPathCount = 0;
        int invalidDueToBlockedEdge = 0;
        
        for (int i = 0; i < LEN; i++) {
            for (int j = 0; j < LEN; j++) {
                data[i][j] = new PD_Oracle_node();
                
                 
                data[i][j].shortDistance = fw.getGraph()[i][j];
                
                 
                String validatedPath = fw.getValidatedPath(i, j);
                data[i][j].pd_pointlist = validatedPath;
                
                if (!validatedPath.isEmpty() && !validatedPath.equals("原地踏步")) {
                    validPathCount++;
                } else if (fw.getGraph()[i][j] < 20000000.0) {
                     
                    invalidDueToBlockedEdge++;
                }
            }
        }
        
        System.out.printf("PD_oracle: 初始化完成 - 有效路径: %d, 因阻塞边无效: %d\n", 
                         validPathCount, invalidDueToBlockedEdge);
    }

    /**
     * 查找节点间的最短路径信息（使用已验证的路径）
     */
    public PD_Oracle_node find(int id1, int id2) {
        if (id1 < 0 || id1 >= LEN || id2 < 0 || id2 >= LEN) {
            PD_Oracle_node invalidNode = new PD_Oracle_node();
            invalidNode.shortDistance = -1;
            invalidNode.pd_pointlist = "";
            return invalidNode;
        }
        return data[id1][id2];
    }

    /**
     * 检查路径是否有效（快速检查）
     */
    public boolean isPathValid(int from, int to) {
        if (from < 0 || from >= LEN || to < 0 || to >= LEN) {
            return false;
        }
        return !data[from][to].pd_pointlist.isEmpty() && 
               !data[from][to].pd_pointlist.equals("原地踏步");
    }

    /**
     * 获取最短距离
     */
    public double getShortestDistance(int from, int to) {
        if (from < 0 || from >= LEN || to < 0 || to >= LEN) {
            return -1;
        }
        return data[from][to].shortDistance;
    }

    /**
     * 获取最短路径
     */
    public String getShortestPath(int from, int to) {
        if (from < 0 || from >= LEN || to < 0 || to >= LEN) {
            return "";
        }
        return data[from][to].pd_pointlist;
    }

    /**
     * 打印统计信息
     */
    public void printStatistics() {
        int totalPaths = 0;
        int validPaths = 0;
        double maxDistance = 0;
        double minDistance = Double.MAX_VALUE;
        
        for (int i = 0; i < LEN; i++) {
            for (int j = 0; j < LEN; j++) {
                if (i != j) {
                    totalPaths++;
                    if (isPathValid(i, j)) {
                        validPaths++;
                        double distance = data[i][j].shortDistance;
                        if (distance > maxDistance) maxDistance = distance;
                        if (distance < minDistance) minDistance = distance;
                    }
                }
            }
        }
        
        System.out.println("\n=== PD_oracle 路径统计 ===");
        System.out.println("总路径数: " + totalPaths);
        System.out.println("有效路径数: " + validPaths);
        System.out.println("路径有效率: " + String.format("%.2f%%", (double) validPaths / totalPaths * 100));
        System.out.println("最短距离: " + (minDistance == Double.MAX_VALUE ? "N/A" : minDistance));
        System.out.println("最长距离: " + maxDistance);
        System.out.println("偏序关系数量: " + fw.getPartialOrderCount());
    }
}