package Class;

/**
 * 偏序关系类
 * 表示节点之间的先后访问顺序约束
 */
public class PartialOrder {
    public TokenNode PSt;  // Preceding Stop - 必须先访问的节点
    public TokenNode SSt;  // Succeeding Stop - 后访问的节点
    
    public PartialOrder() {}
    
    public PartialOrder(TokenNode PSt, TokenNode SSt) {
        this.PSt = PSt;
        this.SSt = SSt;
    }
    
    // Getter and Setter
    public TokenNode getPSt() { return PSt; }
    public void setPSt(TokenNode PSt) { this.PSt = PSt; }
    
    public TokenNode getSSt() { return SSt; }
    public void setSSt(TokenNode SSt) { this.SSt = SSt; }
    
    @Override
    public String toString() {
        return "PartialOrder{PSt=" + (PSt != null ? PSt.id : "null") + 
               ", SSt=" + (SSt != null ? SSt.id : "null") + "}";
    }
}