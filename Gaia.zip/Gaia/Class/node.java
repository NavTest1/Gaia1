package Class;

import ckks.Ciphertext;
import java.math.BigInteger;
import java.util.ArrayList;
import java.io.Serializable; // 👈 1. 必须引入这个包

// 👇 2. 必须加上 implements Serializable
public class node implements Serializable {
    
    // 👇 3. 建议加上版本号，防止序列化冲突
    private static final long serialVersionUID = 1L;

    public long id;
    public BigInteger kv, rv;
    public int index;
    public int x;
    public int y;
    public ArrayList<Double> Dis = new ArrayList<>();
    public ArrayList<Integer> Neb = new ArrayList<>();
    
    // === 新增：加密坐标字段 ===
    public Ciphertext xEnc;  // 加密的x坐标
    public Ciphertext yEnc;  // 加密的y坐标

    public node() {

    }
    
    // 检查是否包含加密坐标
    public boolean hasEncryptedCoords() {
        return xEnc != null && yEnc != null;
    }
    
    // 设置加密坐标
    public void setEncryptedCoords(Ciphertext encryptedX, Ciphertext encryptedY) {
        this.xEnc = encryptedX;
        this.yEnc = encryptedY;
    }
    
    // 获取加密坐标信息字符串
    public String getEncryptedCoordsInfo() {
        if (hasEncryptedCoords()) {
            return "加密坐标: [xEnc: 已设置, yEnc: 已设置]";
        } else {
            return "加密坐标: [未设置]";
        }
    }

    // show 方法返回所有属性信息的字符串
    public String show() {
        StringBuilder sb = new StringBuilder();
        sb.append("节点信息：\n");
        sb.append("ID: ").append(id).append("\n");
        sb.append("KV: ").append(kv).append("\n");
        sb.append("rv: ").append(rv).append("\n");
        sb.append("索引 (index): ").append(index).append("\n");
        sb.append("坐标 x: ").append(x).append("\n");
        sb.append("坐标 y: ").append(y).append("\n");
        sb.append("邻居: ").append(Neb).append("\n");
        sb.append(getEncryptedCoordsInfo()).append("\n");

        return sb.toString();
    }
    
    // 简化的show方法，用于调试输出
    public String showSimple() {
        return "node{id=" + id + ", index=" + index + ", x=" + x + ", y=" + y + 
               ", encCoords=" + (hasEncryptedCoords() ? "YES" : "NO") + "}";
    }
    
    // 用于调试的toString方法
    @Override
    public String toString() {
        return showSimple();
    }
}