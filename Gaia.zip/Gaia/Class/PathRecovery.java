package Class;

import ckks.Ciphertext;
import it.unisa.dia.gas.jpbc.Element;

import java.math.BigInteger;
import java.util.ArrayList;

public class PathRecovery {
    public Ciphertext dis;
    public ArrayList<String> path;
    public PathRecovery(Ciphertext dis, ArrayList<String> list) {
        this.dis = dis;
        this.path = list;
    }

    public ArrayList<String> getPath() {
        return this.path;
    }

    public Ciphertext getDis() {
        return dis;
    }
}
