package Proxy.CMP;

import Proxy.Program.*;
import Proxy.Program.MyGCCommon;
import Proxy.Program.ProgCommon;
import Proxy.Program.Program;
import Proxy.YaoGC.Circuit;

import java.math.BigInteger;

public class GCCcompareTo {

    /**
     * 判断Cilent输入是否大于0,默认flase=0=Cilent>=0,true=1=Cilent<0
     * @param Server_r
     * @param Cilent_dec_add_r
     * @return
     */
    public static int runGarbledCircuit(int Server_r,int Cilent_dec_add_r) {
        /**
         *      Server_r >= Cilent_dec_add_r     1
         *      Server_r < Cilent_dec_add_r     0
         *      Server_r  Cilent_dec_add_r
         *      1000        897         1
         *      1000        1000        1
         *      1000        1897        0
         */
        double sTime = System.currentTimeMillis();
        Program.iterCount = 1;
        BigInteger S_bits = BigInteger.valueOf(Server_r);
        BigInteger C_bits = BigInteger.valueOf(Cilent_dec_add_r);
        int n = BigInteger.valueOf(Server_r).bitLength();

        //  new GCServer GCClient
        MyGCServer myGCServer = new MyGCServer(S_bits, n);
        MyGCClient myGCClient = new MyGCClient(C_bits, n);
        myGCServer.sBits = S_bits;
        myGCClient.cBits = C_bits;


        //  ---initCircuits

        MyGCCommon.initCircuits();

        myGCClient.otNumOfPairs = MyGCCommon.bitVecLen;

        //  ---createCircuits
        Circuit.isForGarbling = true;

        for (int i = 0; i < ProgCommon.ccs.length; i++) {
            try {
                ProgCommon.ccs[i].build();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        //  ---initializeOT
        myGCServer.otNumOfPairs = MyGCCommon.bitVecLen;


        try {
            myGCServer.initializeOT();

            myGCClient.initializeOT();
//---------------------------------------------------------
            myGCServer.snder.initialize2();


            myGCClient.rcver.initialize2();

            myGCServer.snder.Micro_receiver.step_2();

            myGCServer.snder.initialize3();
        } catch (Exception e) {
            e.printStackTrace();
        }

        //  ---generateLabelPairs
//---------------------------------------------------------
            myGCServer.generateLabelPairs();

        try {
            //  ---execTransfer

            myGCServer.execTransfer();
            myGCClient.execTransfer();

            myGCServer.execS();
            myGCClient.rcver.exex();
            //  ***execCircuit
            Circuit.isForGarbling = false;

            myGCClient.execCircuit();

            //  ---execCircuit

            myGCServer.execCircuit();

            //  ***interpretResult
            myGCClient.interpretResult();
            //  ---interpretResult
            myGCServer.interpretResult();

            //  ---verify_result
            myGCClient.verify_result();
            myGCServer.verify_result();
        }catch (Exception e){
            e.printStackTrace();
        }

        return myGCServer.tag;

    }

    public static void main(String[] args) {
        int cb = 1;
        double startTime =  System.currentTimeMillis();
        System.out.println("开始时间:"+startTime);
        cb = runGarbledCircuit(1100,100);
        double endTime =  System.currentTimeMillis();
       //System.out.println("结束时间:"+endTime);
        double usedTime = (endTime-startTime)*1.0;
        System.out.println(cb);
        System.out.println("用时："+usedTime+"ms");

    }
}
