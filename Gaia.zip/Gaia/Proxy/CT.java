package Proxy;

import Omega.NewOmega;
import Omega.PK;
import Omega.SK;
import Proxy.CMP.GCCcompareTo;
import ckks.CKKSHelper;
import ckks.Ciphertext;
import ckks.Context;
import ckks.PublicKeys;
import it.unisa.dia.gas.jpbc.Element;
import lombok.SneakyThrows;
import org.apache.commons.codec.binary.Base64;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.math.BigInteger;
import java.net.Socket;

import static Proxy.CMP.GCCcompareTo.runGarbledCircuit;

public final class CT {
    private final PublicKeys pk;
    //private final NewOmega omega;
    private final CKKSHelper ckks = new CKKSHelper(2, 4, 10, 20);
    //private final BigInteger sk;
    private final Context context;
    public CT(PublicKeys _pk, Context _context) throws IOException {
        //omega = new NewOmega();
        pk = _pk;
        context = _context;
        ckks.SetContext(context);
        ckks.SetPublicKeys(pk);
        ckks.loadSecretKey("D:\\Gaia\\src\\main\\resources");
//        System.out.println("------------------------------------------------");
//        Ciphertext test = ckks.encrypt(42);
//        System.out.println(ckks.decrypt(test));
//        System.out.println("------------------------------------------------");
    }

    public int CT_CMP1(int re, Ciphertext EleR) {
//        BigInteger r=omega.Dec1(R.getImmutable(),pk, sk);

        //System.out.println("pk: " + pk);
        //System.out.println("sk: " + sk);
        //int eler = omega.Dec1(EleR.getImmutable(), pk, sk).intValue();
        
        int eler = (int) Math.round(ckks.decrypt(EleR));
// ****** 打印调试 ******
System.out.println("CT_CMP1 输入 re=" + re + "  EleR=" + EleR);
System.out.println("CT_CMP1 解密 eler=" + eler + "  返回 " + runGarbledCircuit(re, eler));
// ****** 打印结束 ******


        //System.out.println("这是CT33");
//        if(eler.compareTo(BigInteger.valueOf(re))<=0){
//            return 1;
//        }
//        else {
//            return 0;
//        }
        return runGarbledCircuit(re, eler);
    }

//    public int CT_CMP1(Element re, Element EleR) {
//        BigInteger r = omega.Dec1(re.getImmutable(), pk, sk);
//
//        BigInteger eler = omega.Dec1(EleR.getImmutable(), pk, sk);
//        return GCCcompareTo.runGarbledCircuit(r.intValue(), eler.intValue());
//    }

    @SneakyThrows
    public int CT_CMP2(Element re, Element EleR) {
        String sr = Base64.encodeBase64String(re.toBytes());
        String ser = Base64.encodeBase64String(EleR.toBytes());
        String res = sr + ",,," + ser;
        int ret;
        try (Socket socket = new Socket(/*"8.130.44.189"*/"127.0.0.1",12345)) {
            ObjectOutputStream oos=new ObjectOutputStream(socket.getOutputStream());
            oos.writeObject(res);
            oos.flush();
            ObjectInputStream ois=new ObjectInputStream(socket.getInputStream());
            ret= ois.readInt();
        }
        return ret;
    }

    @SneakyThrows
    public BigInteger getSk() {
        FileInputStream inputStream = new FileInputStream("D:\\Gaia\\src\\main\\resources\\SK.json");
        int read;
        int index = 0;
        byte[] res = new byte[1024];
        while ((read = inputStream.read()) != -1) {
            res[index++] = (byte) read;
        }
        inputStream.close();
        return new BigInteger(Base64.decodeBase64(res));
    }

    public static void main(String[] args) throws IOException {



    }

}
