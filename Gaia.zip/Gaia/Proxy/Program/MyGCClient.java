package Proxy.Program;

import Proxy.OT.Temp;
import Proxy.YaoGC.State;

import java.math.BigInteger;


public class MyGCClient extends ProgClient{
    public BigInteger cBits;   //  cBits = bv = random
    public BigInteger[] sBitslbs, cBitslbs;

    public State outputState;

    public MyGCClient(BigInteger bv, int length) {   //  bv is random ; length = n = 100
        cBits = bv;
        MyGCCommon.bitVecLen = length;
    }

    protected void init() throws Exception {
//        MyGCCommon.bitVecLen = MyGCCommon.ois.readInt();
//        System.out.println("**1:r");
        MyGCCommon.initCircuits();   //  创建电路

        otNumOfPairs = MyGCCommon.bitVecLen;

        super.init();
    }

    public void execTransfer() throws Exception {
//        System.out.println("**8:r");
        sBitslbs = new BigInteger[MyGCCommon.bitVecLen];

        sBitslbs = Temp.getTemp_sBitslps();

        cBitslbs = new BigInteger[MyGCCommon.bitVecLen];
        rcver.execProtocol(cBits);  //  选择
//        cBitslbs = rcver.getData();
    }

    public void execCircuit() throws Exception {
        cBitslbs = rcver.getData();
        outputState = MyGCCommon.execCircuit(sBitslbs, cBitslbs);
    }


    public void interpretResult() throws Exception {
//        System.out.println("**11:w");
        Temp.setOutLabels(outputState.toLabels());

    }

    public void verify_result() throws Exception {
        Temp.setcBits(cBits);
//        MyGCCommon.oos.writeObject(cBits);
//        MyGCCommon.oos.flush();
    }
}
