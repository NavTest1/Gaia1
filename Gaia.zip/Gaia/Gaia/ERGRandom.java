package Gaia;

import Class.TokenNode;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * 论文中“随机数生成与存储”：为节点生成随机数，用于路径加密的掩码
 */
public class ERGRandom {
    private static final Map<TokenNode, byte[]> randomMap = new HashMap<>();
    private static final Random random = new Random();

    // 生成并存储节点的随机数（字节数组形式）
    public static byte[] getAndStore(TokenNode st) {
        if (!randomMap.containsKey(st)) {
            byte[] r = new byte[16]; // 16字节随机数（可调整长度）
            random.nextBytes(r);
            randomMap.put(st, r);
        }
        return randomMap.get(st);
    }

    // 清空（测试用）
    public static void clear() {
        randomMap.clear();
    }
}