package Gaia;

import Class.TokenNode;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * 全局延迟集合：实现论文中MSR算法的2area-Delay（2D）策略
 * 功能：缓存因前置节点（PSt）未访问且跨区域而暂不能访问的后续节点（SSt）
 */
public class GlobalDelayingSet {
    // 2D策略的延迟集合：存储待访问的SSt节点（TokenNode类型）
    public static final Set<TokenNode> ST2D = Collections.synchronizedSet(new HashSet<>());
    
    // 单例模式：确保全局只有一个GlobalDelayingSet实例
    private static GlobalDelayingSet instance;
    private GlobalDelayingSet() {} // 私有构造方法，禁止外部new
    public static GlobalDelayingSet getInstance() {
        if (instance == null) {
            instance = new GlobalDelayingSet();
        }
        return instance;
    }
    
    /**
     * 1. 添加节点到延迟集合（论文Algorithm 4 Line 8）
     * @param sstNode 需延迟的后续节点（SSt）
     * @return 成功添加返回true，已存在返回false
     */
    public boolean addToST2D(TokenNode sstNode) {
        if (sstNode == null) {
            throw new IllegalArgumentException("待添加的SSt节点不能为null");
        }
        // 线程安全添加
        return ST2D.add(sstNode);
    }
    
    /**
     * 2. 从延迟集合移除节点（论文Algorithm 4隐含逻辑：当PSt被访问后）
     * @param sstNode 已满足访问条件的SSt节点
     * @return 成功移除返回true，不存在返回false
     */
    public boolean removeFromST2D(TokenNode sstNode) {
        if (sstNode == null) {
            throw new IllegalArgumentException("待移除的SSt节点不能为null");
        }
        return ST2D.remove(sstNode);
    }
    
    /**
     * 3. 检查节点是否在延迟集合中（论文Algorithm 3 Line 20：判断E(St1)是否在ST2D）
     * @param node 待检查的节点（可能是SSt）
     * @return 在集合中返回true，否则返回false
     */
    public boolean isInST2D(TokenNode node) {
        if (node == null) {
            return false;
        }
        return ST2D.contains(node);
    }
    
    /**
     * 4. 获取延迟集合的不可修改视图
     * @return 不可修改的ST2D集合
     */
    public Set<TokenNode> getST2DView() {
        return Collections.unmodifiableSet(ST2D);
    }
    
    /**
     * 5. 清空延迟集合（导航任务结束后重置）
     */
    public void clearST2D() {
        ST2D.clear();
    }
}