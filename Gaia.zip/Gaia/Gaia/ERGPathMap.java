package Gaia; 

import Class.TokenNode;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * 论文中“明文路径映射”：存储<起点, 终点> → 明文路径字节数组
 * 修复：添加阻塞边校验、路径格式验证、空节点检查
 */
public class ERGPathMap {
    // 存储路径映射：起点 → {终点 → 路径字节数组}
    private static final Map<TokenNode, Map<TokenNode, byte[]>> pathMap = new HashMap<>();
    // 存储阻塞边：起点 → {终点 → 是否阻塞}
    private static final Map<TokenNode, Map<TokenNode, Boolean>> blockedEdges = new HashMap<>();
    // 路径格式正则（如 "1->2->3"）
    private static final Pattern PATH_PATTERN = Pattern.compile("^\\d+(->\\d+)*$");

    /**
     * 注册阻塞边（从Floyd算法中同步阻塞信息）
     */
    public static void registerBlockedEdge(TokenNode from, TokenNode to, boolean isBlocked) {
        validateNode(from, "起点");
        validateNode(to, "终点");
        blockedEdges.computeIfAbsent(from, k -> new HashMap<>()).put(to, isBlocked);
        // 无向图需同步反向边
        blockedEdges.computeIfAbsent(to, k -> new HashMap<>()).put(from, isBlocked);
    }

    /**
     * 注册明文路径：增加路径格式校验
     */
    public static void registerPlainPath(TokenNode prev, TokenNode st, byte[] plainPath) {
        validateNode(prev, "起点");
        validateNode(st, "终点");
        validatePath(plainPath); // 校验路径格式
        
        // 检查是否为阻塞边
        if (isBlocked(prev, st)) {
            throw new IllegalArgumentException("禁止注册阻塞边的路径：" + prev.getId() + "->" + st.getId());
        }
        
        pathMap.computeIfAbsent(prev, k -> new HashMap<>()).put(st, plainPath);
    }

    /**
     * 获取明文路径：增加阻塞边检查
     */
    public static byte[] getPlainPath(TokenNode prev, TokenNode st) {
        validateNode(prev, "起点");
        validateNode(st, "终点");
        
        // 检查是否为阻塞边
        if (isBlocked(prev, st)) {
            // 尝试获取绕行节点
            TokenNode dst = ERGDeviationMap.getDSt(prev, st);
            if (dst != null) {
                // 存在绕行节点，生成 prev->dst->st 的路径
                byte[] prevToDstPath = getPlainPath(prev, dst);
                byte[] dstToStPath = getPlainPath(dst, st);
                String pathStr = new String(prevToDstPath) + "->" + new String(dstToStPath);
                return pathStr.getBytes();
            } else {
                throw new IllegalStateException("访问了阻塞边且无绕行节点，路径不可达：" + prev.getId() + "->" + st.getId());
            }
        }
    
        byte[] path = pathMap.getOrDefault(prev, new HashMap<>()).getOrDefault(st, new byte[0]);
        validatePath(path); // 二次校验路径格式
        return path;
    }

    /**
     * 检查边是否阻塞
     */
    public static boolean isBlocked(TokenNode from, TokenNode to) {
        return blockedEdges.getOrDefault(from, new HashMap<>()).getOrDefault(to, false);
    }

    /**
     * 验证节点非空且ID有效
     */
    private static void validateNode(TokenNode node, String nodeType) {
        if (node == null) {
            throw new IllegalArgumentException(nodeType + "不能为空");
        }
        if (node.getId() < 0) { // 假设ID为正整数
            throw new IllegalArgumentException(nodeType + "ID无效：" + node.getId());
        }
    }

    /**
     * 验证路径格式（防止"02->->3"这类错误）
     */
    private static void validatePath(byte[] pathBytes) {
        if (pathBytes == null || pathBytes.length == 0) {
            return; // 空路径允许（直接连接）
        }
        
        String path = new String(pathBytes);
        if (!PATH_PATTERN.matcher(path).matches()) {
            throw new IllegalArgumentException("路径格式错误：" + path + "（正确格式：1->2->3）");
        }
    }

    /**
     * 清空所有数据（测试用）
     */
    public static void clear() {
        pathMap.clear();
        blockedEdges.clear();
    }
}
    