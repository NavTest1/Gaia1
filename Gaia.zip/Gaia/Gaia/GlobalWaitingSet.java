package Gaia;

import Class.TokenNode;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * 全局等待集合：实现论文中MSR算法的1area-Wait（1W）策略
 * 功能：缓存因前置节点（PSt）未访问而暂不能访问的后续节点（SSt）
 */
public class GlobalWaitingSet {
    // 1W策略的等待集合：存储待访问的SSt节点（TokenNode类型）
    public static final Set<TokenNode> ST1W = Collections.synchronizedSet(new HashSet<>());
    
    // 单例模式：确保全局只有一个GlobalWaitingSet实例（避免多实例导致数据不一致）
    private static GlobalWaitingSet instance;
    private GlobalWaitingSet() {} // 私有构造方法，禁止外部new
    public static GlobalWaitingSet getInstance() {
        if (instance == null) {
            instance = new GlobalWaitingSet();
        }
        return instance;
    }
    
    /**
     * 1. 添加节点到等待集合（论文Algorithm 4 Line 3）
     * @param sstNode 需等待的后续节点（SSt）
     * @return 成功添加返回true，已存在返回false
     */
    public boolean addToST1W(TokenNode sstNode) {
        if (sstNode == null) {
            throw new IllegalArgumentException("待添加的SSt节点不能为null");
        }
        // 线程安全添加（避免多线程调用SK/MSR时的并发问题）
        return ST1W.add(sstNode);
    }
    
    /**
     * 2. 从等待集合移除节点（论文Algorithm 4隐含逻辑：当PSt被访问后）
     * @param sstNode 已满足访问条件的SSt节点
     * @return 成功移除返回true，不存在返回false
     */
    public boolean removeFromST1W(TokenNode sstNode) {
        if (sstNode == null) {
            throw new IllegalArgumentException("待移除的SSt节点不能为null");
        }
        return ST1W.remove(sstNode);
    }
    
    /**
     * 3. 检查节点是否在等待集合中（论文Algorithm 3 Line 18：判断E(St1)是否在ST1W）
     * @param node 待检查的节点（可能是SSt）
     * @return 在集合中返回true，否则返回false
     */
    public boolean isInST1W(TokenNode node) {
        if (node == null) {
            return false; // 空节点不可能在集合中
        }
        return ST1W.contains(node);
    }
    
    /**
     * 4. 获取等待集合的不可修改视图（避免外部直接修改集合，保证数据安全性）
     * @return 不可修改的ST1W集合
     */
    public Set<TokenNode> getST1WView() {
        return Collections.unmodifiableSet(ST1W);
    }
    
    /**
     * 5. 清空等待集合（用于导航任务结束后重置，避免影响下一次导航）
     */
    public void clearST1W() {
        ST1W.clear();
    }
}