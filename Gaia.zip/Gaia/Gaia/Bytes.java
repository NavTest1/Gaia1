package Gaia;

/**
 * 论文中“字节操作工具”：提供字节数组异或（XOR）操作，用于路径加密
 */
public class Bytes {
    // 字节数组异或：a XOR b → result
    public static byte[] xor(byte[] a, byte[] b) {
        if (a.length != b.length) {
            throw new IllegalArgumentException("字节数组长度必须一致");
        }
        byte[] result = new byte[a.length];
        for (int i = 0; i < a.length; i++) {
            result[i] = (byte) (a[i] ^ b[i]);
        }
        return result;
    }
}