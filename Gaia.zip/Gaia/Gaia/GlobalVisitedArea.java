package Gaia;

import Class.TokenNode;
import java.util.HashSet;
import java.util.Set;

/**
 * 论文中“已访问区域集合”：管理区域级别的访问状态
 */
public class GlobalVisitedArea {
    private static final Set<Integer> visitedAreas = new HashSet<>();

    // 标记区域为已访问（通过TokenNode获取区域ID）
    public static void markAreaAsVisited(TokenNode node) {
        int areaId = GlobalAreaMap.getMainArea(node); // 依赖GlobalAreaMap获取区域ID
        visitedAreas.add(areaId);
    }

    // 判断区域是否已访问
    public static boolean isVisited(TokenNode node) {
        int areaId = GlobalAreaMap.getMainArea(node);
        return visitedAreas.contains(areaId);
    }

    // 清空（测试用）
    public static void clear() {
        visitedAreas.clear();
    }
}