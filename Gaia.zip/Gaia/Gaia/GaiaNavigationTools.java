package Gaia;

import NSP.EncNavigationTools;
import ckks.CKKSHelper;
import ckks.Ciphertext;
import ckks.Context;
import ckks.PublicKeys;
import cn.hutool.core.lang.hash.Hash;
import cn.hutool.crypto.digest.DigestUtil;

import java.security.NoSuchAlgorithmException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import Class.PartialOrder;
import Class.TokenNode;
import Class.node;
import NSP.EncVec;
import NSP.EncVecTools;
import NSP.EncGraph;
import NSP.EncNode;
import NSP.StopSet;
import Proxy.CT;
import lombok.SneakyThrows;
import java.util.stream.*;;

/**
 * 完整版：集成Floyd预处理结果的导航算法
 * 修复版：正确集成偏序约束处理
 */
public class GaiaNavigationTools {
    
    // 新增：Floyd预处理实例引用
    private static Algorithm.Floyd_Warshall_1 floydInstance;

    // 设置Floyd实例的方法
    public static void setFloydInstance(Algorithm.Floyd_Warshall_1 floyd) {
        floydInstance = floyd;
    }

    // 在GaiaNavigationTools.java中修改SecureSkimming方法
    public static TokenNode SecureSkimming(TokenNode E_S,
            TokenNode E_D,
            TokenNode IT,
            List<TokenNode> C,
            int dir,
            List<PartialOrder> PO) throws Exception {
        if (PO == null)
            PO = Collections.emptyList();
        return new Navigator(E_S, E_D, C, PO, null, null).SK(E_S, E_D, IT, new StopSet(C),
                (dir == 0) ? Direction.CLOCKWISE : Direction.ANTICLOCKWISE,
                PO);
    }

    /* ====================== 1. 对外唯一入口 ====================== */
    
    // 新的Nav方法，包含节点数据参数
    public static EncryptedQueryResult Nav(TokenNode E_S, TokenNode E_D,
            List<TokenNode> E_Stops, List<PartialOrder> PO,
            ConcurrentHashMap<Integer, node> apl,
            ConcurrentHashMap<Long, Integer> id2Index) throws Exception {
        
        // 验证输入参数
        if (E_S == null || E_D == null) {
            throw new IllegalArgumentException("起点或终点TokenNode为null");
        }

        if (E_S.xEnc == null || E_S.yEnc == null) {
            throw new IllegalArgumentException("起点TokenNode缺少加密坐标");
        }

        if (E_D.xEnc == null || E_D.yEnc == null) {
            throw new IllegalArgumentException("终点TokenNode缺少加密坐标");
        }

        // 新增：验证apl和id2Index参数
        if (apl == null) {
            throw new IllegalArgumentException("apl节点映射不能为null");
        }
        if (id2Index == null) {
            throw new IllegalArgumentException("id2Index索引映射不能为null");
        }

        // 新增：验证Floyd实例已设置
        if (floydInstance == null) {
            throw new IllegalStateException("Floyd预处理实例未设置，请先调用setFloydInstance()");
        }

        System.out.println("=== Gaia Nav 开始 ===");
        System.out.println("起点: " + E_S.getId());
        System.out.println("终点: " + E_D.getId());
        System.out.println("途径点数量: " + E_Stops.size());
        for (int i = 0; i < E_Stops.size(); i++) {
            System.out.println("  途径点 " + i + ": " + E_Stops.get(i).getId());
        }
        System.out.println("偏序约束数量: " + (PO != null ? PO.size() : 0));

        // 🔥 修改：传入apl和id2Index
        EncryptedQueryResult result = new Navigator(E_S, E_D, E_Stops, PO, apl, id2Index).run();

        System.out.println("=== Gaia Nav 完成 ===");
        System.out.println("生成的路径段数: " + result.getTriples().size());
        return result;
    }

    // 保留原有的Nav方法用于兼容性（但抛出异常提示使用新方法）
    public static EncryptedQueryResult Nav(TokenNode E_S, TokenNode E_D,
            List<TokenNode> E_Stops, List<PartialOrder> PO) throws Exception {
        throw new IllegalStateException("请使用新的Nav方法，需要传入apl和id2Index参数");
    }

    /* ====================== 2. 总控Navigator（Algorithm 1） ====================== */
    public static class Navigator {
        TokenNode E_S, E_D;
        List<TokenNode> E_Stops;
        List<PartialOrder> PO;
        EncryptedQueryResult EQR = new EncryptedQueryResult();

        // 新增：存储排序后的途径点序列
        public List<TokenNode> sortedStops = new ArrayList<>();
        
        // 🔥 新增：状态跟踪
        private Set<Long> visitedNodes = new HashSet<>();
        private TokenNode currentNode;
        
        // 新增：节点数据和索引映射
        ConcurrentHashMap<Integer, node> apl;
        ConcurrentHashMap<Long, Integer> Id2Index;

        // 修改后的构造函数
        public Navigator(TokenNode s, TokenNode d, List<TokenNode> stops, List<PartialOrder> po,
                 ConcurrentHashMap<Integer, node> aplMap,
                 ConcurrentHashMap<Long, Integer> id2Index) {
            this.E_S = s;
            this.E_D = d;
            this.E_Stops = stops;
            this.PO = (po != null) ? po : new ArrayList<>(); // 确保PO不为null
            this.apl = aplMap;
            this.Id2Index = id2Index;
            
            // 🔥 新增：初始化状态
            this.currentNode = E_S;
            this.visitedNodes.add(E_S.getId());
        }

        public EncryptedQueryResult run() throws Exception {
            System.out.println("[Gaia Navigator] 开始导航，总途径点数: " + E_Stops.size() + ", 偏序约束: " + PO.size());
            System.out.println("[Gaia Navigator] 偏序约束详情:");
            for (int i = 0; i < PO.size(); i++) {
                PartialOrder po = PO.get(i);
                System.out.printf("  约束%d: %d → %d\n", i + 1, po.getPSt().getId(), po.getSSt().getId());
            }

            if (E_Stops.isEmpty()) {
                System.out.println("[Gaia Navigator] 途径点为空，直接返回");
                buildAndEncryptDirectPath();
                return EQR;
            }

            // 修复：添加空值检查
            StopSet[] triple = EncNavigationTools.SecureGrouping(E_S, E_D, new ArrayList<>(E_Stops));

            System.out.println("[Gaia Navigator] SecureGrouping 结果: " +
                    "STL=" + triple[0].size() + ", STM=" + triple[1].size() + ", STH=" + triple[2].size());

            // 确保triple数组不为null且包含3个元素
            if (triple == null || triple.length < 3) {
                throw new IllegalStateException("SecureGrouping返回无效结果");
            }

            // 初始化可能为null的StopSet
            for (int i = 0; i < triple.length; i++) {
                if (triple[i] == null) {
                    triple[i] = new StopSet();
                }
            }

            // 🔥 修改：使用新的导航方法，集成偏序约束检查
            navigateWithPartialOrderChecking(triple[0], triple[1], triple[2]);

            System.out.println("[Gaia Navigator] 导航完成，总路径段数: " + EQR.triples.size());
            System.out.println("[Gaia Navigator] 最终排序的途径点: " + 
                sortedStops.stream().map(tn -> String.valueOf(tn.getId())).collect(Collectors.joining(" -> ")));
            
            return EQR;
        }

        /**
 * 🔥 新增：在MSR中寻找安全的替代节点
 */
private TokenNode findSafeAlternative(TokenNode violatingNode, StopSet availableStops) throws Exception {
    System.out.println("  [MSR安全替代] 为违反约束的节点 " + violatingNode.getId() + " 寻找替代");
    
    // 从可用节点中寻找不会违反约束的节点
    for (TokenNode candidate : availableStops.list) {
        if (candidate.getId() == violatingNode.getId()) {
            continue; // 跳过原节点
        }
        
        boolean isSafe = true;
        // 检查候选节点是否安全（所有前驱都已访问）
        for (PartialOrder po : PO) {
            if (candidate.getId() == po.SSt.getId() && !visitedNodes.contains(po.PSt.getId())) {
                isSafe = false;
                System.out.println("    [MSR安全替代] ❌ 候选 " + candidate.getId() + 
                                 " 也不安全：前驱 " + po.PSt.getId() + " 未访问");
                break;
            }
        }
        
        if (isSafe) {
            System.out.println("    [MSR安全替代] ✅ 找到安全替代: " + candidate.getId());
            return candidate;
        }
    }
    
    System.out.println("  [MSR安全替代] ❌ 没有找到安全替代节点");
    return null;
}

/**
 * 🔥 新增：检查候选节点是否安全（所有前驱都已访问）
 */
private boolean isCandidateSafe(TokenNode candidate) {
    for (PartialOrder po : PO) {
        // 如果候选节点是某个约束的后继，且前驱节点还未访问
        if (candidate.getId() == po.SSt.getId() && !visitedNodes.contains(po.PSt.getId())) {
            System.out.println("  [MSR安全检查] ❌ 节点 " + candidate.getId() + 
                             " 违反约束: " + po.PSt.getId() + " → " + po.SSt.getId());
            return false;
        }
    }
    System.out.println("  [MSR安全检查] ✅ 节点 " + candidate.getId() + " 是安全的");
    return true;
}

        /**
 * 🔥 修改：集成偏序约束检查的导航方法（修复重复添加问题）
 */
private void navigateWithPartialOrderChecking(StopSet STL, StopSet STM, StopSet STH) throws Exception {
    System.out.println("[navigateWithPartialOrderChecking] 开始集成偏序检查的导航");
    
    // 🔥 修复：清空之前的排序结果
    sortedStops.clear();
    
    // 1. 处理Low区
    List<TokenNode> lowOrder = processStopSetWithPO(STL, "Low");
    
    // 2. 处理Mid区  
    List<TokenNode> midOrder = processStopSetWithPO(STM, "Mid");
    
    // 3. 处理High区
    List<TokenNode> highOrder = processStopSetWithPO(STH, "High");
    
    // 🔥 修复：只在这里添加一次，不在processStopSetWithPO中添加
    sortedStops.addAll(lowOrder);
    sortedStops.addAll(midOrder);
    sortedStops.addAll(highOrder);
    
    System.out.println("[navigateWithPartialOrderChecking] 导航完成: Low=" + lowOrder.size() + 
                      ", Mid=" + midOrder.size() + ", High=" + highOrder.size());
}

/**
 * 🔥 修改：处理一个StopSet，集成偏序约束检查（修复重复添加问题）
 */
private List<TokenNode> processStopSetWithPO(StopSet stopSet, String areaName) throws Exception {
    System.out.println("[" + areaName + "区处理] 开始，节点数: " + stopSet.size());
    
    List<TokenNode> resultOrder = new ArrayList<>(); // 🔥 修改：只返回结果，不直接添加到sortedStops
    StopSet remainingStops = new StopSet(stopSet.list); // 复制剩余节点
    
    while (!remainingStops.isEmpty()) {
        System.out.println("  [" + areaName + "区] 剩余节点: " + remainingStops.size());
        
        // 选择下一个节点（使用原有的SK算法）
        TokenNode nextCandidate = selectNextCandidate(remainingStops, areaName);
        
        if (nextCandidate == null) {
            System.out.println("  [" + areaName + "区] 无法选择下一个节点，退出");
            break;
        }
        
        // 🔥 关键：检查偏序约束并处理
        TokenNode actualNext = checkAndHandlePartialOrder(nextCandidate, remainingStops);
        
        if (actualNext != null) {
            // 🔥 修改：只添加到结果顺序，不在processStopSetWithPO中添加到sortedStops
            resultOrder.add(actualNext);
            
            // 更新状态
            visitedNodes.add(actualNext.getId());
            currentNode = actualNext;
            
            // 从剩余节点中移除
            remainingStops.remove(actualNext);
            
            System.out.println("  [" + areaName + "区] 选择节点: " + actualNext.getId() + 
                             ", 剩余: " + remainingStops.size());
        } else {
            System.out.println("  [" + areaName + "区] 无法处理节点 " + nextCandidate.getId() + "，跳过");
            remainingStops.remove(nextCandidate);
        }
    }
    
    System.out.println("[" + areaName + "区处理] 完成，处理节点: " + resultOrder.size());
    return resultOrder; // 🔥 修改：返回结果，由调用者统一添加到sortedStops
}

        /**
         * 🔥 新增：检查偏序约束并处理违反情况
         */
        private TokenNode checkAndHandlePartialOrder(TokenNode candidate, StopSet availableStops) throws Exception {
            System.out.println("  [偏序检查] 检查候选节点: " + candidate.getId());
            
            // 检查所有偏序约束
            for (PartialOrder po : PO) {
                // 如果候选节点是某个约束的后继节点
                if (candidate.getId() == po.SSt.getId()) {
                    System.out.println("  [偏序检查] 节点 " + candidate.getId() + " 是约束 " + 
                                     po.PSt.getId() + " → " + po.SSt.getId() + " 的后继");
                    
                    // 检查前驱节点是否已访问
                    if (!visitedNodes.contains(po.PSt.getId())) {
                        System.out.println("  [偏序检查] ❌ 约束违反: 前驱节点 " + po.PSt.getId() + " 未访问");
                        
                        // 触发MSR策略处理
                        TokenNode alternative = handlePartialOrderViolation(candidate, po, availableStops);
                        if (alternative != null && alternative.getId() != candidate.getId()) {
                            System.out.println("  [偏序检查] 🔄 MSR返回替代节点: " + alternative.getId());
                            return alternative;
                        } else {
                            System.out.println("  [偏序检查] ⚠️ MSR无法提供替代节点，跳过当前节点");
                            return null; // 跳过这个违反约束的节点
                        }
                    } else {
                        System.out.println("  [偏序检查] ✅ 约束满足: 前驱节点 " + po.PSt.getId() + " 已访问");
                    }
                }
            }
            
            // 没有约束违反，返回原候选节点
            System.out.println("  [偏序检查] ✅ 节点 " + candidate.getId() + " 无约束违反");
            return candidate;
        }

        /**
         * 🔥 新增：处理偏序约束违反
         */
        private TokenNode handlePartialOrderViolation(TokenNode violatingNode, PartialOrder violatedPO, StopSet availableStops) throws Exception {
            System.out.println("  [MSR处理] 处理约束违反: " + violatedPO.PSt.getId() + " → " + violatedPO.SSt.getId());
            
            // 从可用节点中移除违反约束的节点
            StopSet remainingStops = availableStops.clone();
            remainingStops.remove(violatingNode);
            
            if (remainingStops.isEmpty()) {
                System.out.println("  [MSR处理] ⚠️ 无其他可用节点");
                return null;
            }
            
            // 调用MSR策略选择替代节点
            TokenNode alternative = MSR(currentNode, violatingNode, remainingStops, PO);
            
            if (alternative != null && alternative.getId() != violatingNode.getId()) {
                System.out.println("  [MSR处理] ✅ 找到替代节点: " + alternative.getId());
                return alternative;
            }
            
            System.out.println("  [MSR处理] ❌ 无法找到合适的替代节点");
            return null;
        }

        /**
         * 🔥 新增：选择下一个候选节点（基于原有SK逻辑）
         */
        private TokenNode selectNextCandidate(StopSet stopSet, String areaName) throws Exception {
            if (stopSet.isEmpty()) return null;
            
            if (stopSet.size() == 1) {
                return stopSet.list.get(0);
            }
            
            // 使用原有的SK算法逻辑选择下一个节点
            // 这里简化实现，实际应该根据区域使用不同的选择策略
            TokenNode firstNode = stopSet.list.get(0);
            Direction direction = Direction.CLOCKWISE;
            
            return SK(currentNode, E_D, firstNode, stopSet, direction, PO);
        }

        // 🔥 修改：保留原有的NLow/NMid/NHigh方法，但更新为使用新的状态跟踪
TokenNode NLow(StopSet STL, StopSet STM, StopSet STH) throws Exception {
    List<TokenNode> lowOrder = processStopSetWithPO(STL, "Low");
    if (lowOrder.isEmpty()) {
        return currentNode;
    } else {
        // 🔥 显式赋值和类型转换，修复VerifyError
        TokenNode lastNode = lowOrder.get(lowOrder.size() - 1);
        return lastNode;
    }
}

        TokenNode NMid(TokenNode E_StL_last, StopSet STM) throws Exception {
    List<TokenNode> midOrder = processStopSetWithPO(STM, "Mid");
    if (midOrder.isEmpty()) {
        return E_StL_last;
    } else {
        // 🔥 显式赋值和类型转换，修复VerifyError
        TokenNode lastNode = midOrder.get(midOrder.size() - 1);
        return lastNode;
    }
}

        void NHigh(TokenNode E_StM_last, StopSet STH) throws Exception {
            processStopSetWithPO(STH, "High");
        }

        /* ====================== 新增：增强版路径构建方法 ====================== */
        
        /**
         * 增强版：使用预处理结果构建完整路径（包含中间节点映射）
         */
        private void buildCompletePathFromPrecomputedEnhanced() throws Exception {
            System.out.println("[buildCompletePathFromPrecomputedEnhanced] 开始构建完整路径");
            
            // 收集所有排序后的节点（包括起点和终点）
            List<TokenNode> fullPathOrder = new ArrayList<>();
            fullPathOrder.add(E_S);
            fullPathOrder.addAll(sortedStops);
            fullPathOrder.add(E_D);
            
            System.out.println("[buildCompletePathFromPrecomputedEnhanced] 完整节点顺序: " + 
                fullPathOrder.stream().map(tn -> String.valueOf(tn.getId())).collect(Collectors.joining(" -> ")));
            
            // 步骤1：收集所有路径节点（包括中间节点）
            Set<Long> allPathNodes = collectAllPathNodes(fullPathOrder);
            
            // 步骤2：为所有路径节点创建EncGraph映射
            createEncGraphMappingsForPathNodes(allPathNodes);
            
            // 步骤3：构建加密路径
            buildEncryptedPathSegments(fullPathOrder);
        }

        /**
         * 收集所有路径节点（包括中间节点）
         */
        private Set<Long> collectAllPathNodes(List<TokenNode> fullPathOrder) {
            Set<Long> allPathNodes = new HashSet<>();
            
            for (int i = 0; i < fullPathOrder.size() - 1; i++) {
                TokenNode from = fullPathOrder.get(i);
                TokenNode to = fullPathOrder.get(i + 1);
                
                // 使用预处理结果获取路径
                String precomputedPath = floydInstance.getPathBetweenNodes(from.getId(), to.getId());
                List<Long> segmentNodes = parsePrecomputedPathNodes(precomputedPath, from.getId(), to.getId());
                allPathNodes.addAll(segmentNodes);
                
                System.out.printf("[collectAllPathNodes] 段 %d->%d: %d个节点\n", 
                                 from.getId(), to.getId(), segmentNodes.size());
            }
            
            System.out.println("[collectAllPathNodes] 总共收集到 " + allPathNodes.size() + " 个路径节点");
            return allPathNodes;
        }

        /**
         * 解析路径字符串获取所有节点ID（不创建TokenNode）
         */
        private List<Long> parsePrecomputedPathNodes(String path, long startId, long endId) {
            List<Long> nodeIds = new ArrayList<>();
            nodeIds.add(startId);
            
            if (path == null || path.isEmpty() || path.equals("原地踏步")) {
                nodeIds.add(endId);
                return nodeIds;
            }
            
            try {
                String[] nodeIdStrs = path.split("->");
                for (String nodeIdStr : nodeIdStrs) {
                    nodeIdStr = nodeIdStr.trim();
                    if (!nodeIdStr.isEmpty()) {
                        long nodeId = Long.parseLong(nodeIdStr);
                        nodeIds.add(nodeId);
                    }
                }
                nodeIds.add(endId);
            } catch (Exception e) {
                System.err.println("[parsePrecomputedPathNodes] 解析路径失败: " + path + " - " + e.getMessage());
                // 解析失败，直接连接起点终点
                nodeIds.clear();
                nodeIds.add(startId);
                nodeIds.add(endId);
            }
            
            return nodeIds;
        }

        /**
         * 为路径中的所有节点创建EncGraph映射
         */
        private void createEncGraphMappingsForPathNodes(Set<Long> pathNodeIds) throws Exception {
            System.out.println("[createEncGraphMappingsForPathNodes] 为 " + pathNodeIds.size() + " 个路径节点创建映射");
            
            int createdCount = 0;
            int existingCount = 0;
            int failedCount = 0;
            
            for (Long nodeId : pathNodeIds) {
                // 检查是否已存在映射
                if (isNodeAlreadyMapped(nodeId)) {
                    existingCount++;
                    continue;
                }
                
                // 创建新的TokenNode并添加到EncGraph
                TokenNode newNode = createTokenNodeWithCoords(nodeId);
                if (newNode != null) {
                    EncNode encNode = new EncNode(newNode.xEnc, newNode.yEnc, newNode);
                    EncGraph.nodeSet.put(newNode, encNode);
                    createdCount++;
                    System.out.println("    ✅ 创建映射: " + nodeId);
                } else {
                    failedCount++;
                    System.err.println("    ❌ 创建映射失败: " + nodeId);
                }
            }
            
            System.out.println("[createEncGraphMappingsForPathNodes] 映射创建完成: 新增=" + createdCount + 
                              ", 已存在=" + existingCount + ", 失败=" + failedCount + 
                              ", 总映射=" + EncGraph.nodeSet.size());
        }

        /**
         * 检查节点是否已存在映射
         */
        private boolean isNodeAlreadyMapped(long nodeId) {
            for (TokenNode existing : EncGraph.nodeSet.keySet()) {
                if (existing.getId() == nodeId){
                    return true;
                }
            }
            return false;
        }

        /**
         * 创建带加密坐标的TokenNode - 修复版
         */
        private TokenNode createTokenNodeWithCoords(long nodeId) throws Exception {
            // 首先检查nodeId是否是矩阵索引（小数字）
            Integer nodeIdx;
            
            if (nodeId < 10000) {  // 假设矩阵索引都是小数字
                // nodeId是矩阵索引，直接使用
                nodeIdx = (int) nodeId;
            } else {
                // nodeId是实际节点ID，通过映射查找
                nodeIdx = Id2Index.get(nodeId);
            }
            
            if (nodeIdx != null && apl != null) {
                node nd = apl.get(nodeIdx);
                if (nd != null) {
                    TokenNode newNode = new TokenNode("", "", "", nd.id);  // 使用实际节点ID
                    // 加密真实坐标
                    newNode.xEnc = ckks.encrypt(nd.x);
                    newNode.yEnc = ckks.encrypt(nd.y);
                    System.out.println("    ✅ 成功创建TokenNode: 索引=" + nodeIdx + ", 实际ID=" + nd.id);
                    return newNode;
                }
            }
            System.err.println("[createTokenNodeWithCoords] 无法找到节点信息: " + nodeId);
            return null;
        }

        /**
         * 构建加密路径段
         */
        private void buildEncryptedPathSegments(List<TokenNode> fullPathOrder) throws Exception {
            for (int i = 0; i < fullPathOrder.size() - 1; i++) {
                TokenNode from = fullPathOrder.get(i);
                TokenNode to = fullPathOrder.get(i + 1);
                
                System.out.println("[buildEncryptedPathSegments] 构建路径段: " + from.getId() + " -> " + to.getId());
                
                String precomputedPath = floydInstance.getPathBetweenNodes(from.getId(), to.getId());
                List<TokenNode> segmentNodes = parsePrecomputedPath(precomputedPath, from, to);
                
                // 加密路径段（跳过第一个节点，因为它是前一段的终点）
                for (int j = 0; j < segmentNodes.size() - 1; j++) {
                    EQR.addEncryptedPath(segmentNodes.get(j + 1), segmentNodes.get(j), PO);
                }
            }
        }

        /**
         * 构建直接路径（无途径点时）
         */
        private void buildAndEncryptDirectPath() throws Exception {
            System.out.println("[buildAndEncryptDirectPath] 构建直接路径: " + E_S.getId() + " -> " + E_D.getId());
            
            // 使用预处理结果获取路径
            String precomputedPath = floydInstance.getPathBetweenNodes(E_S.getId(), E_D.getId());
            if (precomputedPath != null && !precomputedPath.isEmpty() && !precomputedPath.equals("原地踏步")) {
                // 解析路径节点并加密
                List<TokenNode> pathNodes = parsePrecomputedPath(precomputedPath, E_S, E_D);
                for (int i = 0; i < pathNodes.size() - 1; i++) {
                    EQR.addEncryptedPath(pathNodes.get(i + 1), pathNodes.get(i), PO);
                }
            } else {
                // 备选：直接连接起点终点
                EQR.addEncryptedPath(E_D, E_S, PO);
            }
        }

        /**
         * 解析预处理路径字符串为TokenNode列表
         */
        private List<TokenNode> parsePrecomputedPath(String path, TokenNode start, TokenNode end) {
            List<TokenNode> nodes = new ArrayList<>();
            nodes.add(start);
            
            if (path == null || path.isEmpty() || path.equals("原地踏步")) {
                // 直接连接
                nodes.add(end);
                return nodes;
            }
            
            try {
                // 解析路径中的中间节点
                String[] nodeIds = path.split("->");
                for (String nodeIdStr : nodeIds) {
                    nodeIdStr = nodeIdStr.trim();
                    if (!nodeIdStr.isEmpty()) {
                        long nodeId = Long.parseLong(nodeIdStr);
                        // 查找对应的TokenNode
                        TokenNode node = findTokenNodeById(nodeId);
                        if (node != null) {
                            nodes.add(node);
                        }
                    }
                }
                
                // 添加终点
                nodes.add(end);
                
            } catch (Exception e) {
                System.err.println("[parsePrecomputedPath] 解析路径失败: " + path + ", 错误: " + e.getMessage());
                // 备选：直接连接
                nodes.clear();
                nodes.add(start);
                nodes.add(end);
            }
            
            return nodes;
        }

        /**
         * 根据节点ID查找TokenNode
         */
        private TokenNode findTokenNodeById(long nodeId) {
            // 首先在EncGraph中查找
            for (TokenNode key : EncGraph.nodeSet.keySet()) {
                if (key.getId() == nodeId) {
                    return key;
                }
            }
            
            // 然后在途径点中查找
            for (TokenNode stop : E_Stops) {
                if (stop.getId() == nodeId) {
                    return stop;
                }
            }
            
            // 然后在起点终点中查找
            if (E_S.getId() == nodeId) return E_S;
            if (E_D.getId() == nodeId) return E_D;
            
            // 如果没有找到，创建临时的TokenNode（只包含ID）
            System.out.println("[findTokenNodeById] 警告: 创建临时TokenNode for ID: " + nodeId);
            return new TokenNode("", "", "", nodeId);
        }

        /* ---------- Algorithm 3 SK ---------- */
        TokenNode SK(TokenNode E_S, TokenNode E_D, TokenNode IT, StopSet ST, Direction dir, List<PartialOrder> PO)
                throws Exception {
            System.out.println("[SK] 排序决策: IT=" + (IT != null ? IT.getId() : "null") + ", ST=" + ST.size() + ", dir=" + dir);

            if (ST.isEmpty()) {
                System.out.println("[SK] ST为空，返回IT");
                return IT;
            }

            if (ST.size() == 1) {
                System.out.println("[SK] ST只有1个节点，直接返回");
                return ST.list.get(0);
            }

            StopSet STOnL1 = new StopSet();
            for (TokenNode Sti : ST.list) {
                Ciphertext cross = EncVecTools.cross(E_S, E_D, Sti);
                Ciphertext blind = ckks.add(cross, getRe());
                int cb = ctInstance.CT_CMP1(ri(), blind);
                if (cb == 1)
                    STOnL1.add(Sti);
            }

            System.out.println("[SK] STOnL1 节点数量: " + STOnL1.size());

            TokenNode E_St1 = null;
            if (!STOnL1.isEmpty()) {
                System.out.println("[SK] 情况1: STOnL1非空");
                E_St1 = STOnL1.list.get(0);
                for (int i = 1; i < STOnL1.list.size(); i++) {
                    TokenNode E_St2 = STOnL1.list.get(i);
                    Ciphertext enumEnc = EncVecTools.projection(E_St1, E_St2, E_S, E_D);
                    Ciphertext blind = ckks.add(enumEnc, getRe());
                    int cb = ctInstance.CT_CMP1(ri(), blind);
                    if (cb == 0)
                        E_St1 = E_St2;
                }
                TokenNode ans = MSR(E_S, E_St1, ST, PO);
                if (ans != null)
                    return ans;
            } else {
                System.out.println("[SK] 情况2: STOnL1为空");
                int idx = 1;
                E_St1 = ST.list.get(0);
                StopSet STOnSSt1 = new StopSet();
                while (idx < ST.list.size()) {
                    TokenNode E_St2 = ST.list.get(idx);
                    int side = EncNavigationTools.SecureOrienting(E_S, E_St1, E_St2);
                    if (side == RIGHT) {
                        E_St1 = E_St2;
                        STOnSSt1.clear();
                    } else {
                        Ciphertext colEnc = EncVecTools.colinear(E_S, E_St1, E_St2);
                        Ciphertext blind = ckks.add(colEnc, getRe());
                        int cb = ctInstance.CT_CMP1(ri(), blind);
                        if (cb == 1)
                            STOnSSt1.add(E_St2);
                    }
                    idx++;
                }
                if (!STOnSSt1.isEmpty()) {
                    Ciphertext esX = E_S.xEnc;
                    Ciphertext esY = E_S.yEnc;
                    Ciphertext est1X = E_St1.xEnc;
                    Ciphertext est1Y = E_St1.yEnc;

                    Ciphertext vecX = ckks.subtract(est1X, esX);
                    Ciphertext vecY = ckks.subtract(est1Y, esY);

                    EncVec vec = new EncVec(vecX, vecY);

                    E_St1 = findNearestOnLine(E_S, STOnSSt1, vec, PO);
                } else {
                    E_St1 = findMostExtremeStop(E_S, ST, dir, PO);
                }
            }

            TokenNode msrResult = MSR(E_S, E_St1, ST, PO);
            System.out.println("[SK] 完成，选择节点: " + (msrResult != null ? msrResult.getId() : E_St1.getId()));
            return (msrResult != null) ? msrResult : E_St1;
        }

        /* ---------- Algorithm 4 MSR ---------- */
TokenNode MSR(TokenNode E_S, TokenNode E_St1, StopSet ST, List<PartialOrder> PO) throws Exception {
    System.out.println("  [MSR策略] 开始处理，当前候选: " + E_St1.getId() + ", 可用节点: " + ST.size());
    
    // 🔥 新增：在MSR中加强约束检查
    if (!isCandidateSafe(E_St1)) {
        System.out.println("  [MSR策略] ❌ 候选节点 " + E_St1.getId() + " 违反约束，寻找替代");
        
        // 寻找安全的替代节点
        TokenNode safeAlternative = findSafeAlternative(E_St1, ST);
        if (safeAlternative != null) {
            System.out.println("  [MSR策略] ✅ 找到安全替代节点: " + safeAlternative.getId());
            return safeAlternative;
        } else {
            System.out.println("  [MSR策略] ⚠️ 无法找到安全替代节点，使用原节点但可能违反约束");
        }
    }
    
    GlobalWaitingSet waitingSet = GlobalWaitingSet.getInstance();

    // 1W策略：同区域等待
    for (PartialOrder po : PO) {
        if (E_St1.getId() == po.SSt.getId() && isSameMainArea(po.PSt, po.SSt)) {
            System.out.println("  [MSR策略] ✅ 触发策略: 1W（同区域等待）");
            waitingSet.addToST1W(E_St1);
            
            StopSet remain = ST.clone();
            remain.remove(E_St1);
            
            if (!remain.isEmpty()) {
                // 🔥 修改：寻找安全的替代节点
                TokenNode alternative = findSafeAlternative(E_St1, remain);
                if (alternative != null) {
                    System.out.println("  [MSR策略] 选择替代节点: " + alternative.getId());
                    return alternative;
                }
            }
        }
    }
    
    // 2D策略：高区域延迟
    for (PartialOrder po : PO) {
        if (E_St1.getId() == po.SSt.getId() && isHigherMainArea(po.PSt, po.SSt)) {
            System.out.println("  [MSR策略] ✅ 触发策略: 2D（高区域延迟）");
            GlobalDelayingSet delayingSet = GlobalDelayingSet.getInstance();
            delayingSet.addToST2D(E_St1);
            
            StopSet remain = ST.clone();
            remain.remove(E_St1);
            
            if (!remain.isEmpty()) {
                // 🔥 修改：寻找安全的替代节点
                TokenNode alternative = findSafeAlternative(E_St1, remain);
                if (alternative != null) {
                    System.out.println("  [MSR策略] 选择替代节点: " + alternative.getId());
                    return alternative;
                }
            }
        }
    }
    
    // ViaDSt策略：寻找绕行节点
    TokenNode DSt = getDStBetween(E_S, E_St1);
    if (DSt != null) {
        System.out.println("  [MSR策略] ✅ 触发策略: ViaDSt（绕行节点 " + DSt.getId() + "）");
        if (isVisitedArea(DSt) || isLowerMainArea(DSt, E_St1)) {
            return DSt;
        }
        if (isSameMainArea(DSt, E_St1)) {
            Direction dr = computePartialCAC(E_S, E_St1, DSt);
            return SK(E_S, E_S, DSt, ST, dr, PO);
        }
    }
    
    System.out.println("  [MSR策略] ⚠️ 所有策略均无法处理，返回原节点");
    return E_St1;
}

        /* ====================== 工具函数 ====================== */
        private TokenNode handleEmptyAM(StopSet STL, StopSet STH) throws Exception {
            if (STL == null || STL.isEmpty()) {
                System.out.println("[handleEmptyAM] STL为空，返回E_S");
                return E_S;
            }

            int SHl = 0, SHr = 0;
            for (TokenNode IT : STH.list) {
                int side = EncNavigationTools.SecureOrienting(E_S, E_D, IT);
                if (side == LEFT)
                    SHl = 1;
                else
                    SHr = 1;
            }

            StopSet STLl = new StopSet(), STlr = new StopSet();
            for (TokenNode IT : STL.list) {
                int side = EncNavigationTools.SecureOrienting(E_S, E_D, IT);
                if (side == LEFT)
                    STLl.add(IT);
                else
                    STlr.add(IT);
            }

            TokenNode IT;
            if (SHl == 1 && SHr == 0 && !STlr.isEmpty()) {
                IT = STlr.list.get(0);
                return SK(E_S, E_D, IT, STlr, Direction.CLOCKWISE, PO);
            } else if (SHl == 0 && SHr == 1 && !STLl.isEmpty()) {
                IT = STLl.list.get(0);
                return SK(E_S, E_D, IT, STLl, Direction.ANTICLOCKWISE, PO);
            } else if (!STlr.isEmpty()) {
                IT = STlr.list.get(0);
                return SK(E_S, E_D, IT, STlr, Direction.CLOCKWISE, PO);
            } else if (!STLl.isEmpty()) {
                IT = STLl.list.get(0);
                return SK(E_S, E_D, IT, STLl, Direction.ANTICLOCKWISE, PO);
            } else {
                System.out.println("[handleEmptyAM] 所有候选集都为空，返回E_S");
                return E_S;
            }
        }

        private void logMSRTrigger(TokenNode currentNode, PartialOrder po, String strategy) {
            System.out.println("[MSR] 检查策略: " + strategy);
            System.out.println("  当前节点ID: " + currentNode.getId());
            System.out.println("  PO中SStID: " + po.SSt.getId());
            System.out.println("  PO中PStID: " + po.PSt.getId());
            System.out.println("  isVisited(PSt): " + isVisited(po.PSt));
            System.out.println("  ID匹配: " + (currentNode.getId() == po.SSt.getId()));
            System.out.println("  同区域: " + isSameMainArea(po.PSt, po.SSt));
        }

        private StopSet filterSide(StopSet src, Direction target) {
            StopSet res = new StopSet();

            if (src == null || src.list == null) {
                return res;
            }

            for (TokenNode st : src.list) {
                int side;
                try {
                    side = EncNavigationTools.SecureOrienting(E_S, E_D, st);
                } catch (NoSuchAlgorithmException e) {
                    System.err.println("[filterSide] SecureOrienting 异常: " + e.getMessage());
                    continue;
                }

                if (side == target.getCode()) {
                    res.add(st);
                }
            }
            return res;
        }

        private TokenNode findNearestOnLine(TokenNode E_S, StopSet STOnLine, EncVec lineVec, List<PartialOrder> PO)
                throws Exception {
            TokenNode E_St1 = STOnLine.list.get(0);
            for (int i = 1; i < STOnLine.list.size(); i++) {
                TokenNode E_St2 = STOnLine.list.get(i);
                Ciphertext projEnc = EncVecTools.projection(E_St1, E_St2, E_S, E_D);
                Ciphertext blind = ckks.add(projEnc, getRe());
                int cb = ctInstance.CT_CMP1(ri(), blind);
                if (cb == 0)
                    E_St1 = E_St2;
            }
            TokenNode ans = MSR(E_S, E_St1, STOnLine, PO);
            return ans != null ? ans : E_St1;
        }

        private TokenNode findMostExtremeStop(TokenNode E_S, StopSet ST, Direction dir, List<PartialOrder> PO)
                throws Exception {
            TokenNode E_St1 = ST.list.get(0);
            for (int i = 1; i < ST.list.size(); i++) {
                TokenNode E_St2 = ST.list.get(i);
                int side = EncNavigationTools.SecureOrienting(E_S, E_St1, E_St2);
                if (dir == Direction.CLOCKWISE && side == RIGHT)
                    E_St1 = E_St2;
                if (dir == Direction.ANTICLOCKWISE && side == LEFT)
                    E_St1 = E_St2;
            }
            TokenNode ans = MSR(E_S, E_St1, ST, PO);
            return ans != null ? ans : E_St1;
        }

        /* ====================== 全局静态工具 ====================== */
        private static final Random rnd = new Random();

        private static int ri() {
            return rnd.nextInt(1000) + 5000;
        }

        private static Ciphertext getRe() {
            CKKSHelper localCkks = ckks;
            if (localCkks == null) {
                localCkks = GaiaNavigationTools.getCKKS();
                if (localCkks == null) {
                    throw new IllegalStateException("CKKS 未初始化，请先调用 setCKKS() 方法");
                }
            }
            return localCkks.encrypt(ri());
        }

        /* ====================== 外部依赖 ====================== */
        public static volatile CKKSHelper ckks;
        public static volatile CT ct;

        public static synchronized void setCKKS(CKKSHelper helper, CT ct1) {
            ckks = helper;
            ct = ct1;
            Navigator.ckks = helper;
            Navigator.ct = ct1;
        }

        /* ====================== 占位工具 ====================== */
        private static boolean isVisited(TokenNode n) {
            return GlobalVisitedSet.isVisited(n);
        }

        private static boolean isVisitedArea(TokenNode n) {
            return GlobalVisitedArea.isVisited(n);
        }

        private static boolean isSameMainArea(TokenNode a, TokenNode b) {
            return GlobalAreaMap.getMainArea(a) == GlobalAreaMap.getMainArea(b);
        }

        private static boolean isHigherMainArea(TokenNode a, TokenNode b) {
            return GlobalAreaMap.getMainArea(a) < GlobalAreaMap.getMainArea(b);
        }

        private static boolean isLowerMainArea(TokenNode a, TokenNode b) {
            return GlobalAreaMap.getMainArea(a) > GlobalAreaMap.getMainArea(b);
        }

        private static TokenNode getDStBetween(TokenNode from, TokenNode to) {
            return ERGDeviationMap.getDSt(from, to);
        }

        private static Direction computePartialCAC(TokenNode E_CSt, TokenNode E_NSt, TokenNode E_DSt) {
            int side;
            try {
                side = EncNavigationTools.SecureOrienting(E_CSt, E_NSt, E_DSt);
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
                throw new RuntimeException("算法不存在异常", e);
            }
            return side == LEFT ? Direction.CLOCKWISE : Direction.ANTICLOCKWISE;
        }
    }

    /* ====================== 7. 结果容器 ====================== */
    private static volatile CT ctInstance;
    private static volatile CKKSHelper ckks;

    public static synchronized void setCKKS(CKKSHelper helper, CT ct) {
        ckks = helper;
        ctInstance = ct;
        Navigator.ckks = helper;
        Navigator.ct = ct;
    }

    public static CKKSHelper getCKKS() {
        CKKSHelper localCkks = ckks;
        if (localCkks == null) {
            throw new IllegalStateException("CKKS 未初始化，请先调用 setCKKS() 方法");
        }
        return localCkks;
    }

    public static class EncryptedQueryResult {
        private final List<EncryptedPathTriple> triples = new ArrayList<>();
        private Ciphertext encTotalDistance;

        public void addEncryptedPath(TokenNode st, TokenNode prev, List<PartialOrder> PO) {
            System.out.println("[addEncryptedPath] " + prev.getId() + " -> " + st.getId());

            // 修改：不再检查阻塞边，因为预处理阶段已经处理
            byte[] plainSeg = ERGPathMap.getPlainPath(prev, st);
            int segLen = plainSeg.length;
            byte[] r = ERGRandom.getAndStore(st);
            byte[] hashedR = DigestUtil.sha256(r);
            byte[] mask = CryptoPRF.F(sk3, hashedR, segLen);
            byte[] encSeg = Bytes.xor(plainSeg, mask);
            triples.add(new EncryptedPathTriple(st, encSeg, r));
            accumulateDistance(st);
        }

        private void accumulateDistance(TokenNode st) {
            Ciphertext seg = ERGDistanceMap.getEncDistance(st);
            if (seg == null) {
                System.err.println("[WARN] 节点 " + st.getId() + " 缺少加密距离，跳过累加");
                return;
            }
            if (encTotalDistance == null)
                encTotalDistance = seg;
            else
                encTotalDistance = ckks.add(encTotalDistance, seg);
        }

        public List<EncryptedPathTriple> getTriples() {
            return Collections.unmodifiableList(triples);
        }

        public Ciphertext getEncTotalDistance() {
            return encTotalDistance;
        }
    }

    public static class EncryptedPathTriple {
        public TokenNode E_St;
        public byte[] encPath;
        public byte[] r;

        public EncryptedPathTriple(TokenNode st, byte[] enc, byte[] rand) {
            this.E_St = st;
            this.encPath = enc;
            this.r = rand;
        }

        public TokenNode getESt() {
            return E_St;
        }

        public byte[] getEncPath() {
            return encPath;
        }

        public byte[] getR() {
            return r;
        }
    }

    /* ====================== 8. 常量 ====================== */
    public enum Direction {
        CLOCKWISE(2),
        ANTICLOCKWISE(3),
        LEFT(1),
        RIGHT(0);

        private final int code;

        Direction(int code) {
            this.code = code;
        }

        public int getCode() {
            return code;
        }
    }

    private static final int LEFT = 1, RIGHT = 0, ON = -1;

    /* ====================== 9. 外部全局 ====================== */
    private static byte[] sk3;

    public static void setSK3(byte[] sk) {
        sk3 = sk;
    }

    /* ====================== 11. 获取CT实例的方法 ====================== */
    public static CT getCT() {
        CT localCt = ctInstance;
        if (localCt == null) {
            throw new IllegalStateException("CT 未初始化，请先调用 setCKKS() 方法");
        }
        return localCt;
    }
}