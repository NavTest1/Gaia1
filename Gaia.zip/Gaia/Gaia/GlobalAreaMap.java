package Gaia;

import Class.TokenNode;
import java.util.HashMap;
import java.util.Map;

/**
 * 论文中“区域层级映射”：定义节点→主区域ID的映射，及区域层级关系
 */
public class GlobalAreaMap {
    // 节点→主区域ID的映射（示例：可从配置/数据库加载）
    private static final Map<TokenNode, Integer> nodeToArea = new HashMap<>();

    // 初始化区域映射（示例数据，需替换为真实逻辑）
    static {
        // 示例：TokenNode1属于区域1，TokenNode2属于区域2...
        // nodeToArea.put(tokenNode1, 1);
        // nodeToArea.put(tokenNode2, 2);
    }

    // 获取节点所属的主区域ID
    public static int getMainArea(TokenNode node) {
        return nodeToArea.getOrDefault(node, 0); // 0为默认区域（根区域）
    }

    // 判断区域a是否比区域b层级高（区域ID越小，层级越高，符合论文逻辑）
    public static boolean isHigherLevel(int areaA, int areaB) {
        return areaA < areaB;
    }

    // 判断区域a是否比区域b层级低
    public static boolean isLowerLevel(int areaA, int areaB) {
        return areaA > areaB;
    }
}