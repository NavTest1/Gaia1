package Gaia;

import Class.TokenNode;
import ckks.Ciphertext;
import java.util.HashMap;
import java.util.Map;

/**
 * 论文中“加密距离映射”：存储节点→加密距离（密文）
 */
public class ERGDistanceMap {
    private static final Map<TokenNode, Ciphertext> distanceMap = new HashMap<>();

    // 注册加密距离：节点st的加密距离为encDistance
    public static void registerEncDistance(TokenNode st, Ciphertext encDistance) {
        distanceMap.put(st, encDistance);
    }

    // 获取加密距离：节点st的加密距离
    public static Ciphertext getEncDistance(TokenNode st) {
        return distanceMap.getOrDefault(st, null);
    }

    // 清空（测试用）
    public static void clear() {
        distanceMap.clear();
    }
}