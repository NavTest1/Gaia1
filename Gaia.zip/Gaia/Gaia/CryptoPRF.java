package Gaia;


import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

/**
 * 论文中“伪随机函数（PRF）”：基于HMAC生成伪随机掩码
 */
public class CryptoPRF {
    private static final String HMAC_ALGORITHM = "HmacSHA256"; // 选择HMAC算法

    // 伪随机函数F：输入密钥sk和数据r，生成伪随机掩码
    public static byte[] F(byte[] sk, byte[] r) {
        try {
            Mac mac = Mac.getInstance(HMAC_ALGORITHM);
            SecretKeySpec keySpec = new SecretKeySpec(sk, HMAC_ALGORITHM);
            mac.init(keySpec);
            return mac.doFinal(r);
        } catch (NoSuchAlgorithmException | InvalidKeyException e) {
            throw new RuntimeException("PRF生成失败", e);
        }
    }
    /**
 * 生成指定长度的伪随机掩码（循环 HMAC）
 */
public static byte[] F(byte[] sk, byte[] r, int len) {
    byte[] mask = new byte[len];
    Mac mac;
    try {
        mac = Mac.getInstance(HMAC_ALGORITHM);
        SecretKeySpec keySpec = new SecretKeySpec(sk, HMAC_ALGORITHM);
        mac.init(keySpec);
    } catch (NoSuchAlgorithmException | InvalidKeyException e) {
        throw new RuntimeException("PRF初始化失败", e);
    }

    int off = 0;
    int block = 0;
    while (off < len) {
        byte[] blockBytes = new byte[4 + r.length];
        // 用 block 序号作为盐，保证每次 HMAC 输入不同
        blockBytes[0] = (byte) (block >>> 24);
        blockBytes[1] = (byte) (block >>> 16);
        blockBytes[2] = (byte) (block >>> 8);
        blockBytes[3] = (byte) (block);
        System.arraycopy(r, 0, blockBytes, 4, r.length);

        byte[] out = mac.doFinal(blockBytes);
        int copy = Math.min(out.length, len - off);
        System.arraycopy(out, 0, mask, off, copy);
        off += copy;
        block++;
    }
    return mask;
}
}
