package Gaia; 

import Class.TokenNode;
import java.util.HashSet;
import java.util.Set;

/**
 * 论文中“已访问节点集合”：确保每个节点仅被导航一次
 */
public class GlobalVisitedSet {
    private static final Set<TokenNode> visitedNodes = new HashSet<>();

    // 标记节点为已访问
    public static void markAsVisited(TokenNode node) {
        visitedNodes.add(node);
    }

    // 判断节点是否已访问
    public static boolean isVisited(TokenNode node) {
        return visitedNodes.contains(node);
    }

    // 清空（测试用）
    public static void clear() {
        visitedNodes.clear();
    }
}