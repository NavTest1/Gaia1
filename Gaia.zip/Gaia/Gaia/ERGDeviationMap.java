package Gaia;

import Class.TokenNode;
import java.util.HashMap;
import java.util.Map;

/**
 * 论文中“绕行节点映射”：存储<起点, 终点> → 绕行节点DSt
 */
public class ERGDeviationMap {
    // <起点, <终点, 绕行节点DSt>> 的嵌套映射
    private static final Map<TokenNode, Map<TokenNode, TokenNode>> deviationMap = new HashMap<>();

    // 注册绕行节点：从from到to的绕行节点是dst
    public static void registerDSt(TokenNode from, TokenNode to, TokenNode dst) {
        deviationMap.computeIfAbsent(from, k -> new HashMap<>()).put(to, dst);
    }

    // 获取绕行节点：从from到to的DSt
    public static TokenNode getDSt(TokenNode from, TokenNode to) {
        return deviationMap.getOrDefault(from, new HashMap<>()).get(to);
    }

    // 清空（测试用）
    public static void clear() {
        deviationMap.clear();
    }
    // 【添加测试绕行节点的方法】
    // public static void initTestDeviationNodes() {
    //     TokenNode node2 = new TokenNode();
    //     node2.setId(2);
    //     TokenNode node3 = new TokenNode();
    //     node3.setId(3);
    //     TokenNode dstNode5 = new TokenNode();
    //     dstNode5.setId(0);
    //     registerDSt(node2, node3, dstNode5);
    //     System.out.println("已添加测试绕行节点：2->3 的绕行节点为 0");
    // }
}